import datetime
import time
import pandas as pd
import json
import openpyxl
from datetime import timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator

default_args = {
    "owner": "AkejanA",
    "email": ["AkejanA@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}


def sql_check_task(edw_se_hook):
    sql_select = """SELECT count(1)
 from DDS.RS_CR_CONTRACT_DPD_FL dpd
WHERE date_value >= trunc(sysdate) -1
  AND date_value < trunc(sysdate) 
    """
    ora_conn = edw_se_hook.get_conn()
    with ora_conn.cursor() as cursor:
        cursor.execute(sql_select)
        data = cursor.fetchone()[0]
    ora_conn.close()
    if data > 0:
        return "loan_sc_load"
    else:
        return "wait_task"




def concatenate_iin_columns(df, concat_df):
    # List of columns to concatenate
    iin_columns = ['IIN', 'SPOUSE', 'MOTHER_IIN', 'FATHER_IIN', 'SIBLINGS']

    # Create a list of Series objects from df
    series_list = [df[col] for col in iin_columns if col in df.columns]

    # Add the 'CHILD_IIN' column from concat_df if it exists
    if 'CHILD_IIN' in concat_df.columns:
        series_list.append(concat_df['CHILD_IIN'])

    # Concatenate all series vertically
    iins_total = pd.concat(series_list, ignore_index=True)

    # Remove duplicates and reset the index
    iins_total = iins_total.drop_duplicates().reset_index(drop=True)

    # Rename the column to 'IIN'
    iins_total = iins_total.to_frame(name='IIN')

    return iins_total.drop_duplicates()


def calculate_age(iin):
    current_date = datetime.date.today()
    # Extract year, month, and day from IIN
    year = int(iin[:2])
    month = int(iin[2:4])
    day = int(iin[4:6])

    # Validate month and day
    if month < 1 or month > 12:
        return None  # Invalid month
    if day < 1 or day > 31:
        return None  # Invalid day

    # Determine the century
    if year <= int(str(current_date.year)[2:]):
        year += 2000
    else:
        year += 1900

    # Create a date object for the birth date
    try:
        birth_date = datetime.date(year, month, day)
    except ValueError:
        # This catches invalid dates like February 30th
        return None

    # Calculate age
    age = current_date.year - birth_date.year

    # Adjust age if birthday hasn't occurred this year
    if current_date.month < birth_date.month or (
            current_date.month == birth_date.month and current_date.day < birth_date.day):
        age -= 1

    return age

def create_df(edw_se_hook,dssb_de_hook):
    edw_conn = edw_se_hook.get_conn()
    edw_cur = edw_conn.cursor()
    dssbde_conn = dssb_de_hook.get_conn()
    dssbde_cur = dssbde_conn.cursor()

    # Данные с ЗАГСА
    edw_query = f''' 
    select /*+ parallel(12) */ G.Iin_Bin as IIN
    ,MAX(dpd.max_exp_ovrd_cnt) as REAL_DPD_FL
    from DDS.RS_CR_CONTRACT_DPD_FL dpd
    inner join DDS.rs_cr_contract_h h 
        on dpd.rs_cr_contract_id=h.dwh_id and dpd.gm_system_code=h.gm_system_code
    inner join dds.RS_CR_CONTRACT_SCD_S sc 
        on h.dwh_id=sc.dwh_id  and h.gm_system_code=sc.gm_system_code  and trunc(sysdate-1) between sc.date_begin and sc.date_end
    inner join  DDS.GM_SUBJECT_H G 
        ON sc.GM_SUBJECT_ID=G.DWH_ID and G.GM_SYSTEM_CODE=sc.Gm_System_Code
    WHERE dpd.date_value = TO_DATE(sysdate, 'DD-MM-YY')-1
    GROUP BY G.Iin_Bin
    '''
    dssb_query = f''' 
    SELECT DISTINCT 
        IIN, 
        CHILDIIN AS CHILD_IIN, 
        MOTHERIIN AS MOTHER_IIN, 
        FATHERIIN AS FATHER_IIN, 
        CASE WHEN IIN = CHILDIIN THEN 'child' 
                WHEN IIN = MOTHERIIN THEN 'mother' 
                WHEN IIN = FATHERIIN THEN 'father' 
                ELSE NULL 
            END ROLE    
    FROM  DSSB_OCDS.D$GDB_ZAGS C
    WHERE 1=1
    AND IIN IS NOT NULL
    '''
    edw_df = pd.DataFrame(edw_cur.execute(edw_query))
    edw_df.columns = ['IIN','REAL_DPD_FL']

    dssb_df = pd.DataFrame(dssbde_cur.execute(dssb_query))
    dssb_df.columns = ['IIN','CHILD_IIN','MOTHER_IIN','FATHER_IIN','ROLE']
    # данные о мужьях
    df1 = edw_df.merge(dssb_df[(dssb_df['ROLE'] == 'mother') & dssb_df['FATHER_IIN'].notnull()][['IIN', 'FATHER_IIN']].drop_duplicates(),on='IIN', how='left')
    # данные о женах
    df1 = df1.merge(dssb_df[(dssb_df['ROLE'] == 'father') & dssb_df['MOTHER_IIN'].notnull()][['IIN', 'MOTHER_IIN']].drop_duplicates(),on='IIN', how='left')
    df1.columns = ['IIN', 'REAL_DPD_FL', 'HUSBAND_IIN', 'WIFE_IIN']
    # данные о отцах
    df1 = df1.merge(dssb_df[(dssb_df['ROLE'] == 'child') & dssb_df['FATHER_IIN'].notnull()][['IIN', 'FATHER_IIN']].drop_duplicates(),on='IIN', how='left')
    # данные о матерях
    df1 = df1.merge(dssb_df[(dssb_df['ROLE'] == 'child') & dssb_df['MOTHER_IIN'].notnull()][['IIN', 'MOTHER_IIN']].drop_duplicates(), on='IIN', how='left')
    # братья и сестры по матери
    by_mother = df1.merge(dssb_df[(dssb_df['ROLE'] == 'mother') & dssb_df['CHILD_IIN'].notnull()][['MOTHER_IIN', 'CHILD_IIN']].drop_duplicates(), on='MOTHER_IIN', how='left')
    # братья и сестры по отцу
    by_father = df1.merge(dssb_df[(dssb_df['ROLE'] == 'father') & dssb_df['CHILD_IIN'].notnull()][['FATHER_IIN', 'CHILD_IIN']].drop_duplicates(),on='FATHER_IIN', how='left')
    # Убираем дубли CHILD_IIN
    df1 = pd.concat([by_father, by_mother], axis=0).drop_duplicates()
    df1 = df1[df1['IIN'] != df1['CHILD_IIN']]
    df1['SPOUSE'] = df1.HUSBAND_IIN.combine_first(df1.WIFE_IIN)  # 1 колонка для супруг
    # убираем не нужные столбцы
    df1 = df1[['IIN', 'REAL_DPD_FL', 'MOTHER_IIN', 'FATHER_IIN', 'CHILD_IIN', 'SPOUSE']]
    df1.columns = ['IIN', 'REAL_DPD_FL', 'MOTHER_IIN', 'FATHER_IIN', 'SIBLINGS', 'SPOUSE']

# Работадатель
    workplace = f''' 
    select
        distinct r.iin, r.bik
    from DDS.GCVP_RES_DETAIL_FL r
    '''
    workplace_df = pd.DataFrame(edw_cur.execute(workplace))
    workplace_df.columns = ["IIN","BIK"]
    df1 = df1.merge(workplace_df, on='IIN', how='left')
    # Это у нас справочник по работодателям
    df1 = df1.drop_duplicates()
    iin_data = df1.replace({float('nan'): None}) # Данные которые будут заливаться в таблицу с иин

    fathers = dssb_df[(dssb_df['ROLE'] == 'father') & dssb_df['CHILD_IIN'].notnull()][['FATHER_IIN', 'CHILD_IIN']].drop_duplicates()
    mothers = dssb_df[(dssb_df['ROLE'] == 'mother') & dssb_df['CHILD_IIN'].notnull()][['MOTHER_IIN', 'CHILD_IIN']].drop_duplicates()
    fathers.columns = ['PARENT_IIN', 'CHILD_IIN']
    mothers.columns = ['PARENT_IIN', 'CHILD_IIN']
    concat = pd.concat([fathers, mothers]).drop_duplicates()
    del mothers, fathers
    concat['CHILD_AGE'] = concat['CHILD_IIN'].apply(calculate_age)
    concat = concat[concat['CHILD_AGE'] >= 18]
    concat = concat[concat.PARENT_IIN.isin(df1.IIN)]
    child_data = concat.replace({float('nan'): None}) #Данные которые будут заливаться в таблицу с детьми

    # Номера с ПКБ
    pkb_query= f''' 
    select /*+ parallel(12) */distinct f.iin, home_phone pkb_phone from dds.pkb_client_reports_fl f
    inner join (select iin, max(report_id) report_id from dds.Pkb_Client_Reports_Fl s
                    group by iin) s on s.report_id = f.report_id
    '''
    # Номера с ОСРМ
    ocrm_query = f''' 
    select /*+ parallel(12) */ distinct t2.iin_bin iin, t.communication_value ocrm_phone
    FROM DDS.OCRM_RB_SUBJECT_CONTACT_S T
    LEFT JOIN DDS.OCRM_RB_SUBJECT_S T2
        ON T2.DWH_ID = T.DWH_ID
        AND T2.IS_ACTUAL = 'A'
    WHERE T.IS_ACTUAL = 'A'
        and t.communication_type = 'Доверенный номер'
    '''
    # Номера с ЗАГСА
    gbd_query = f''' 
    select /*+ parallel(12)*/
        distinct 
        iin, 
        mobile zags_phone 
    from DSSB_OCDS.d$gdb_zags c
    where iin is not null
    and mobile is not null
    '''
    pkb_phone = pd.DataFrame(edw_cur.execute(pkb_query))
    pkb_phone.columns = ['IIN','PKB_PHONE']
    
    ocrm_phone = pd.DataFrame(edw_cur.execute(ocrm_query))
    ocrm_phone.columns = ['IIN','OCRM_PHONE']
    ocrm_phone.dropna(inplace=True)
    ocrm_phone = ocrm_phone.drop_duplicates(subset=['IIN'], keep='first')

    zags_phone = pd.DataFrame(dssbde_cur.execute(gbd_query))
    zags_phone.columns = ['IIN','ZAGS_PHONE']

    iins_total = concatenate_iin_columns(df1, concat)
    iins_total = iins_total.merge(pkb_phone, on='IIN', how='left')
    iins_total = iins_total.merge(ocrm_phone, on='IIN', how='left')
    iins_total = iins_total.merge(zags_phone, on='IIN', how='left')
    phone_data = iins_total.replace({float('nan'): None}) #Данные которые будут заливаться в таблицу с Номерами


    child_list = child_data.values.tolist()
    phones_list = phone_data.values.tolist()
    iin_list = iin_data.values.tolist()

    dssbde_cur.execute("select max(rep_date) from dssb_de.loan_sc_children")
    max_date_child = dssbde_cur.fetchone()[0].date()
    dssbde_cur.execute("select max(rep_date) from dssb_de.loan_sc_numbers")
    max_date_numbers = dssbde_cur.fetchone()[0].date()
    dssbde_cur.execute("select max(rep_date) from dssb_de.loan_sc_iin")
    max_date_iin = dssbde_cur.fetchone()[0].date()

    dssbde_cur.execute(
        f"delete from dssb_de.loan_sc_children where rep_date = date'{datetime.date.today() - datetime.timedelta(days=1)}' ")
    dssbde_conn.commit()
    dssbde_cur.executemany(
        f"insert into dssb_de.loan_sc_children (rep_date, is_actual, parent_iin, child_iin, child_age) values (date'{datetime.date.today() - datetime.timedelta(days=1)}', 'A',:1, :2, :3)",
        child_list)
    dssbde_conn.commit()
    dssbde_cur.execute(f"update dssb_de.loan_sc_children set is_actual = 'N' where rep_date = date'{max_date_child}'")
    dssbde_conn.commit()

    dssbde_cur.execute(
        f"delete from dssb_de.loan_sc_numbers where rep_date = date'{datetime.date.today() - datetime.timedelta(days=1)}' ")
    dssbde_conn.commit()
    dssbde_cur.executemany(
        f"insert into dssb_de.loan_sc_numbers (rep_date, is_actual, iin, pkb_phone, ocrm_phone, zags_phone) values (date'{datetime.date.today() - datetime.timedelta(days=1)}','A',:1, :2, :3, :4)",
        phones_list)
    dssbde_conn.commit()
    dssbde_cur.execute(f"update dssb_de.loan_sc_numbers set is_actual = 'N' where rep_date = date'{max_date_numbers}'")
    dssbde_conn.commit()

    dssbde_cur.execute(
        f"delete from dssb_de.loan_sc_iin where rep_date = date'{datetime.date.today() - datetime.timedelta(days=1)}' ")
    dssbde_conn.commit()
    dssbde_cur.executemany(
        f"insert into dssb_de.loan_sc_iin (rep_date,is_actual, iin, real_dpd_fl, mother_iin, father_iin, siblings, spouse, bik) values (date'{datetime.date.today() - datetime.timedelta(days=1)}','A',:1, :2, :3, :4, :5, :6, :7)",
        iin_list)
    dssbde_conn.commit()
    dssbde_cur.execute(f"update dssb_de.loan_sc_iin set is_actual = 'N' where rep_date = date'{max_date_iin}'")
    dssbde_conn.commit()
    dssbde_cur.close()
    dssbde_conn.close()

with DAG(
    dag_id="RB2_LOAN_SC_LIST",
    start_date=datetime.datetime(2024, 11, 6),
    schedule="0 10 * * 1",
    default_args=default_args,
) as dag:

    dssb_de_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE")
    edw_se_hook = OracleHook(oracle_conn_id="db_oracle_edw__edw_se", schema="EDW_SE") 

    kwargs = {"edw_se_hook": edw_se_hook,
              "dssb_de_hook": dssb_de_hook,
              }

    start_task = DummyOperator(task_id="start_task")

    check_data_ready_task = BranchPythonOperator(
        task_id="check_data_ready_task", python_callable=sql_check_task, op_kwargs=kwargs
    )

    wait_task = PythonOperator(
        task_id="wait_task",
        python_callable=lambda: time.sleep(60 * 15),
    )

    restart_task = TriggerDagRunOperator(
        task_id="restart_task",
        trigger_dag_id="RB2_LOAN_SC_LIST",
        reset_dag_run=True,
    )

    loan_sc_load = PythonOperator(
        task_id="loan_sc_load",
        python_callable=create_df,
        op_kwargs=kwargs,
        dag=dag,
    )

    end_task = DummyOperator(task_id="end_task")


    start_task >> check_data_ready_task
    check_data_ready_task >> loan_sc_load >> end_task
    check_data_ready_task >> wait_task >> restart_task 


