from datetime import datetime

import airflow
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.providers.oracle.operators.oracle import OracleOperator

from source.telegram_notifications import (
    TelegramErrorNotification,
    TelegramSuccessNotification,
)


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/dev_risk_xml/"
apps = dags + "apps/"

home_dir = apps + "RISK_CMD_CCE_XML/"
spark_files_dir = temp_dir

spark_default_conf = {
    "spark.master": "yarn",
    "spark.submit.deployMode": "cluster",
    "spark.yarn.queue": "dm",
    "spark.driver.maxResultSize": "0",
    "spark.rpc.message.maxSize": "1024",
    "spark.hadoop.yarn.timeline-service.enabled": False,
    "spark.local.dir": spark_files_dir,
}

default_args = {
    "owner": "NikitaMi",
    "email": ["NikitaMi@halykbank.kz", "AlibekDz@halykbank.kz", "AiysulySH@halykbank.kz"],
    "email_on_failure": True,
    "start_date": datetime(2023, 6, 4),
    "on_failure_callback": [TelegramErrorNotification()],
}

alibek_app_py_files_2 = str(
    home_dir
    + "py_files_2/Schemas.zip,"
    + home_dir
    + "py_files_2/Mappers.zip,"
    + home_dir
    + "py_files_2/Parsers.zip,"
    + home_dir
    + "py_files_2/Oracle_configs.zip,"
    + home_dir
    + "py_files_2/Logging.zip,"
    + home_dir
    + "py_files_2/Writers.zip"
)


def spark_submit_generator(
    name,
    app_name,
    executor_memory="18G",
    driver_memory="24G",
    trigger_rule="all_success",
    app_py_files=str(
        home_dir
        + "py-files/Schemas.zip,"
        + home_dir
        + "py-files/Mappers.zip,"
        + home_dir
        + "py-files/Parsers.zip,"
        + home_dir
        + "py-files/Oracle_configs.zip,"
        + home_dir
        + "py-files/Logging.zip,"
        + home_dir
        + "py-files/Writers.zip"
    ),
):
    return SparkSubmitOperator(
        task_id=str(name),
        conn_id="spark_default",
        application=home_dir + "app_folder/" + str(app_name + ".py"),
        executor_memory=executor_memory,
        driver_memory=driver_memory,
        num_executors=8,
        principal="ADH_Runner_CDO@HALYKBANK.NB",
        keytab="/opt/airflow/config/credentials/hadoop/krb5.keytab",
        py_files=app_py_files,
        name=name,
        jars=home_dir + "ojdbc8-21.1.0.0.jar",
        verbose=True,
        conf=spark_default_conf,
        trigger_rule=trigger_rule,
    )


def bash_sleep_generator(name, trigger_rule="all_success", length="1m"):
    return BashOperator(task_id=str(name), bash_command="sleep " + length, trigger_rule=trigger_rule)


def oracle_operator_generator(name, path, trigger_rule="all_done"):
    return OracleOperator(
        task_id=str(name), oracle_conn_id="EDW_ETL_CDO", sql=str(path), autocommit=True, trigger_rule=trigger_rule
    )


def truncate_partion(name):
    query = """
        DECLARE
            extract_date DATE;
            table_list SYS.ODCIVARCHAR2LIST;
        BEGIN
            SELECT
                OPER_DATE 
            INTO 
                extract_date
            FROM
    	        RISKDM.AIRFLOW_ETL_DATA
            WHERE
                DAG_NAME = 'EDW_CMD_RISKDM'
                AND STATUS = 'WAITING';

            table_list := SYS.ODCIVARCHAR2LIST(
                'CMD_CCE_ACCOUNT_DEBT_FL',
                'CMD_CCE_APPLICATION_FIELDS_FL',
                'CMD_CCE_APPLICATION_PKB_L',
                'CMD_CCE_AUTO_INFO_FL',
                'CMD_CCE_BANKRUPTCY_FL',
                'CMD_CCE_CLIENT_ITEM_FL',
                'CMD_CCE_COMPANY_ITEM_FL',
                'CMD_CCE_CONDITIONS_FL',
                'CMD_CCE_CONTACT_PHONE_FL',
                'CMD_CCE_FCB_EXISTINGCONTRACTS_FL',
                'CMD_CCE_FCB_TERMINATEDCONTRACTS_FL',
                'CMD_CCE_FEE_SUM_OW_FL',
                'CMD_CCE_GARANTEEINFO_FL',
                'CMD_CCE_GBDRNREPORT305_FL',
                'CMD_CCE_GBDRNREPORT306_FL',
                'CMD_CCE_GTSVP_SRD_FL',
                'CMD_CCE_INTERNALCREDITHISTORY_SRD_FL',
                'CMD_CCE_INTERNAL_DELINQUENCY_ACCOUNTS_FL',
                'CMD_CCE_INTERNAL_DELINQUENCY_RESPONSE_DATA_FL',
                'CMD_CCE_MOBILE_ITEM_FL',
                'CMD_CCE_MOBILE_PHONE_FL',
                'CMD_CCE_PARAMETER_SET_FL',
                'CMD_CCE_PERSON_DOC_FL',
                'CMD_CCE_POV_CLIENT_FL',
                'CMD_CCE_POV_DEVICE_FL',
                'CMD_CCE_PROCESSES_ITEMS_FL',
                'CMD_CCE_PROCESSES_PARCED_DATA_FL',
                'CMD_CCE_PROCESSES_PARCED_FL',
                'CMD_CCE_PROCESS_INFO_FL',
                'CMD_CCE_RATE_FL',
                'CMD_CCE_SDK_INFO_FL',
                'CMD_CCE_SERVICE_DATA_FL',
                'CMD_CCE_VERIFICATIONS_FL',
                'CMD_CCE_VERIFICATION_ANSWERS_FL',
                'CMD_CCE_VERIFICATION_FIELDS_FL',
                'CMD_CCE_VERIFICATION_SET_FL',
                'CMD_CCE_OFFERS_XML_FL'
            );

            FOR i IN 1 .. table_list.COUNT LOOP
                DDS.TRUNCATE_PARTITION_CDO_P(table_list(i),TO_CHAR(extract_date, 'YYYYMMDD'));
            END LOOP;
        END;    
        """
    return OracleOperator(task_id=str(name), oracle_conn_id="EDW_ETL_CDO", sql=query, autocommit=True)


with airflow.DAG(
    dag_id="EDW_LOADER_CMD_CCE_XML",
    tags=["EDW_LOADER", "CMD", "DDS", "EDW", "SPARK", "ODS"],
    default_args=default_args,
    schedule_interval="0 2 * * *",
    # schedule_interval='@once',
    description="Парсинг и загрузка данных процесса кредитования в ХД",
    catchup=False,
) as dag_spark:
    risk_cmd_st1: SparkSubmitOperator = spark_submit_generator(name="risk_cmd_st1", app_name="risk_cmd_st1")
    risk_cmd_st1_items_a: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st1_items_a", app_name="risk_cmd_st1_items"
    )
    risk_cmd_st1_items_b: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st1_items_b",
        app_name="risk_cmd_st1_items",
        driver_memory="24g",
        executor_memory="24g",
        trigger_rule="one_failed",
    )
    risk_cmd_st2_cond: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_cond", app_name="risk_cmd_st2_cond", trigger_rule="all_done"
    )
    risk_cmd_st2_person_doc: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_person_doc", app_name="risk_cmd_st2_person_doc", trigger_rule="all_done"
    )

    RISK_CMD_ST2_PARAMETER_SET: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_PARAMETER_SET",
        app_name="RISK_CMD_ST2_PARAMETER_SET",
        driver_memory="72g",
        executor_memory="48g",
        app_py_files=alibek_app_py_files_2,
    )
    RISK_CMD_ST2_VERIFICATIONS: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_VERIFICATIONS",
        app_name="RISK_CMD_ST2_VERIFICATIONS",
        driver_memory="36g",
        executor_memory="36g",
        trigger_rule="all_done",
        app_py_files=alibek_app_py_files_2,
    )
    RISK_CMD_ST2_PROCESS_AGG: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_PROCESS_AGG",
        app_name="RISK_CMD_ST2_PROCESS_AGG",
        trigger_rule="all_done",
        app_py_files=alibek_app_py_files_2,
    )
    RISK_CMD_ST2_PROCESS_AGG_2: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_PROCESS_AGG_2",
        app_name="RISK_CMD_ST2_PROCESS_AGG_2",
        trigger_rule="all_done",
        app_py_files=alibek_app_py_files_2,
    )
    RISK_CMD_ST2_RISKLIST_ITEMS: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_RISKLIST_ITEMS",
        app_name="RISK_CMD_ST2_RISKLIST_ITEMS",
        trigger_rule="all_done",
        app_py_files=alibek_app_py_files_2,
    )
    risk_cmd_st2_fcb: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_fcb", app_name="risk_cmd_st2_fcb", trigger_rule="all_done"
    )
    risk_cmd_st2_process_info: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_process_info", app_name="risk_cmd_st2_process_info", trigger_rule="all_done"
    )
    risk_cmd_st2_skdinfo: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_skdinfo", app_name="risk_cmd_st2_skdinfo", trigger_rule="all_done"
    )
    risk_cmd_st2_srd: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_srd", app_name="risk_cmd_st2_srd", trigger_rule="all_done"
    )
    risk_cmd_st2_srd_2: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_st2_srd_2", app_name="risk_cmd_st2_srd_2", trigger_rule="all_done"
    )
    RISK_CMD_ST2_APPLICATION_LINK: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_APPLICATION_LINK",
        app_name="RISK_CMD_ST2_APPLICATION_LINK",
        trigger_rule="all_done",
        app_py_files=alibek_app_py_files_2,
    )
    RISK_CMD_ST2_GRNT: SparkSubmitOperator = spark_submit_generator(
        name="RISK_CMD_ST2_GRNT",
        app_name="RISK_CMD_ST2_GRNT",
        trigger_rule="all_done",
        app_py_files=alibek_app_py_files_2,
    )
    risk_cmd_offers: SparkSubmitOperator = spark_submit_generator(
        name="risk_cmd_offers", 
        app_name="risk_cmd_offers",
        driver_memory="28g",
        executor_memory="24g",
        trigger_rule="all_done"
    )

    # App_F1
    AppF_1: OracleOperator = oracle_operator_generator(name="AppF_1", path="sql/Application_Fields/AppF_1.sql")
    AppF_2: OracleOperator = oracle_operator_generator(name="AppF_2", path="sql/Application_Fields/AppF_2.sql")
    AppF_3: OracleOperator = oracle_operator_generator(name="AppF_3", path="sql/Application_Fields/AppF_3.sql")
    AppF_4: OracleOperator = oracle_operator_generator(name="AppF_4", path="sql/Application_Fields/AppF_4.sql")
    AppF_5: OracleOperator = oracle_operator_generator(name="AppF_5", path="sql/Application_Fields/AppF_5.sql")
    AppF_6: OracleOperator = oracle_operator_generator(name="AppF_6", path="sql/Application_Fields/AppF_6.sql")

    CMD_CCE_PROCESSES_ITEMS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_PROCESSES_ITEMS_FL", path="sql/CMD_CCE_PROCESSES_ITEMS_FL.sql"
    )
    CMD_CCE_PROCESSES_PARCED_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_PROCESSES_PARCED_FL", path="sql/CMD_CCE_PROCESSES_PARCED_FL.sql"
    )
    CMD_CCE_VERIFICATION_SET_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_VERIFICATION_SET_FL", path="sql/CMD_CCE_VERIFICATION_SET_FL.sql"
    )
    CMD_CCE_AUTO_INFO_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_AUTO_INFO_FL", path="sql/CMD_CCE_AUTO_INFO_FL.sql"
    )
    CMD_CCE_CONDITIONS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_CONDITIONS_FL", path="sql/CMD_CCE_CONDITIONS_FL.sql"
    )
    CMD_CCE_FEE_SUM_OW_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_FEE_SUM_OW_FL", path="sql/CMD_CCE_FEE_SUM_OW_FL.sql"
    )
    CMD_CCE_PERSON_DOC_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_PERSON_DOC_FL", path="sql/CMD_CCE_PERSON_DOC_FL.sql"
    )
    CMD_CCE_PROCESSES_PARCED_DATA_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_PROCESSES_PARCED_DATA_FL", path="sql/CMD_CCE_PROCESSES_PARCED_DATA_FL.sql"
    )

    CMD_CCE_CLIENT_ITEM_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_CLIENT_ITEM_FL", path="sql/CMD_CCE_CLIENT_ITEM_FL.sql"
    )
    CMD_CCE_COMPANY_ITEM_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_COMPANY_ITEM_FL", path="sql/CMD_CCE_COMPANY_ITEM_FL.sql"
    )
    CMD_CCE_CONTACT_PHONE_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_CONTACT_PHONE_FL", path="sql/CMD_CCE_CONTACT_PHONE_FL.sql"
    )
    CMD_CCE_MOBILE_ITEM_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_MOBILE_ITEM_FL", path="sql/CMD_CCE_MOBILE_ITEM_FL.sql"
    )
    CMD_CCE_MOBILE_PHONE_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_MOBILE_PHONE_FL", path="sql/CMD_CCE_MOBILE_PHONE_FL.sql"
    )
    CMD_CCE_PARAMETER_SET_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_PARAMETER_SET_FL", path="sql/CMD_CCE_PARAMETER_SET_FL.sql"
    )
    CMD_CCE_POV_DEVICE_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_POV_DEVICE_FL", path="sql/CMD_CCE_POV_DEVICE_FL.sql"
    )
    CMD_CCE_VERIFICATION_ANSWERS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_VERIFICATION_ANSWERS_FL", path="sql/CMD_CCE_VERIFICATION_ANSWERS_FL.sql"
    )
    CMD_CCE_VERIFICATION_FIELDS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_VERIFICATION_FIELDS_FL", path="sql/CMD_CCE_VERIFICATION_FIELDS_FL.sql"
    )
    CMD_CCE_VERIFICATIONS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_VERIFICATIONS_FL", path="sql/CMD_CCE_VERIFICATIONS_FL.sql"
    )
    CMD_CCE_ACCOUNT_DEBT_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_ACCOUNT_DEBT_FL", path="sql/CMD_CCE_ACCOUNT_DEBT_FL.sql"
    )
    CMD_CCE_RATE_FL: OracleOperator = oracle_operator_generator(name="CMD_CCE_RATE_FL", path="sql/CMD_CCE_RATE_FL.sql")
    CMD_CCE_SDK_INFO_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_SDK_INFO_FL", path="sql/CMD_CCE_SDK_INFO_FL.sql"
    )
    CMD_CCE_SERVICE_DATA_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_SERVICE_DATA_FL", path="sql/CMD_CCE_SERVICE_DATA_FL.sql"
    )
    CMD_CCE_FCB_TERMINATEDCONTRACTS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_FCB_TERMINATEDCONTRACTS_FL", path="sql/CMD_CCE_FCB_TERMINATEDCONTRACTS_FL.sql"
    )
    CMD_CCE_FCB_EXISTINGCONTRACTS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_FCB_EXISTINGCONTRACTS_FL", path="sql/CMD_CCE_FCB_EXISTINGCONTRACTS_FL.sql"
    )
    CMD_CCE_PROCESS_INFO_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_PROCESS_INFO_FL", path="sql/CMD_CCE_PROCESS_INFO_FL.sql"
    )
    CMD_CCE_BASEX_RESPONSE_DATA_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_BASEX_RESPONSE_DATA_FL", path="sql/CMD_CCE_BASEX_RESPONSE_DATA_FL.sql"
    )
    CMD_CCE_SALARY_RESPONSE_DATA_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_SALARY_RESPONSE_DATA_FL", path="sql/CMD_CCE_SALARY_RESPONSE_DATA_FL.sql"
    )
    CMD_CCE_INTERNAL_DELINQUENCY_RESPONSE_DATA_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_INTERNAL_DELINQUENCY_RESPONSE_DATA_FL",
        path="sql/CMD_CCE_INTERNAL_DELINQUENCY_RESPONSE_DATA_FL.sql",
    )
    CMD_CCE_INTERNAL_DELINQUENCY_ACCOUNTS_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_INTERNAL_DELINQUENCY_ACCOUNTS_FL", path="sql/CMD_CCE_INTERNAL_DELINQUENCY_ACCOUNTS_FL.sql"
    )
    CMD_CCE_GTSVP_SRD_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_GTSVP_SRD_FL", path="sql/CMD_CCE_GTSVP_SRD_FL.sql"
    )
    CMD_CCE_INTERNALCREDITHISTORY_SRD_FL: OracleOperator = oracle_operator_generator(
        name="CMD_CCE_INTERNALCREDITHISTORY_SRD_FL", path="sql/CMD_CCE_INTERNALCREDITHISTORY_SRD_FL.sql"
    )

    risk_cmd_st2_fcb_delay = bash_sleep_generator(name="risk_cmd_st2_fcb_delay", trigger_rule="all_done")
    risk_cmd_st2_process_info_delay = bash_sleep_generator(
        name="risk_cmd_st2_process_info_delay", trigger_rule="all_done"
    )

    risk_cmd_st2_skdinfo_delay = bash_sleep_generator(name="risk_cmd_st2_skdinfo_delay", trigger_rule="all_done")
    risk_cmd_st2_srd_delay = bash_sleep_generator(name="risk_cmd_st2_srd_delay", trigger_rule="all_done")
    risk_cmd_st1_delay = bash_sleep_generator(name="risk_cmd_st1_delay", trigger_rule="all_done")
    risk_cmd_st1_items_delay = bash_sleep_generator(name="risk_cmd_st1_items_delay", trigger_rule="all_done")
    risk_cmd_st2_cond_delay = bash_sleep_generator(name="risk_cmd_st2_cond_delay", trigger_rule="all_done")
    risk_cmd_st2_person_doc_delay = bash_sleep_generator(name="risk_cmd_st2_person_doc_delay", trigger_rule="all_done")
    RISK_CMD_ST2_PARAMETER_SET_delay = bash_sleep_generator(
        name="RISK_CMD_ST2_PARAMETER_SET_delay", trigger_rule="all_done"
    )
    RISK_CMD_ST2_PROCESS_AGG_delay = bash_sleep_generator(
        name="RISK_CMD_ST2_PROCESS_AGG_delay", trigger_rule="all_done"
    )
    RISK_CMD_ST2_PROCESS_AGG_2_delay = bash_sleep_generator(
        name="RISK_CMD_ST2_PROCESS_AGG_2_delay", trigger_rule="all_done"
    )
    RISK_CMD_ST2_RISKLIST_ITEMS_delay = bash_sleep_generator(
        name="RISK_CMD_ST2_RISKLIST_ITEMS_delay", trigger_rule="all_done"
    )
    RISK_CMD_ST2_VERIFICATIONS_delay = bash_sleep_generator(
        name="RISK_CMD_ST2_VERIFICATIONS_delay", trigger_rule="all_done"
    )

    # Preparer
    DATA_PREPARER_UPDATE: OracleOperator = oracle_operator_generator(
        name="DATA_PREPARER_UPDATE", path="sql/DATA_PREPARER_UPDATE.sql", trigger_rule="all_success"
    )
    DATA_PREPARER_INSERT: OracleOperator = oracle_operator_generator(
        name="DATA_PREPARER_INSERT", path="sql/DATA_PREPARER_INSERT.sql", trigger_rule="all_success"
    )

    start: EmptyOperator = EmptyOperator(task_id="start")
    preparer: EmptyOperator = EmptyOperator(task_id="preparer")
    end: EmptyOperator = EmptyOperator(
        task_id="end",
        on_success_callback=[TelegramSuccessNotification()],
    )
    truncate_partion: OracleOperator = truncate_partion(name='trunc_task')

start >> truncate_partion

truncate_partion >> risk_cmd_st1 >> risk_cmd_st1_delay
truncate_partion >> risk_cmd_st1_items_a >> risk_cmd_st1_items_delay
truncate_partion >> RISK_CMD_ST2_PARAMETER_SET
truncate_partion >> risk_cmd_offers >> preparer

risk_cmd_st1_delay >> risk_cmd_st2_cond
risk_cmd_st1_delay >> CMD_CCE_VERIFICATION_SET_FL >> preparer
risk_cmd_st1_delay >> CMD_CCE_PROCESSES_PARCED_FL >> preparer

risk_cmd_st2_cond_delay >> CMD_CCE_PROCESSES_PARCED_DATA_FL >> preparer
risk_cmd_st2_cond_delay >> CMD_CCE_CONDITIONS_FL >> preparer

risk_cmd_st2_cond_delay >> risk_cmd_st2_fcb >> risk_cmd_st2_fcb_delay
risk_cmd_st2_fcb_delay >> CMD_CCE_FCB_TERMINATEDCONTRACTS_FL >> preparer
risk_cmd_st2_fcb_delay >> CMD_CCE_FCB_EXISTINGCONTRACTS_FL >> preparer

risk_cmd_st2_fcb_delay >> risk_cmd_st2_process_info >> risk_cmd_st2_process_info_delay
risk_cmd_st2_process_info_delay >> RISK_CMD_ST2_APPLICATION_LINK >> preparer
risk_cmd_st2_process_info_delay >> CMD_CCE_PROCESS_INFO_FL >> preparer
risk_cmd_st2_process_info_delay >> RISK_CMD_ST2_GRNT >> preparer

risk_cmd_st2_cond >> risk_cmd_st2_cond_delay

risk_cmd_st1_items_a >> risk_cmd_st1_items_b >> risk_cmd_st1_items_delay

risk_cmd_st1_items_delay >> risk_cmd_st2_person_doc
risk_cmd_st1_items_delay >> CMD_CCE_PROCESSES_ITEMS_FL >> preparer

risk_cmd_st2_person_doc >> risk_cmd_st2_person_doc_delay

risk_cmd_st2_person_doc_delay >> risk_cmd_st2_skdinfo >> risk_cmd_st2_skdinfo_delay
risk_cmd_st2_skdinfo_delay >> CMD_CCE_ACCOUNT_DEBT_FL >> preparer
risk_cmd_st2_skdinfo_delay >> CMD_CCE_RATE_FL >> preparer
risk_cmd_st2_skdinfo_delay >> CMD_CCE_SDK_INFO_FL >> preparer
risk_cmd_st2_skdinfo_delay >> CMD_CCE_SERVICE_DATA_FL >> preparer

risk_cmd_st2_skdinfo_delay >> risk_cmd_st2_srd >> risk_cmd_st2_srd_2 >> risk_cmd_st2_srd_delay
risk_cmd_st2_srd_delay >> CMD_CCE_BASEX_RESPONSE_DATA_FL >> preparer
risk_cmd_st2_srd_delay >> CMD_CCE_SALARY_RESPONSE_DATA_FL >> preparer
risk_cmd_st2_srd_delay >> CMD_CCE_INTERNAL_DELINQUENCY_RESPONSE_DATA_FL >> preparer
risk_cmd_st2_srd_delay >> CMD_CCE_INTERNAL_DELINQUENCY_ACCOUNTS_FL >> preparer
risk_cmd_st2_srd_delay >> CMD_CCE_GTSVP_SRD_FL >> preparer
risk_cmd_st2_srd_delay >> CMD_CCE_INTERNALCREDITHISTORY_SRD_FL >> preparer

risk_cmd_st2_person_doc_delay >> CMD_CCE_AUTO_INFO_FL >> preparer
risk_cmd_st2_person_doc_delay >> CMD_CCE_FEE_SUM_OW_FL >> preparer
risk_cmd_st2_person_doc_delay >> CMD_CCE_PERSON_DOC_FL >> preparer

RISK_CMD_ST2_PARAMETER_SET >> RISK_CMD_ST2_PARAMETER_SET_delay >> CMD_CCE_PARAMETER_SET_FL >> preparer
(
    RISK_CMD_ST2_PARAMETER_SET_delay
    >> RISK_CMD_ST2_VERIFICATIONS
    >> RISK_CMD_ST2_VERIFICATIONS_delay
    >> [CMD_CCE_VERIFICATIONS_FL, CMD_CCE_VERIFICATION_FIELDS_FL, CMD_CCE_VERIFICATION_ANSWERS_FL]
    >> preparer
)
(
    RISK_CMD_ST2_VERIFICATIONS_delay
    >> RISK_CMD_ST2_PROCESS_AGG
    >> RISK_CMD_ST2_PROCESS_AGG_delay
    >> [CMD_CCE_CONTACT_PHONE_FL, CMD_CCE_POV_DEVICE_FL]
    >> preparer
)
(
    RISK_CMD_ST2_PROCESS_AGG_delay
    >> RISK_CMD_ST2_PROCESS_AGG_2
    >> RISK_CMD_ST2_PROCESS_AGG_2_delay
    >> CMD_CCE_MOBILE_PHONE_FL
    >> preparer
)
RISK_CMD_ST2_PROCESS_AGG_2_delay >> AppF_1 >> AppF_2 >> AppF_3 >> AppF_4 >> AppF_5 >> AppF_6 >> preparer
(
    RISK_CMD_ST2_PROCESS_AGG_2_delay
    >> RISK_CMD_ST2_RISKLIST_ITEMS
    >> RISK_CMD_ST2_RISKLIST_ITEMS_delay
    >> [CMD_CCE_COMPANY_ITEM_FL, CMD_CCE_MOBILE_ITEM_FL, CMD_CCE_CLIENT_ITEM_FL]
    >> preparer
)

preparer >> DATA_PREPARER_UPDATE >> DATA_PREPARER_INSERT >> end
