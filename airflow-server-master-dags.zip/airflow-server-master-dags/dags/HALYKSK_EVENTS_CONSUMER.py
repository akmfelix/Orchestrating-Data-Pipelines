import datetime as dt
import json
import logging
import typing

import oracledb
import pendulum
from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition

from source.telegram_notifications import TelegramErrorNotification


logger = logging.getLogger(__name__)

default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

columns = (
    "EVENT_DATE",
    "EVENT_TIME",
    "LAYER",
    "EVENT_NAME",
    "POLICY_TYPE",
    "INVOICE_NUMBER",
    "AMOUNT",
    "PRODUCT",
    "PAY_METHOD",
    "SUCCESS",
    "ERROR",
    "PATH",
    "ID",
    "FIRST_NAME",
    "LAST_NAME",
    "PHONE",
    "OS",
    "UA",
    "IIN",
)


def transforms(message_dict: dict, message_timestamp: int) -> typing.Tuple[typing.Any, ...]:
    data = list(message_dict.values())[0].get("data", {})

    event_time = dt.datetime.fromtimestamp(message_timestamp / 1000)  # Kafka stores time in UTC
    event_time = event_time.astimezone(pendulum.timezone("Asia/Oral"))  # Localize UTC time
    event_date = event_time.date()

    layer = None
    event_name = None
    policy_type = None
    invoice_number = None
    amount = None
    product = None
    pay_method = None
    success = None
    error = None
    path = None
    id_ = None
    first_name = None
    last_name = None
    phone = None
    os = None
    ua = None
    iin = None

    if data:
        layer = data.get("layer")
        event_name = data.get("event_name")
        event_data = data.get("event_data")
        if event_data:
            policy_type = event_data.get("policy_type")
            invoice_number = event_data.get("invoice_number")
            amount = event_data.get("amount")
            product = event_data.get("product")
            pay_method = event_data.get("pay_method")
            success = event_data.get("success")
            if isinstance(success, bool):
                success = str(success)

            error_dict = event_data.get("error")
            if error_dict:
                error = error_dict.get("error")
                path = error_dict.get("path")

        event_info = data.get("event_info")
        if event_info:
            user = event_info.get("user")
            if user:
                id_ = user.get("id")
                first_name = user.get("first_name")
                last_name = user.get("last_name")
                phone = user.get("phone")
                iin = user.get("iin")
            device = event_info.get("device")
            if device:
                os = device.get("os")
                ua = device.get("ua")

    return (
        event_date,
        event_time,
        layer,
        event_name,
        policy_type,
        invoice_number,
        amount,
        product,
        pay_method,
        success,
        error,
        path,
        id_,
        first_name,
        last_name,
        phone,
        os,
        ua,
        iin,
    )


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deserialize_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    target_cols: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(target_cols)) if target_cols else "",
        values=", ".join(f":{i}" for i in range(1, len(target_cols) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.setinputsizes(
            oracledb.DB_TYPE_DATE,
            oracledb.DB_TYPE_DATE,
            50,
            200,
            200,
            100,
            oracledb.DB_TYPE_NUMBER,
            150,
            50,
            50,
            512,
            256,
            oracledb.DB_TYPE_NUMBER,
            100,
            100,
            oracledb.DB_TYPE_NUMBER,
            100,
            100,
            180,
        )
        try:
            cursor.executemany(None, data, batcherrors=True)
        except Exception as e:
            print(e)
            print(data)
            for error in cursor.getbatcherrors():
                print(error.message)
                print(data[error.offset])
            raise e
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    topics: typing.List[str],
    oracle_hook: OracleHook,
    consumer_config: dict,
    table_name: str,
    target_columns: typing.Tuple[str, ...],
    batch_size: int,
    poll_timeout: float = 3.0,
    threshold: int = 0,
) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe(topics, on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages and len(consumed_messages) >= threshold:
                logger.info(f"Consumed {len(consumed_messages)} messages")
                data = list(
                    transforms(deserialize_message(m), m.timestamp()[1])
                    for m in consumed_messages
                    if m is not None  # and m.error() is None  # collect errors in a separate tuple
                )
                bulk_insert(
                    oracle_conn=connection,
                    data=data,
                    table_name=table_name,
                    target_cols=target_columns,
                )
                consumer.commit()
            else:
                logger.info(f"There are no more messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    dag_id="HALYKSK_EVENTS_CONSUMER",
    default_args=default_args,
    description="A DAG that reads Halyk SK-related events from the 'DAF_EVENTS_SK' topic and writes them to the DSSB DB",
    schedule="@hourly",
    start_date=pendulum.datetime(2024, 9, 27),
    catchup=False,
    max_active_runs=1,
    tags=["consumer", "kafka"],
):
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)
    kafka_config_id = "kafka_oper_prod__tribe_ecosystem_reader"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)
    consumer_config["group.id"] = f"{consumer_config['group.id']}_TEST_GROUP"

    table_name = "DSSB_DE.EVENTS_HALYK_SK2"

    kwargs = {
        "topics": ["DAF_EVENTS_SK"],
        "oracle_hook": oracle_hook,
        "consumer_config": consumer_config,
        "table_name": table_name,
        "target_columns": columns,
        "batch_size": 25_000,
        "threshold": 25_000,
        "poll_timeout": 5.0,
    }

    consume_and_write_task = PythonOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        python_callable=consume_and_write,
        op_kwargs=kwargs,
        on_failure_callback=[TelegramErrorNotification()],
    )
    consume_and_write_task
