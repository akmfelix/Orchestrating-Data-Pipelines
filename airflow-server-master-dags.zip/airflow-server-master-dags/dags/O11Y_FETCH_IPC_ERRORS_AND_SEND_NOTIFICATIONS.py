from datetime import datetime, timedelta
from textwrap import TextWrapper, dedent
from typing import Tuple

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook

from source.telegram_notifier import TelegramNotifier


default_args = {
    "depends_on_past": False,
    "start_date": datetime(2024, 7, 17),
    "retries": 1,
    "retry_delay": timedelta(minutes=15),
    "owner": "AlibekDz",
}


def format_message(wrapper: TextWrapper, repo_name: str, task_name: str, err_message: str) -> str:
    err_message = wrapper.fill(dedent(err_message))
    return f"🛠️ Процесс — <b>{task_name}</b> из репозитория — <b>{repo_name}</b> упал с ошибкой:\n<code>{err_message}</code>"


def fetch_error_tuples(oracle_hook: OracleHook, sql_statement: str) -> Tuple[str, str, str]:
    connection = oracle_hook.get_conn()
    with connection.cursor() as cursor:
        result_set = cursor.execute(sql_statement).fetchall()
    connection.close()
    return result_set


def check_and_alert(**context):
    bot_token = context["var"]["value"].get("telegram_bot_token")
    chat_id = context["var"]["value"].get("telegram_notifications_chat_id")
    proxies = {
        "http": context["var"]["value"].get("http_proxy"),
        "https": context["var"]["value"].get("https_proxy"),
    }

    notifier = TelegramNotifier(bot_token=bot_token, chat_id=chat_id)
    wrapper = TextWrapper(width=24, initial_indent="> ", subsequent_indent="> ", max_lines=6, replace_whitespace=True)

    ipc_errors_fetching_sql = """
            SELECT 'EDW_IPC' AS task_rep
            , task_name
            , RUN_ERR_MSG   as msg
        FROM edw_ipc.OPB_TASK_INST_RUN
        WHERE ((to_number(to_char(SYSDATE, 'HH24')) <= 6
                    AND START_TIME < TRUNC(SYSDATE) + INTERVAL '6' HOUR
                    AND  START_TIME >= TRUNC(SYSDATE))
                    OR (to_number(to_char(SYSDATE, 'HH24')) > 6
                    AND START_TIME >= TRUNC(SYSDATE) + INTERVAL '6' HOUR
                    AND  TRUNC(START_TIME) <= TRUNC(SYSDATE)))
        AND RUN_STATUS_CODE IN (3, 15)
        UNION
        SELECT 'ACRM_REP'  AS task_rep
            , task_name
            , RUN_ERR_MSG as msg
        FROM ACRM_REP.OPB_TASK_INST_RUN
        WHERE ((to_number(to_char(SYSDATE, 'HH24')) <= 6
                    AND START_TIME < TRUNC(SYSDATE) + INTERVAL '6' HOUR
                    AND  START_TIME >= TRUNC(SYSDATE))
                    OR (to_number(to_char(SYSDATE, 'HH24')) > 6
                    AND START_TIME >= TRUNC(SYSDATE) + INTERVAL '6' HOUR
                    AND  TRUNC(START_TIME) <= TRUNC(SYSDATE)))
        AND RUN_STATUS_CODE IN (3, 15)
        UNION
        SELECT 'SB_REP'    AS task_rep
            , task_name
            , RUN_ERR_MSG as msg
        FROM RB_REP.OPB_TASK_INST_RUN
        WHERE ((to_number(to_char(SYSDATE, 'HH24')) <= 6
                    AND START_TIME < TRUNC(SYSDATE) + INTERVAL '6' HOUR
                    AND  START_TIME >= TRUNC(SYSDATE))
                    OR (to_number(to_char(SYSDATE, 'HH24')) > 6
                    AND START_TIME >= TRUNC(SYSDATE) + INTERVAL '6' HOUR
                    AND  TRUNC(START_TIME) <= TRUNC(SYSDATE)))
        AND RUN_STATUS_CODE IN (3, 15)
        AND WORKFLOW_ID IN (311, 4305, 4426, 4709)
    """
    ipc_errors = fetch_error_tuples(
        OracleHook(oracle_conn_id="db_oracle_ipc__edw_ipc", thick_mode=True), ipc_errors_fetching_sql
    )
    workflow_errors_fetching_sql = """
            SELECT     WFSTAT.POW_WORKFLOWDEFINITIONNAM AS WF_NAME,
               REQSTAT.POR_OBJECTNAME AS TASK_NAME,
               TO_CHAR(REQSTAT.POR_MESSAGE) AS MSG
    FROM INFA_MRS_MON_HK.PO_REQUESTSTAT REQSTAT
    LEFT JOIN INFA_MRS_MON_HK.PO_TASKSTAT TASKSTAT ON REQSTAT.POR_PARENTSTATID = TASKSTAT.POT_STATID
    LEFT JOIN INFA_MRS_MON_HK.PO_WORKFLOWSTAT WFSTAT ON TASKSTAT.POT_PARENTSTATID = WFSTAT.POW_STATID
    WHERE REQSTAT.POR_SERVICENAME = 'DIS_DEI_PROD_HALYKBANK' 
           AND WFSTAT.POW_WORKFLOWDEFINITIONNAM IN ('wf_DAILY_LOAD_RISKDM_RSLOAN', 'wf_DAILY_LOAD_RISKDM_CARD', 'wf_DAILY_LOAD_RISKDM_SCORING', 'wf_DAILY_LOAD_RISKDM_DEPOSIT', 'wf_DAILY_LOAD_RISKDM_ONLINE') 
           AND REQSTAT.POR_STATE = 2
           AND TO_CHAR(REQSTAT.POR_MESSAGE) != 'No errors encountered.'
           AND ( (to_number(to_char(SYSDATE, 'HH24')) <= 6
            AND (TO_DATE('1970-01-01', 'YYYY-MM-DD')+(WFSTAT.POW_STARTTIME / 1000)/(60 * 60 * 24)) < TRUNC(SYSDATE) + INTERVAL '6' HOUR
            AND  (TO_DATE('1970-01-01', 'YYYY-MM-DD')+(WFSTAT.POW_STARTTIME / 1000)/(60 * 60 * 24)) >= TRUNC(SYSDATE))
            OR (to_number(to_char(SYSDATE, 'HH24')) > 6
            AND (TO_DATE('1970-01-01', 'YYYY-MM-DD')+(WFSTAT.POW_STARTTIME / 1000)/(60 * 60 * 24)) >= TRUNC(SYSDATE) + INTERVAL '6' HOUR
            AND  TRUNC(TO_DATE('1970-01-01', 'YYYY-MM-DD')+(WFSTAT.POW_STARTTIME / 1000)/(60 * 60 * 24)) <= TRUNC(SYSDATE)))
        """
    workflow_errors = fetch_error_tuples(
        OracleHook(oracle_conn_id="ETL_REP", thick_mode=True), workflow_errors_fetching_sql
    )

    for repo_name, task_name, err_message in ipc_errors + workflow_errors:
        message = format_message(wrapper, repo_name, task_name, err_message)
        response = notifier.send_message(message, proxies)


with DAG(
    dag_id="O11Y_FETCH_IPC_ERRORS_AND_SEND_NOTIFICATIONS",
    default_args=default_args,
    schedule_interval="0 6,12 * * *",
    catchup=False,
    tags=["observability"],
) as dag:
    check_and_alert_task = PythonOperator(
        task_id="fetch_ipc_errors",
        python_callable=check_and_alert,
        dag=dag,
    )

check_and_alert_task
