import abc
import typing

import pendulum
import requests
from airflow.notifications.basenotifier import BaseNotifier


requests.packages.urllib3.disable_warnings()


class TelegramNotification(BaseNotifier, abc.ABC):
    def __init__(self) -> None: ...

    def send_request(self, message: str, *, bot_token, chat_id, proxies: typing.Dict[str, str]):
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        data = {"chat_id": chat_id, "text": message, "parse_mode": "html"}
        response = requests.post(url, data=data, proxies=proxies, verify=False)
        return response

    @abc.abstractmethod
    def compose_message(self, airflow_context: typing.Dict[str, typing.Any]) -> str: ...

    def notify(self, airflow_context: typing.Dict[str, typing.Any]):
        bot_token = airflow_context["var"]["value"].get("telegram_bot_token")
        chat_id = airflow_context["var"]["value"].get("telegram_notifications_chat_id")
        proxies = {
            "http": airflow_context["var"]["value"].get("http_proxy"),
            "https": airflow_context["var"]["value"].get("https_proxy"),
        }
        message = self.compose_message(airflow_context)
        self.send_request(message, bot_token=bot_token, chat_id=chat_id, proxies=proxies)

    def parse_airflow_context(self, airflow_context: typing.Dict[str, typing.Any]):
        dag_id = airflow_context["task_instance"].dag_id
        task_id = airflow_context["task_instance"].task_id
        exec_datetime = pendulum.now("Asia/Oral")
        return dag_id, task_id, exec_datetime


class TelegramErrorNotification(TelegramNotification):
    def compose_message(self, airflow_context: typing.Dict[str, typing.Any]) -> str:
        dag_id, task_id, exec_datetime = self.parse_airflow_context(airflow_context)
        return f"""❌ Task — <b>{task_id}</b> from DAG — <b>{dag_id}</b> failed on <i>{exec_datetime.to_datetime_string()}</i>"""


class TelegramSuccessNotification(TelegramNotification):
    def compose_message(self, airflow_context: typing.Dict[str, typing.Any]) -> str:
        dag_id, task_id, exec_datetime = self.parse_airflow_context(airflow_context)
        return f"""✅ Task — <b>{task_id}</b> from DAG — <b>{dag_id}</b> succeeded on <i>{exec_datetime.to_datetime_string()}</i>"""
