import json
import logging
from collections.abc import Callable, Iterator

from confluent_kafka import Consumer, KafkaException, TopicPartition, Message


logger = logging.getLogger(__name__)


class BatchConsumer:
    def __init__(self, topics: list[str], consumer_config: dict):
        self.consumer: Consumer = Consumer(consumer_config)
        self.consumer.subscribe(topics, on_assign=self.assignment_callback)

    def deserialize_message(self, message: Message) -> dict:
        if message.error():
            raise message.error()
        else:
            return json.loads(message.value())

    def batch_consume(
        self, *, timeout: float, batch_size: int, apply_function: Callable, threshold = None
    ) -> Iterator[dict, None, None]:
        try:
            while True:
                consumed_messages = self.consumer.consume(
                    num_messages=batch_size, timeout=timeout
                )

                if consumed_messages and consumed_messages >= threshold:
                    data = (self.deserialize_message(m) for m in consumed_messages if m is not None)
                    yield data
                    self.consumer.commit()
                else:
                    break
        finally:
            self.consumer.close()

    def assignment_callback(
        self, consumer: Consumer, partitions: list[TopicPartition]
    ) -> None:
        logger.debug(
            f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}"
        )

        partition_list = "".join(
            f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
            for partition in partitions
        )
        logger.debug(
            f"Consumer successfully assigned to following partitions(s): {partition_list}"
        )
