import typing

import requests


requests.packages.urllib3.disable_warnings()


class TelegramNotifier:
    def __init__(self, bot_token, chat_id):
        self.bot_token = bot_token
        self.chat_id = chat_id

    def send_message(self, message, proxies: typing.Dict[str, str]):
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": "html"}
        response = requests.post(url, data=payload, verify=False, proxies=proxies)
        return response

    def send_image(self, file_path: str, proxies: typing.Dict[str, str], caption=""):
        with open(file_path, "rb") as f:
            response = requests.post(
                f"https://api.telegram.org/bot{self.bot_token}/sendPhoto",
                data={"chat_id": self.chat_id},
                files={"file": f},
                verify=False, proxies=proxies
            )
            return response
