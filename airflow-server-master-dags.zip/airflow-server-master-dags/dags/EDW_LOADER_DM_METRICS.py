from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.postgres.hooks.postgres import PostgresHook


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"

default_args = {"owner": "NikitaMi", "email_on_failure": True, "start_date": datetime(2023, 8, 23)}

user_EDW_ETL_CDO = "EDW_ETL_CDO"
table = "dm.DICT_DM_METRICS"
schema_pg = "public"
schema_ora = "dm"

# # ЕСЛИ НАДО БУДЕТ ПЕРЕГРУЗИТЬ РАССКОММЕНТИТЬ И ПОМЕНЯТЬ ПЕРЕМЕННЫЕ DATE И ЦИКЛ FOR (date = 6 -> МИНУС 6 ДНЕЙ С SYSDATE И СКОЛЬКО РАЗ ЦИКЛ БУДЕТ РАБОТАТЬ ТОЖЕ 6)
# def extract_load(user_oracle, table, schema_pg, schema_ora):
#     postgres_hook = PostgresHook("monitoring")
#     postgres_conn = postgres_hook.get_conn()
#     postgres_cursor = postgres_conn.cursor()

#     oracle_hook = OracleHook(user_oracle)
#     oracle_conn = oracle_hook.get_conn()
#     oracle_cursor = oracle_conn.cursor()
#     oracle_cursor.execute('SELECT * FROM '+ table) # +' WHERE TABLE_NAME IN ('+ dm_in +')')
#     oracle_dm_list = oracle_cursor.fetchall()
#     date = 4 #CHANGE
#     for i in range(3): # CHANGE
#         or_cur = oracle_conn.cursor()
#         oracle_del = 'DELETE FROM ' + schema_ora + '.DM_METRICS WHERE DATE_VALUE = TRUNC(SYSDATE)-'+ str(date)
#         or_cur.execute(oracle_del)

#         pg_cur = postgres_conn.cursor()
#         postgres_del = 'DELETE FROM ' + schema_pg + '.DM_METRICS WHERE DATE_VALUE = CURRENT_DATE-'+ str(date)
#         pg_cur.execute(postgres_del)

#         for row in oracle_dm_list:
#             print('row', row)
#             print('select', row[3])
#             select = row[3].upper()
#             select = select.replace('TRUNC(SYSDATE)-1', 'TRUNC(SYSDATE)-' + str(date))
#             print('replaced', select)
#             oracle_cursor2 = oracle_conn.cursor()
#             oracle_cursor2.execute(select)
#             oracle_data = oracle_cursor2.fetchall()
#             print('oracle_data', oracle_data)
#             for data in oracle_data:
#                 text = ''
#                 if data[0] == None:
#                     insert = 'NULL'
#                 else:
#                     insert = data[0]

#                 if len(data) == 2:
#                     if data[1] == None:
#                         insert2 = 'NULL'
#                     else:
#                         insert2 = data[1]
#                     text = ", '" + insert2 + "')"
#                 else:
#                     text = ", NULL)"
#                 print('text', text)

#                 query = "INSERT INTO " + schema_ora + ".DM_METRICS(DATE_VALUE, TABLE_NAME, METRIC_ID, METRIC_NAME, METRIC_VALUE, GROUPED_BY) \
#                         VALUES (TRUNC(SYSDATE)-" +str(date) + ", '" + str(row[0]) + "', " + str(row[1]) + ", '" + str(row[2]) + "', " + str(insert) + text
#                 print('query', query)
#                 oracle_cursor2.execute(query)
#                 oracle_conn.commit()

#                 query = "INSERT INTO " + schema_pg + ".DM_METRICS(DATE_VALUE, TABLE_NAME, METRIC_ID, METRIC_NAME, METRIC_VALUE, GROUPED_BY) \
#                         VALUES (current_date-" +str(date) + ", '" + str(row[0]) + "', " + str(row[1]) + ", '" + str(row[2]) + "', " + str(insert) + text
#                 print('query', query)
#                 postgres_cursor.execute(query)
#                 postgres_conn.commit()
#         date -= 1
#     or_cur.close()
#     pg_cur.close()
#     oracle_cursor2.close()
#     postgres_cursor.close()
#     postgres_conn.close()
#     oracle_conn.close()


def extract_load(user_oracle, table, schema_pg, schema_ora):
    postgres_hook = PostgresHook("monitoring")
    postgres_conn = postgres_hook.get_conn()
    postgres_cursor = postgres_conn.cursor()

    oracle_hook = OracleHook(user_oracle)
    oracle_conn = oracle_hook.get_conn()

    # проверяем есть ли готовые витрины
    postgres_cursor.execute(
        "SELECT count(*) FROM public.dm_shed_table WHERE date_value = current_date-1 AND dm_ready_fl = 1"
    )
    count_ready_dm = postgres_cursor.fetchone()
    print(count_ready_dm[0])

    # or_cur = oracle_conn.cursor()
    # oracle_del = 'DELETE FROM ' + schema_ora + '.DM_METRICS WHERE DATE_VALUE = TRUNC(SYSDATE)-1'
    # or_cur.execute(oracle_del)

    # pg_cur = postgres_conn.cursor()
    # postgres_del = 'DELETE FROM ' + schema_pg + '.DM_METRICS WHERE DATE_VALUE = CURRENT_DATE-1'
    # pg_cur.execute(postgres_del)

    # oracle_conn.commit()
    # postgres_conn.commit()

    # если готовые витрины есть
    if count_ready_dm[0] != 0:
        # вибираем названия готовых витрин и делаем из них строку через запятую
        postgres_cursor.execute(
            "SELECT substring(wf_name, 4, 100) FROM public.dm_shed_table WHERE date_value = current_date-1 AND dm_ready_fl = 1"
        )
        ready_dm_list = postgres_cursor.fetchall()
        print(ready_dm_list)
        dm_in = ""
        dm_list = ""
        for dm in ready_dm_list:
            dm_in += "'" + str(dm[0]) + "'" + ", "
            dm_list += str(dm[0]) + ", "
        dm_in = dm_in[0 : len(dm_in) - 2]  # e.g. 'HB_DEVICE_H', 'AP_APPLICATION_DM'
        dm_list = dm_list[0 : len(dm_list) - 2]  # e.g.  ['HB_DEVICE_H', 'AP_APPLICATION_DM']
        dm_list = dm_list.split(", ")

        print(dm_in)
        print(dm_list)

        postgres_cursor.execute("SELECT DISTINCT TABLE_NAME FROM public.DM_METRICS WHERE date_value = current_date-1")
        ready_dm_metrics = postgres_cursor.fetchall()
        print("ready_dm_metrics", ready_dm_metrics)  # list [(...,), (...,),]

        oracle_cursor = oracle_conn.cursor()

        if len(ready_dm_metrics) != 0:
            # dm_in2 = ''
            dm_list2 = ""
            for dm in ready_dm_metrics:
                # dm_in2 += "'"+ str(dm[0]) +"'" + ', '
                dm_list2 += str(dm[0]) + ", "
            # dm_in2 = dm_in2[0:len(dm_in2) - 2]
            dm_list2 = dm_list2[0 : len(dm_list2) - 2].split(", ")
            # print(dm_in2)
            print("dm_list2", dm_list2)
            dm_to_load = list(set(dm_list) - set(dm_list2))
            print("dm_to_load", dm_to_load)
            # # удаляем метрики готовых витрин
            # postgres_cursor.execute('DELETE FROM PUBLIC.DM_METRICS WHERE DATE_VALUE=CURRENT_DATE-1 AND TABLE_NAME IN ('+ dm_in2 +')')
            # postgres_conn.commit()
            dm_to_load = "', '".join(dm_to_load)
            print("dm_to_load joined ,", dm_to_load)
            oracle_cursor.execute("SELECT * FROM " + table + " WHERE TABLE_NAME IN ('" + dm_to_load + "')")
            oracle_dm_list = oracle_cursor.fetchall()
        else:
            oracle_cursor.execute("SELECT * FROM " + table + " WHERE TABLE_NAME IN (" + dm_in + ")")
            oracle_dm_list = oracle_cursor.fetchall()
        for row in oracle_dm_list:
            print("row", row)
            print("select", row[3])
            oracle_cursor2 = oracle_conn.cursor()
            oracle_cursor2.execute(row[3])
            oracle_data = oracle_cursor2.fetchall()
            print("oracle_data", oracle_data)
            for data in oracle_data:
                text = ""
                if data[0] == None:
                    insert = "NULL"
                else:
                    insert = data[0]

                if len(data) == 2:
                    if data[1] == None:
                        insert2 = "NULL"
                    else:
                        insert2 = data[1]
                    text = ", '" + insert2 + "')"
                else:
                    text = ", NULL)"
                print("text", text)

                query = (
                    "INSERT INTO "
                    + schema_ora
                    + ".DM_METRICS(DATE_VALUE, TABLE_NAME, METRIC_ID, METRIC_NAME, METRIC_VALUE, GROUPED_BY) \
                        VALUES (TRUNC(SYSDATE)-1"
                    + ", '"
                    + str(row[0])
                    + "', "
                    + str(row[1])
                    + ", '"
                    + str(row[2])
                    + "', "
                    + str(insert)
                    + text
                )
                print("query", query)
                oracle_cursor2.execute(query)
                oracle_conn.commit()

                query = (
                    "INSERT INTO "
                    + schema_pg
                    + ".DM_METRICS(DATE_VALUE, TABLE_NAME, METRIC_ID, METRIC_NAME, METRIC_VALUE, GROUPED_BY) \
                        VALUES (current_date-1"
                    + ", '"
                    + str(row[0])
                    + "', "
                    + str(row[1])
                    + ", '"
                    + str(row[2])
                    + "', "
                    + str(insert)
                    + text
                )
                print("query", query)
                postgres_cursor.execute(query)
                postgres_conn.commit()
            oracle_cursor2.close()
        postgres_cursor.close()
        postgres_conn.close()
        oracle_conn.close()


with DAG(
    tags=["DM", "EDW_LOADER", "DM_METRICS", "EDW"],
    start_date=datetime(2023, 8, 1),
    catchup=False,
    dag_id="EDW_LOADER_DM_METRICS",
    description="Daily ETL process to calculate DM metrics",
    schedule_interval="0 5,6,7,8,10,13 * * *",
    default_args=default_args,
) as dag:
    start_task = DummyOperator(task_id="start_task", dag=dag)
    end_task = DummyOperator(task_id="end_task", dag=dag)

    metric = PythonOperator(
        task_id="metric",
        python_callable=extract_load,
        op_args=[user_EDW_ETL_CDO, table, schema_pg, schema_ora],
        provide_context=True,
        dag=dag,
    )

start_task >> metric >> end_task
