import time
from datetime import datetime

import pandas as pd
from airflow import DAG
from airflow.operators.email import EmailOperator
from airflow.operators.python import BranchPythonOperator, PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"
apps = dags + "apps/"

timestr = time.strftime("%Y-%m-%d")

fname = temp_dir + timestr + ".csv"
xls_fname = temp_dir + timestr + ".xlsx"

sql = """select distinct iin, p_sid,  channel,  request_amount,  request_term,  approved_sum,  approved_monthly_payment,  approved_rate,  approved_term, created_at,  communication_value from bzk_followup_copy1"""

ORACLE_CONN_ID = "SPSS_SE"

default_args = {"owner": "AselNu", "email": ["AselNu3@halykbank.kz"]}


def get_data_from_oracle():
    oracle_hook = OracleHook(oracle_conn_id=ORACLE_CONN_ID)
    pd.DataFrame(
        oracle_hook.get_records(sql=sql),
        columns=[
            "iin",
            "p_sid",
            "channel",
            "request_amount",
            "request_term",
            "approved_sum",
            "approved_monthly_payment",
            "approved_rate",
            "approved_term",
            "created_at",
            "communication_value",
        ],
    ).to_csv(fname, index=False)
    return fname


def validate_csv():
    df = pd.read_csv(fname, converters={"iin": str})
    if not df.empty:
        sheetname = timestr
        writer = pd.ExcelWriter(xls_fname, engine="xlsxwriter")
        df.to_excel(writer, sheet_name=sheetname, index=False)  # send df to writer
        worksheet = writer.sheets[sheetname]  # pull worksheet object
        for idx, col in enumerate(df):  # loop through all columns
            series = df[col]
            max_len = (
                max(
                    (
                        series.astype(str).map(len).max(),  # len of largest item
                        len(str(series.name)),  # len of column name/header
                    )
                )
                + 1
            )  # adding a little extra space
            worksheet.set_column(idx, idx, max_len)  # set column width
        writer.close()
        return "branch_ok"
    else:
        return "branch_not_ok"


with DAG(
    tags=["AselNu3@halykbank.kz", "daily", "email", "spss", "oracle", "asselnuraliyeva", "rb"],
    dag_id="RB_REPORT_DAILY_SPSS",
    description="Ежедневная выгрузка по БЗК.",
    start_date=datetime(2023, 2, 9),
    schedule_interval="0 11 * * 1-5",
    catchup=False,
    default_args=default_args,
) as dag:
    ora_extract = PythonOperator(task_id="ora_extract_task", python_callable=get_data_from_oracle)
    branch_task = BranchPythonOperator(
        task_id="validate_csv",
        python_callable=validate_csv,
        dag=dag,
    )
    branch_ok = EmailOperator(
        task_id="branch_ok",
        to=["AselNu3@halykbank.kz", "KuanysKu@halykbank.kz"],
        # to=["SanzharsyltanBe@halykbank.kz"],
        subject="Ежедневный отчет по БЗК",
        html_content="Добрый день. Направляю ежедневную выгрузку по БЗК. \n С уважением, " "Нуралиева Асель",
        files=[xls_fname],
    )
    branch_not_ok = EmailOperator(
        task_id="branch_not_ok",
        to=["SanzharsyltanBe@halykbank.kz"],
        subject="ERROR in DAG DEV_oracle_spss_assel_daily",
        html_content="Dataset is empty",
    )

ora_extract >> branch_task
branch_task >> branch_ok
branch_task >> branch_not_ok
