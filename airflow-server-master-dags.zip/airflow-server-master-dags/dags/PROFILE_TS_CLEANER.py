import json
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator, PythonOperator

# from airflow.providers.vertica.operators.vertica import VerticaOperator
from airflow.providers.vertica.hooks.vertica import VerticaHook
from airflow.utils.email import send_email
from jinja2 import Template


VERTICA_CONN = "Vertica_Prod"
home = "/opt/airflow/"
dags = home + "dags/"
sql = dags + "sql/"

default_args = {
    "owner": "NikitaMi",
    "retries": 0,
    "retry_delay": timedelta(minutes=10),
    # 'catchup': False
}


def set_date(**kwargs):  # функция устанавливает максимальную дату из логов по умолчанию
    vertica_hook = VerticaHook("Vertica_Prod")
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(
        "\
        SELECT min(actual_date) as actual_date \
        from profile_dm.PROFILE_ACTUAL_DATE"
    )

    global actual_date
    actual_date = vertica_cursor.fetchone()
    # print(actual_date, 'actual_date')

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="actual_date", value=actual_date)


def email_text(context):
    task_instance = context["task_instance"]

    subject = f"Airflow Task {task_instance.task_id}"
    body = f"The task {task_instance.task_id} finished with status {task_instance.current_state()}. Log URL: {task_instance.log_url}\n\n"

    to_email = ["AiysulySH@halykbank.kz", "NikitaMi@halykbank.kz"]

    send_email(to=to_email, subject=subject, html_content=body)


def profile_stg_cleaner(**kwargs):

    actual_date = kwargs["ti"].xcom_pull(key="actual_date", task_ids="set_date")[0]

    # Обычные таблицы stg

    date_to = (actual_date - timedelta(days=5)).strftime("%Y-%m-%d")
    date_from = (actual_date - timedelta(days=185)).strftime("%Y-%m-%d")

    print("date_from ", date_from)
    print("date_to ", date_to)

    template_sql = open(sql + "profile_stg_truncate.sql", "r").read()
    templated_sql = Template(template_sql).render({"date_from": date_from, "date_to": date_to})
    print(templated_sql)

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(templated_sql)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def profile_stg_two_mnth_cleaner(**kwargs):
    # Исторические таблицы stg - хранящие историю в 2 месяца
    actual_date = kwargs["ti"].xcom_pull(key="actual_date", task_ids="set_date")[0]

    date_to_mnth = (actual_date - timedelta(days=65)).strftime("%Y-%m-%d")
    date_from_mnth = (actual_date - timedelta(days=185)).strftime("%Y-%m-%d")

    print("date_from_mnth ", date_from_mnth)
    print("date_to_mnth ", date_to_mnth)

    template_sql_mnth = open(sql + "profile_stg_two_mnth_truncate.sql", "r").read()
    templated_sql_mnth = Template(template_sql_mnth).render({"date_from": date_from_mnth, "date_to": date_to_mnth})
    print(templated_sql_mnth)

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(templated_sql_mnth)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def mdm_cleaner(**kwargs):
    actual_date = kwargs["ti"].xcom_pull(key="actual_date", task_ids="set_date")[0]

    date_to = (actual_date - timedelta(days=5)).strftime("%Y-%m-%d")

    mdm_log_sql = open(sql + "mdm_hist_creator/check_raw.sql", "r").read()
    templated_mdm_log_sql = Template(mdm_log_sql).render(load_date=date_to)
    print(templated_mdm_log_sql)

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(templated_mdm_log_sql)
    ready_load_id = vertica_cursor.fetchall()[0][0]
    print(ready_load_id)

    template_sql_mdm = open(sql + "profile_mdm_truncate.sql", "r").read()
    templated_sql_mdm = Template(template_sql_mdm).render(load_id=ready_load_id)
    print(templated_sql_mdm)

    vertica_cursor.execute(templated_sql_mdm)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


with DAG(
    dag_id="PROFILE_TS_CLEANER",
    description="DAG, который чистит данные в Vertica",
    tags=["PROFILE"],
    start_date=datetime(2024, 8, 21),
    schedule_interval="0 21 * * 1",
    catchup=False,
    owner_links={"doc": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=727749873"},
    default_args=default_args,
) as dag:
    set_date = PythonOperator(
        task_id="set_date",
        python_callable=set_date,
        dag=dag,
    )
    profile_stg_cleaner = PythonOperator(
        task_id="profile_stg_cleaner",
        provide_context=True,
        python_callable=profile_stg_cleaner,
        email=["AiysulySH@halykbank.kz", "NikitaMi@halykbank.kz"],
        email_on_failure=True,
        email_on_retry=False,
        on_failure_callback=email_text,
        dag=dag,
    )
    profile_stg_two_mnth_cleaner = PythonOperator(
        task_id="profile_stg_two_mnth_cleaner",
        provide_context=True,
        python_callable=profile_stg_two_mnth_cleaner,
        email=["AiysulySH@halykbank.kz", "NikitaMi@halykbank.kz"],
        email_on_failure=True,
        email_on_retry=False,
        on_failure_callback=email_text,
        dag=dag,
    )
    mdm_cleaner = PythonOperator(
        task_id="mdm_cleaner",
        provide_context=True,
        python_callable=mdm_cleaner,
        email=["AiysulySH@halykbank.kz", "NikitaMi@halykbank.kz"],
        email_on_failure=True,
        email_on_retry=False,
        on_failure_callback=email_text,
        dag=dag,
    )


set_date >> profile_stg_cleaner >> profile_stg_two_mnth_cleaner >> mdm_cleaner
