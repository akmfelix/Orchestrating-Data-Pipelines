from datetime import datetime

import airflow
from airflow.operators.empty import EmptyOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.providers.oracle.operators.oracle import OracleOperator

from source.telegram_notifications import (
    TelegramErrorNotification,
)


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"
apps = dags + "apps/"
app_files = apps + "PKB_RUN/"

spark_files_dir = temp_dir

default_args = {
    "owner": "AlibekDz",
    "email": [
        "NikitaMi@halykbank.kz",
        "AlibekDz@halykbank.kz",
        "AiysulySH@halykbank.kz",
    ],
    "email_on_failure": True,
    "on_failure_callback": [TelegramErrorNotification()],
}

spark_default_conf = {
    "spark.master": "yarn",
    "spark.submit.deployMode": "cluster",
    "spark.yarn.queue": "dm",
    "spark.driver.maxResultSize": "0",
    "spark.rpc.message.maxSize": "2047",
    # "spark.shuffle.service.enabled": True,
    # "spark.dynamicAllocation.enabled": True,
    # "spark.sql.orc.compress.size": "4096",
    # "spark.sql.orc.stripe.size": "268435456",
    # "orc.stripe.size": "268435456",
    # "orc.compress.size": "4096",
    "spark.hadoop.yarn.timeline-service.enabled": False,
    "spark.local.dir": spark_files_dir,
    "spark.kryoserializer.buffer.max": "128m",
    # "hive.exec.orc.default.stripe.size": "268435456",
    # "spark.sql.orc.enableVectorizedReader": True,
    # "spark.memory.offHeap.enabled": True,
    # "spark.memory.offHeap.size": "16g"
}


def spark_submit_generator(
    name,
    app_name,
    executor_memory="48G",
    driver_memory="72G",
    trigger_rule="all_success",
    app_py_files=str(
        app_files
        + "Schemas.zip,"
        + app_files
        + "Mappers.zip,"
        + app_files
        + "Parsers.zip,"
        + app_files
        + "Oracle_configs.zip,"
        + app_files
        + "Logging.zip,"
        + app_files
        + "Writers.zip"
    ),
):
    return SparkSubmitOperator(
        task_id=str(name),
        conn_id="spark_default",
        application=app_files + str(app_name + ".py"),
        executor_memory=executor_memory,
        driver_memory=driver_memory,
        num_executors=8,
        principal="ADH_Runner_CDO@HALYKBANK.NB",
        keytab="/opt/airflow/config/credentials/hadoop/krb5.keytab",
        py_files=app_py_files,
        name=name,
        jars=app_files + "ojdbc8-21.1.0.0.jar",
        verbose=True,
        conf=spark_default_conf,
        trigger_rule=trigger_rule,
    )


def truncate_task(name, query, trigger_rule="all_success"):
    return OracleOperator(
        task_id=str(name),
        oracle_conn_id="EDW_ETL_CDO",
        sql=query,
        autocommit=True,
        trigger_rule=trigger_rule,
    )


def oracle_operator_generator(name, path, trigger_rule="all_success"):
    return OracleOperator(
        task_id=str(name),
        oracle_conn_id="EDW_ETL_CDO",
        sql=str(path),
        autocommit=True,
        trigger_rule=trigger_rule,
    )


with airflow.DAG(
    dag_id="EDW_LOADER_PKB_REPORTS_XML",
    tags=["EDW_LOADER", "SPARK", "DDS", "ODS", "PKB", "EDW"],
    default_args=default_args,
    schedule_interval="0 7 * * *",
    # schedule_interval='@once',
    description="Парсинг и загрузка данных ПКБ в ХД",
    start_date=datetime(2024, 1, 19),
    catchup=False,
) as dag_spark:

    combined_sql = """
        DECLARE
            extract_date DATE;
        BEGIN 
            SELECT
                OPER_DATE 
            INTO 
                extract_date
            FROM
    	        RISKDM.AIRFLOW_ETL_DATA
            WHERE
                DAG_NAME = 'EDW_PKB_RISKDM'
                AND STATUS = 'WAITING';

            DDS.TRUNCATE_PARTITION_CDO_P('PKB_CONTRACT_PAYMENTS_FL',TO_CHAR(extract_date, 'YYYYMMDD'));
            DDS.TRUNCATE_PARTITION_CDO_P('PKB_CLIENT_REPORTS_FL',TO_CHAR(extract_date, 'YYYYMMDD')); 
            DDS.TRUNCATE_PARTITION_CDO_P('PKB_CLIENT_CONTRACTS_FL',TO_CHAR(extract_date, 'YYYYMMDD'));  
        END;
        """
    truncate_task: OracleOperator = truncate_task(name='trunc_task', query=combined_sql)

    pkb_report: SparkSubmitOperator = spark_submit_generator(name="pkb_report", app_name="PKB_REPORTS_PARSING")

    # App_F1
    PKB_UPDATE_LOG: OracleOperator = oracle_operator_generator(name="PKB_UPDATE_LOG", path="sql/PKB_UPDATE_LOG.sql")

    PKB_INSERT_LOG: OracleOperator = oracle_operator_generator(name="PKB_INSERT_LOG", path="sql/PKB_INSERT_LOG.sql")

    start: EmptyOperator = EmptyOperator(task_id="start")
    end: EmptyOperator = EmptyOperator(
        task_id="end",
    )

start >> truncate_task >>pkb_report >> PKB_UPDATE_LOG >> PKB_INSERT_LOG >> end
