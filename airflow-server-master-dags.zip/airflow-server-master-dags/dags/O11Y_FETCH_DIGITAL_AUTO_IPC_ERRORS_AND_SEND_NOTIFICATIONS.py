from datetime import datetime, timedelta
from typing import Tuple

import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook

from source.telegram_notifier import TelegramNotifier


default_args = {
    "depends_on_past": False,
    "start_date": pendulum.datetime(2024, 9, 27, tz="Asia/Oral"),
    "retries": 1,
    "retry_delay": timedelta(minutes=15),
    "owner": "AiysulySH",
}


def format_message(
    workflow_name: str,
    repo_name: str,
    status: str,
    inserted_rows: int,
    deleted_rows: int,
    updated_rows: int,
) -> str:
    # message = f"✅ <b>Yahoo Finance Scraper</b> fetched <u>{result_set[0]}</u> records on <i>{pendulum.now('Asia/Oral').to_datetime_string()}</i>"
    err_message = f"✅ Процесс — <b>{workflow_name}</b> из репозитория — <b>{repo_name}</b> завершился со статусом <b>{status}</b>:\nUPDATED ROWS - <b>{updated_rows}</b>,\nINSERTED ROWS - <b>{inserted_rows}</b>,\nDELETED ROWS - <b>{deleted_rows}</b>."
    return err_message


def fetch_error_tuples(oracle_hook: OracleHook, sql_statement: str) -> Tuple[str, str, str]:
    connection = oracle_hook.get_conn()
    with connection.cursor() as cursor:
        result_set = cursor.execute(sql_statement).fetchall()
    connection.close()
    return result_set


def check_and_alert(**context):
    bot_token = context["var"]["value"].get("telegram_bot_token")
    chat_id = context["var"]["value"].get("telegram_notifications_chat_id")
    proxies = {
        "http": context["var"]["value"].get("http_proxy"),
        "https": context["var"]["value"].get("https_proxy"),
    }

    notifier = TelegramNotifier(bot_token=bot_token, chat_id=chat_id)
    error_fetching_sql = """
            SELECT WORKFLOW_NAME,
                   REPO_NAME,
                   STATUS,
                   INSERTED_ROWS,
                   DELETED_ROWS,
                   UPDATED_ROWS
                   FROM (
                         SELECT DISTINCT R1.WORKFLOW_NAME,
                                'RB_REP' AS REPO_NAME,
                                CASE WHEN R2.LAST_ERR_CODE <> 0 THEN 'ERROR/WARNING' WHEN R2.LAST_ERR_CODE = 0 AND R3.START_TIME IS NOT NULL AND R3.END_TIME IS NULL THEN 'RUNNING'
                                     WHEN R3.START_TIME IS NULL THEN 'NOT STARTED'
                                ELSE 'SUCCESS' END STATUS,
                  MAX(CASE WHEN INSTANCE_NAME= 'CarInfo_INSERT' THEN AFFECTED_ROWS END) AS INSERTED_ROWS,
                  MAX(CASE WHEN INSTANCE_NAME= 'CarInfo_DELETE' THEN AFFECTED_ROWS END) AS DELETED_ROWS,
                  MAX(CASE WHEN INSTANCE_NAME= 'CarInfo_UPDATE' THEN AFFECTED_ROWS END) AS UPDATED_ROWS,
                  ROW_NUMBER() OVER (PARTITION BY R1.WORKFLOW_ID ORDER BY R3.START_TIME desc) AS rn
           FROM RB_REP.OPB_WFLOW_RUN R1
           LEFT JOIN RB_REP.OPB_SWIDGINST_LOG R2 ON R1.WORKFLOW_ID = R2.WORKFLOW_ID AND R1.WORKFLOW_RUN_ID = R2.WORKFLOW_RUN_ID
           LEFT JOIN RB_REP.OPB_WFLOW_RUN R3 ON R1.WORKFLOW_ID = R3.WORKFLOW_ID AND R1.WORKFLOW_RUN_ID = R3.WORKFLOW_RUN_ID --AND R2.START_TIME >= trunc(sysdate)-1 
           GROUP BY R1.WORKFLOW_ID, R1.WORKFLOW_NAME, R3.START_TIME, R3.END_TIME, R3.RUN_ERR_CODE, R2.LAST_ERR_CODE, R2.LAST_ERR_MSG
           )
           WHERE WORKFLOW_NAME = 'wf_DIGITAL_AUTO' AND rn = 1 

    """
    errors = fetch_error_tuples(
        OracleHook(oracle_conn_id="db_oracle_ipc__edw_ipc", thick_mode=True), error_fetching_sql
    )

    for workflow_name, repo_name, status, inserted_rows, deleted_rows, updated_rows in errors:
        message = format_message(workflow_name, repo_name, status, inserted_rows, deleted_rows, updated_rows)
        response = notifier.send_message(message, proxies)


with DAG(
    dag_id="O11Y_FETCH_DIGITAL_AUTO_IPC_ERRORS_AND_SEND_NOTIFICATIONS",
    default_args=default_args,
    schedule_interval="0 8 * * *",
    catchup=False,
    tags=["observability"],
) as dag:
    check_and_alert_task = PythonOperator(
        task_id="fetch_ipc_errors",
        python_callable=check_and_alert,
        dag=dag,
    )

check_and_alert_task
