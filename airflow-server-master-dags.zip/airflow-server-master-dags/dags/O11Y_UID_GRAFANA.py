from datetime import datetime, timedelta

import oracledb
import pandas as pd
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.vertica.hooks.vertica import VerticaHook
from airflow.utils.trigger_rule import TriggerRule


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"

default_args = {
    "owner": "NikitaMi",
    "email_on_failure": True,
    "start_date": datetime(2023, 8, 10),
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "catchup": False,
}

user_EDW_ETL_CDO = "EDW_ETL_CDO"
user_ETL_REP = "ETL_REP"
user_EDW_IPC = "EDW_IPC"
user_WF_MONITOR = "monitoring"
user_VERTICA = "Vertica_Prod"

SQL_QUERY_1_path = sql + "DDS_LOAD_LOG.sql"
SQL_QUERY_1 = open(SQL_QUERY_1_path, "r").read()

SQL_QUERY_2_path = sql + "DM_DDS_RELATION.sql"
SQL_QUERY_2 = open(SQL_QUERY_2_path, "r").read()

SQL_QUERY_3_path = sql + "DM_SHED_TABLE.sql"
SQL_QUERY_3 = open(SQL_QUERY_3_path, "r").read()

SQL_QUERY_4_path = sql + "TASK_INST_RUN.sql"
SQL_QUERY_4 = open(SQL_QUERY_4_path, "r").read()

SQL_QUERY_5_path = sql + "TASKS.sql"
SQL_QUERY_5 = open(SQL_QUERY_5_path, "r").read()

SQL_QUERY_6_path = sql + "RISKDM_LOAD_LOG.sql"
SQL_QUERY_6 = open(SQL_QUERY_6_path, "r").read()

SQL_QUERY_7_path = sql + "RISKDM_DDS_READY_FL.sql"
SQL_QUERY_7 = open(SQL_QUERY_7_path, "r").read()

SQL_QUERY_8_path = sql + "VERTICA_PROFILE.sql"
SQL_QUERY_8 = open(SQL_QUERY_8_path, "r").read()

SQL_QUERY_9_path = sql + "VERTICA_REQUESTS.sql"
SQL_QUERY_9 = open(SQL_QUERY_9_path, "r").read()


def extract_dm_dds_relation(sql_query, user_oracle, user_postgres, postgres_table):
    if user_oracle == user_EDW_IPC:
        oracle_hook = OracleHook("db_oracle_ipc__edw_ipc", thick_mode=True)
        oracle_conn = oracle_hook.get_conn()
    else:
        oracle_hook = OracleHook(user_oracle, thick_mode=True)
        oracle_conn = oracle_hook.get_conn()
    oracle_cursor = oracle_conn.cursor()
    oracle_cursor.execute(sql_query)
    oracle_data = oracle_cursor.fetchall()
    print(oracle_data)
    postgres_hook = PostgresHook(user_postgres)
    if len(oracle_data) != 0 or oracle_data:
        if postgres_table == "riskdm_load_log":
            postgres_query = (
                "INSERT INTO "
                + postgres_table
                + " VALUES ({}) ON CONFLICT (entity) DO UPDATE\
                                SET state = excluded.state,\
                                    src_count = excluded.src_count,\
                                    trg_count = excluded.trg_count,\
                                    begin_datetime = excluded.begin_datetime,\
                                    end_datetime = excluded.end_datetime,\
                                    operation_date = excluded.operation_date,\
                                    SYSTEM = excluded.system,\
                                    log_id = excluded.log_id".format(
                    ",".join(["%s"] * len(oracle_data[0]))
                )
            )
        else:
            postgres_hook.run(f"TRUNCATE TABLE {postgres_table}")
            postgres_query = (
                "INSERT INTO " + postgres_table + " VALUES ({})".format(",".join(["%s"] * len(oracle_data[0])))
            )
    postgres_conn = postgres_hook.get_conn()
    postgres_cursor = postgres_conn.cursor()
    if oracle_data:
        postgres_cursor.executemany(postgres_query, oracle_data)
        postgres_conn.commit()
    postgres_cursor.close()
    postgres_conn.close()
    oracle_conn.close()


def vertica_monitoring(user_VERTICA, SQL_QUERY_8, user_WF_MONITOR):
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(SQL_QUERY_8)
    results = vertica_cursor.fetchall()
    vertica_cursor.close()
    vertica_conn.close()

    postgres_hook = PostgresHook(user_WF_MONITOR)
    postgres_conn = postgres_hook.get_conn()
    postgres_cursor = postgres_conn.cursor()

    postgres_hook.run(f"TRUNCATE TABLE public.vertica_monitoring")
    postgres_query = "INSERT INTO public.vertica_monitoring VALUES ({})".format(",".join(["%s"] * len(results[0])))

    postgres_cursor.executemany(postgres_query, results)
    postgres_conn.commit()
    postgres_cursor.close()
    postgres_conn.close()


def vertica_requests(user_VERTICA, SQL_QUERY_9, user_WF_MONITOR):
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(SQL_QUERY_9)
    results = vertica_cursor.fetchall()
    vertica_cursor.close()
    vertica_conn.close()

    postgres_hook = PostgresHook(user_WF_MONITOR)
    postgres_conn = postgres_hook.get_conn()
    postgres_cursor = postgres_conn.cursor()

    postgres_hook.run(f"TRUNCATE TABLE public.vertica_requests")
    postgres_query = "INSERT INTO public.vertica_requests VALUES ({})".format(",".join(["%s"] * len(results[0])))

    postgres_cursor.executemany(postgres_query, results)
    postgres_conn.commit()
    postgres_cursor.close()
    postgres_conn.close()


with DAG(
    tags=["GRAFANA", "O11Y", "MONITORING"],
    start_date=datetime(2023, 8, 10),
    catchup=False,
    dag_id="O11Y_UID_GRAFANA",
    description="ETL process to migrate from log tables to monitoring db for grafana",
    # At minute 0, 10, 20, 30, 40, and  50 past hour 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, and 18 on Monday, Tuesday, Wednesday, Thursday, and Friday.
    # каждые 10 мин с 8 утра до 6 вечера по будням
    schedule_interval="0,10,20,30,40,50 8-18 * * 1-5",
    default_args=default_args,
    owner_links={"NikitaMi": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=584156623"},
) as dag:
    start_task = DummyOperator(task_id="start_task", dag=dag)
    end_task = DummyOperator(task_id="end_task", dag=dag)

    dds_load_log = PythonOperator(
        task_id="dds_load_log",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_1, user_ETL_REP, user_WF_MONITOR, "dds_load_log"],
        provide_context=True,
        dag=dag,
    )

    riskdm_dds_ready_fl = PythonOperator(
        task_id="riskdm_dds_ready_fl",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_7, user_ETL_REP, user_WF_MONITOR, "riskdm_dds_ready_fl"],
        provide_context=True,
        dag=dag,
    )

    riskdm_load_log = PythonOperator(
        task_id="riskdm_load_log",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_6, user_ETL_REP, user_WF_MONITOR, "riskdm_load_log"],
        provide_context=True,
        dag=dag,
    )

    dm_dds_relation = PythonOperator(
        task_id="dm_dds_relation",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_2, user_EDW_ETL_CDO, user_WF_MONITOR, "dm_dds_relation"],
        provide_context=True,
        dag=dag,
    )

    dm_shed_table = PythonOperator(
        task_id="dm_shed_table",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_3, user_EDW_ETL_CDO, user_WF_MONITOR, "dm_shed_table"],
        provide_context=True,
        dag=dag,
    )

    task_inst_run = PythonOperator(
        task_id="task_inst_run",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_4, user_EDW_IPC, user_WF_MONITOR, "task_inst_run"],
        provide_context=True,
        dag=dag,
    )

    tasks = PythonOperator(
        task_id="tasks",
        python_callable=extract_dm_dds_relation,
        op_args=[SQL_QUERY_5, user_EDW_IPC, user_WF_MONITOR, "tasks"],
        provide_context=True,
        dag=dag,
    )

    vertica_monitoring = PythonOperator(
        task_id="vertica_monitoring",
        python_callable=vertica_monitoring,
        op_args=[user_VERTICA, SQL_QUERY_8, user_WF_MONITOR],
        provide_context=True,
        trigger_rule=TriggerRule.ALL_DONE,
        dag=dag,
    )

    vertica_requests = PythonOperator(
        task_id="vertica_requests",
        python_callable=vertica_requests,
        op_args=[user_VERTICA, SQL_QUERY_9, user_WF_MONITOR],
        provide_context=True,
        trigger_rule=TriggerRule.ALL_DONE,
        dag=dag,
    )

(
    start_task
    >> [
        dds_load_log,
        riskdm_dds_ready_fl,
        riskdm_load_log,
        dm_dds_relation,
        dm_shed_table,
        task_inst_run,
        tasks,
    ]
    >> vertica_monitoring
    >> vertica_requests
    >> end_task
)
