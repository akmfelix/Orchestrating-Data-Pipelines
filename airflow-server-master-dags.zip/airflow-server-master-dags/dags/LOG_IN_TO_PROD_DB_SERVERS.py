import datetime as dt
import logging

import pendulum
from airflow.decorators import dag
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook

from source.telegram_notifications import (
    TelegramErrorNotification,
    TelegramSuccessNotification,
)


logger = logging.getLogger(__name__)


doc_md = """
This DAG periodically (every 12 days) performs a round-trip auth. call against prod. DB servers to get around the rule 
that states that every user should login at least once every two weeks to production server.
"""


default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "on_failure_callback": [TelegramErrorNotification()],
    "on_success_callback": [TelegramSuccessNotification()],
}


def login_to_oracle_db(oracle_db_hook) -> None:
    connection = oracle_db_hook.get_conn()
    with connection.cursor() as cursor:
        logger.info(f"Logged in successfully. Trying to select *current_timestamp*...")
        result_set_cursor = cursor.execute(statement="select current_timestamp from dual")
        current_timestamp = result_set_cursor.fetchone()[0]
        log_message = f"Fetched timestamp is {current_timestamp.strftime('%Y-%m-%d %H:%M:%S')}"
        logger.info(log_message)
        logger.info(f"Logged out. Shutting down...")
    connection.close()


@dag(
    default_args=default_args,
    dag_id="LOG_IN_TO_PROD_DATABASES",
    schedule=dt.timedelta(days=12),
    start_date=pendulum.datetime(2024, 11, 7),
    catchup=False,
    tags=["miscellaneous"],
    doc_md=doc_md,
)
def taskflow():
    inputs = (
        (
            "log_in_to_ediskaz_as_mdm_integrator",
            OracleHook(oracle_conn_id="db_oracle_ediskaz__mdm_integrator", thick_mode=True),
        ),
        (
            "log_in_to_crmdb_as_mdm_integrator",
            OracleHook(oracle_conn_id="db_oracle_crmdb__mdm_integrator", thick_mode=True),
        ),
    )

    for _in in inputs:
        op = PythonOperator(
            task_id=_in[0],
            python_callable=login_to_oracle_db,
            op_args=[_in[1]],
        )


taskflow()
