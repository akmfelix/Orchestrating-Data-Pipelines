from datetime import datetime, timedelta
from time import sleep

from airflow import DAG, AirflowException
from airflow.operators.python_operator import BranchPythonOperator, PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.vertica.hooks.vertica import VerticaHook


home = "/opt/airflow/"
dags = home + "dags/"
sql = dags + "sql/Profile/"
mdm_hist_path = sql + "mdmhist_log.sql"


user_EDW_ETL_CDO = "EDW_ETL_CDO"
user_ETL_REP = "ETL_REP"
user_VERTICA = "Vertica_Prod"
profile_relation = "mdm_tech.profile_relation"
profile_log = "mdm_tech.profile_log"

default_args = {
    "owner": "NikitaMi",
    "email_on_failure": True,
    "start_date": datetime(2024, 3, 11),
    "email": ["NikitaMi@halykbank.kz", "AiysulySH@halykbank.kz"],
    "email_on_failure": True,
    # 'retries': 18, # 3 часа через каждые 10 минут если номера пакета нету retry, если появился то грузим
    # 'retry_delay': timedelta(minutes=10),
    "catchup": False,
}


def get_days(**kwargs):
    # print('kwargs', kwargs)
    global days
    days = kwargs["dag_run"].conf["days"]

    global DATE_VALUE
    DATE_VALUE = "to_char(CURRENT_DATE-" + str(days) + ")"
    # print('days', days)

    kwargs["ti"].xcom_push(key="days", value=days)
    kwargs["ti"].xcom_push(key="DATE_VALUE", value=DATE_VALUE)


def check_mdmhist(**kwargs):
    days = int(kwargs["ti"].xcom_pull(key="days", task_ids="get_days")[0])
    # print('days', days)

    date = (datetime.now() + timedelta(days=(days) * -1)).strftime("%Y-%m-%d")
    print("date", date)

    with open(mdm_hist_path, "r") as file:
        sql_script = file.read()
        # замена '${VAL_DATE}' на текущую дату
        sql_script = sql_script.replace("${VAL_DATE}", date)

        vertica_hook = VerticaHook(user_VERTICA)
        vertica_conn = vertica_hook.get_conn()
        vertica_cursor = vertica_conn.cursor()

        vertica_cursor.execute(sql_script)
        is_ready = vertica_cursor.fetchone()

        vertica_conn.commit()
        vertica_cursor.close()
        vertica_conn.close()
        # print('sql_script', sql_script)
        # print('is_ready', is_ready[0])
        # print('is_ready', type(is_ready[0]))
        if int(is_ready[0]) == 0:
            print("4 STEP IS NOT READY")
            sleep(600)
            return "trigger_src_flag"
        else:
            return "check_logs"


def check_logs(**kwargs):  # 5-ый приоритет сначала достаем хабы
    days = kwargs["ti"].xcom_pull(key="days", task_ids=["get_days"])[0]
    # print('pulled days', days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(
        """ 
        SELECT VRT_PROC_NAME, PRIORITY
        FROM (SELECT distinct upper(pl.VRT_PROC_NAME) VRT_PROC_NAME, pr.PRIORITY 
        FROM mdm_tech.profile_log pl
        JOIN mdm_tech.profile_relation pr 
            ON upper(PL.VRT_TABLE_NAME) = upper(pr.VRT_TABLE_NAME)
            AND upper(pl.VRT_PROC_NAME) = upper(pr.VRT_PROC_NAME)
            AND PRIORITY IN (5, 6, 7) 	
        WHERE 1=1
        AND DEPEND_READY_FL = 1 
        AND PROC_READY_FL IN (0, 3) 
        AND OPER_DATE = CURRENT_DATE-"""
        + str(days)
        + ")t ORDER BY PRIORITY"
    )

    ready_proc = vertica_cursor.fetchall()
    # print('ready_pr  oc', ready_proc)

    procedures = {}
    for i in ready_proc:
        procedures[i[0]] = i[1]
    print("procedures", procedures)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="procedures", value=procedures)


def update_start(proc, days):
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    sql_update = (
        " \
        UPDATE "
        + profile_log
        + " SET DATE_START = SYSDATE, PROC_READY_FL = 2 \
        WHERE upper(VRT_PROC_NAME) in(upper('"
        + proc
        + "')) AND OPER_DATE = CURRENT_DATE-"
        + str(days)
    )

    vertica_cursor.execute(sql_update)
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def proc_call(**kwargs):
    procedures = kwargs["ti"].xcom_pull(key="procedures", task_ids=["check_logs"])[0]
    print("pulled procedures", procedures)

    DATE_VALUE = kwargs["ti"].xcom_pull(key="DATE_VALUE", task_ids="get_days")
    # print('pulled  DATE_VALUE', DATE_VALUE)

    days = kwargs["ti"].xcom_pull(key="days", task_ids=["get_days"])[0]
    # print('pulled days', days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()
    for proc, priority in procedures.items():
        if proc is None:
            continue
        # sql_call_package = "CALL public."+proc+"("+ DATE_VALUE +", "+str(packageNum)+")"
        if priority == 7:
            scheme = "profile_dm"
        else:
            scheme = "profile_stg"  # profile_stg
        sql_call_no_package = "CALL " + scheme + "." + proc + "(" + DATE_VALUE + ")"
        print(sql_call_no_package)

        sql_update = (
            " \
        UPDATE "
            + profile_log
            + " SET DATE_END = SYSDATE, PROC_READY_FL = 1 \
        WHERE upper(VRT_PROC_NAME) in(upper('"
            + proc
            + "')) AND OPER_DATE = CURRENT_DATE-"
            + str(days)
        )

        sql_error = (
            " \
        UPDATE "
            + profile_log
            + " SET DATE_END = SYSDATE, PROC_READY_FL = 3 \
        WHERE upper(VRT_PROC_NAME) in(upper('"
            + proc
            + "')) AND OPER_DATE = CURRENT_DATE-"
            + str(days)
        )

        vertica_cursor.execute(
            """
            SELECT distinct upper(pr.VRT_TABLE_NAME), TRUNCATE_FLAG
            FROM mdm_tech.profile_relation pr 
            WHERE IS_ACTUAL=1 and upper(VRT_PROC_NAME)='"""
            + proc
            + "'"
        )

        vrt_tables = vertica_cursor.fetchall()
        # print('vrt_tables', vrt_tables)

        vrt_tables_dict = {}
        for i in vrt_tables:
            vrt_tables_dict[i[0]] = i[1]
        # print('vrt_tables_dict', vrt_tables_dict)

        try:
            flg = False
            for vrt_tbl in vrt_tables_dict.keys():
                if vrt_tables_dict[vrt_tbl] == 1:
                    print(
                        "select DROP_PARTITIONS ('"
                        + scheme
                        + "."
                        + vrt_tbl
                        + "', CURRENT_DATE-"
                        + str(int(days) - 1)
                        + ", CURRENT_DATE-"
                        + str(int(days) - 1)
                        + ");"
                    )
                    vertica_cursor.execute(
                        "select DROP_PARTITIONS ('"
                        + scheme
                        + "."
                        + vrt_tbl
                        + "', CURRENT_DATE-"
                        + str(int(days) - 1)
                        + ", CURRENT_DATE-"
                        + str(int(days) - 1)
                        + ");"
                    )
                    flg = True
                elif vrt_tables_dict[vrt_tbl] == -1:
                    print(
                        "select DROP_PARTITIONS ('"
                        + scheme
                        + "."
                        + vrt_tbl
                        + "', CURRENT_DATE-"
                        + str(days)
                        + ", CURRENT_DATE-"
                        + str(days)
                        + ");"
                    )
                    vertica_cursor.execute(
                        "select DROP_PARTITIONS ('"
                        + scheme
                        + "."
                        + vrt_tbl
                        + "', CURRENT_DATE-"
                        + str(days)
                        + ", CURRENT_DATE-"
                        + str(days)
                        + ");"
                    )
                    flg = True

            if flg:
                update_start(proc, days)
                vertica_cursor.execute(sql_call_no_package)
        except Exception as e:
            print("ERROR:", e)
            print("SQL ERROR on script", sql_call_no_package)
            vertica_cursor.execute(sql_error)
        else:
            vertica_cursor.execute(sql_update)
        vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


with DAG(
    tags=["PROFILE", "STEP_3"],
    catchup=False,
    dag_id="PROFILE_INTERNAL_LOAD",
    description="Ежедневная загрузка профиля клиента. 3-этап. Запуск внутренних процедур Vertica",
    owner_links={"NikitaMI ": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=727749873"},
    schedule_interval=None,
    default_args=default_args,
) as dag:
    get_days = PythonOperator(
        task_id="get_days",
        provide_context=True,
        python_callable=get_days,
        dag=dag,
    )

    check_mdmhist = BranchPythonOperator(
        task_id="check_mdmhist",
        python_callable=check_mdmhist,
        dag=dag,
    )

    trigger_src_flag = TriggerDagRunOperator(
        task_id="trigger_src_flag",
        trigger_dag_id="PROFILE_START",
        wait_for_completion=False,
        dag=dag,
    )

    check_logs = PythonOperator(
        task_id="check_logs",
        provide_context=True,
        python_callable=check_logs,
        dag=dag,
    )

    proc_call = PythonOperator(
        task_id="proc_call",
        provide_context=True,
        python_callable=proc_call,
        trigger_rule="none_failed",
        dag=dag,
    )

    timer = PythonOperator(
        task_id="timer",
        python_callable=lambda: sleep(600),
        trigger_rule="all_success",
        dag=dag,
    )

    trigger_src_flag2 = TriggerDagRunOperator(
        task_id="trigger_src_flag2",
        trigger_dag_id="PROFILE_START",
        trigger_rule="none_failed",
        wait_for_completion=False,
        dag=dag,
    )

get_days >> check_mdmhist >> [trigger_src_flag, check_logs] >> proc_call >> timer >> trigger_src_flag2
