import datetime as dt
import json
import logging
import typing

import oracledb
from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition

from source.telegram_notifications import TelegramErrorNotification


logger = logging.getLogger(__name__)

default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

columns = (
    "DEVICE_ID",
    "CLIENT_ID",
    "SNAPSHOT",
    "OPERATION_TYPE",
    "DEVICE_DATE",
    "GEO_STATUS",
    "GEO_SPEED",
    "GEO_HEADING",
    "GEO_FLOOR",
    "GEO_HORIZONTAL_ACCURANCY",
    "GEO_LATITUDE",
    "GEO_LONGITUDE",
    "GEO_ALTITUDE_ACCURACY",
    "GEO_TIMESTAMP",
    "GEO_ALTITUDE",
)


def deserialize_geo_data(event_dict: dict):
    mobile_sdk_data = event_dict["deviceRequest"].get("mobileSdkData")
    status = speed = heading = floor = horizontal_accuracy = latitude = longitude = altitude_accuracy = timestamp = (
        altitude
    ) = None

    if mobile_sdk_data is not None and mobile_sdk_data != "":
        geolocation_info = json.loads(mobile_sdk_data).get("GeoLocationInfo")
        if geolocation_info:
            status = geolocation_info.get("Status")
            speed = geolocation_info.get("Speed")
            heading = geolocation_info.get("Heading")
            floor = geolocation_info.get("Floor")
            horizontal_accuracy = geolocation_info.get("HorizontalAccuracy")

            latitude = geolocation_info.get("Latitude")
            longitude = geolocation_info.get("Longitude")
            if latitude:
                latitude /= 1_000
            if longitude:
                longitude /= 1_000

            altitude_accuracy = geolocation_info.get("AltitudeAccuracy")
            timestamp = geolocation_info.get("Timestamp")
            altitude = geolocation_info.get("Altitude")
    return (
        str(status) if status is not None else "",
        str(speed) if speed is not None else "",
        str(heading) if heading is not None else "",
        str(floor) if floor is not None else "",
        str(horizontal_accuracy) if horizontal_accuracy is not None else "",
        str(latitude) if latitude is not None else "",
        str(longitude) if longitude is not None else "",
        str(altitude_accuracy) if altitude_accuracy is not None else "",
        str(timestamp) if timestamp is not None else "",
        str(altitude) if altitude is not None else "",
    )


def deserialize_message(message: dict) -> typing.Tuple[typing.Any, ...]:
    event = message["event"]
    device_id = event.get("deviceId")
    consumer = event.get("consumer")
    if device_id:
        device_id = str.upper(device_id)

    if consumer:
        client_id = consumer.get("id")
    else:
        client_id = None

    if client_id:
        client_id = str.upper(client_id)

    timestamp = event.get("timestamp")
    # Deserialize timestamp and attach the UTC timezone (the original timestamp is in UTC time)
    deserialized_timestamp = dt.datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=dt.timezone.utc)
    # Convert to Almaty timezone (since current Airflow is of version 2.7.3 (with Python 3.8.18) it does not have a
    # zoneinfo module and the installed tzdata is oudated (the switch to +5 happened during the spring of 2024))
    converted_timestamp = deserialized_timestamp.astimezone(tz=dt.timezone(dt.timedelta(hours=5)))
    # snapshot = converted_timestamp.date()  # Extract date from timestamp
    snapshot = converted_timestamp.replace(hour=0, minute=0, second=0)
    device_date = converted_timestamp

    operation_type = event.get("operationType")

    return (
        device_id,
        client_id,
        snapshot,
        operation_type,
        device_date,
        *deserialize_geo_data(event),
    )


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deser_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    columns: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(columns)) if columns else "",
        values=", ".join(f":{i}" for i in range(1, len(columns) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.setinputsizes(
            200,
            200,
            oracledb.DB_TYPE_DATE,
            200,
            oracledb.DB_TYPE_DATE,
            100,
            300,
            300,
            300,
            300,
            100,
            100,
            500,
            300,
            500,
        )
        cursor.executemany(None, data)
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    oracle_hook: OracleHook,
    consumer_config: dict,
    topics: typing.List[str],
    batch_size: int,
    poll_timeout: float = 3.0,
    threshold: int = 0,
) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe(topics, on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages and len(consumed_messages) >= threshold:
                data = list(deserialize_message(deser_message(m)) for m in consumed_messages if m is not None)
                logger.info(f"Consumed {len(data)} messages")
                bulk_insert(connection, data, "DSSB_DE.RB_GEODATA", columns)
                consumer.commit()
            else:
                logger.info(f"There are less than {threshold} messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    dag_id="GEO_DATA_PERIODIC_CONSUMER",
    default_args=default_args,
    description="A DAG that reads homebank events from the 'hb-sfd-integration' topic, extracts geo data, and writes it to db",
    schedule=dt.timedelta(hours=1),
    start_date=dt.datetime(2024, 5, 31),
    catchup=False,
    max_active_runs=1,
    tags=["consumer", "kafka"],
):
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)
    kafka_config_id = "kafka_homebank_prod__hb-sfd-integration"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)
    kwargs = {
        "topics": ["hb-sfd-integration"],
        "poll_timeout": 5.0,
        "batch_size": 25_000,
        "threshold": 25_000,
        "consumer_config": consumer_config,
        "oracle_hook": oracle_hook,
    }
    consume_and_write_task = PythonOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        python_callable=consume_and_write,
        op_kwargs=kwargs,
        on_failure_callback=[TelegramErrorNotification()],
    )
    consume_and_write_task
