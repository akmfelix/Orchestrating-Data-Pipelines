from textwrap import TextWrapper, dedent
from typing import Tuple

import pendulum
from airflow.decorators import dag, task
from airflow.providers.oracle.hooks.oracle import OracleHook

from source.telegram_notifier import TelegramNotifier


@dag(
    default_args={
        "owner": "ErbolKo2",
    },
    dag_id="SB_TRIBE_ERROR_NOTIFICATION",
    schedule="0 3-9 * * *",
    start_date=pendulum.datetime(2024, 12, 1, tz="Asia/Oral"),
    catchup=False,
    max_active_runs=1,
    tags=["observability"],
)
def taskflow():
    def format_message(wrapper: TextWrapper, repo_name: str, task_name: str, err_message: str) -> str:
        err_message = wrapper.fill(dedent(err_message))
        return f"🛠️ Процесс — <b>{task_name}</b> из репозитория — <b>{repo_name}</b> упал с ошибкой:\n<code>{err_message}</code>"

    def fetch_error_tuples(oracle_hook: OracleHook, sql_statement: str) -> Tuple[str, str, str]:
        connection = oracle_hook.get_conn()
        with connection.cursor() as cursor:
            result_set = cursor.execute(sql_statement).fetchall()
        connection.close()
        return result_set

    @task(
        task_id="check_and_alert"
    )
    def check_and_alert(**context):
        bot_token = context["var"]["value"].get("telegram_bot_token")
        chat_id = context["var"]["value"].get("telegram_sb_notifications_chat_id")
        proxies = {
            "http": context["var"]["value"].get("http_proxy"),
            "https": context["var"]["value"].get("https_proxy"),
        }

        notifier = TelegramNotifier(bot_token=bot_token, chat_id=chat_id)
        wrapper = TextWrapper(width=24, initial_indent="> ", subsequent_indent="> ", max_lines=6,
                              replace_whitespace=True)

        ipc_errors_fetching_sql = """
            SELECT
                'SB_REP' AS task_rep,
                task_name,
                RUN_ERR_MSG AS msg
            FROM
                RB_REP.OPB_TASK_INST_RUN
            WHERE
                START_TIME >=
                CASE 
                    WHEN TO_NUMBER(TO_CHAR(sysdate, 'HH24')) = 3 THEN TRUNC(sysdate)
                    ELSE TRUNC(sysdate) + INTERVAL '1' HOUR * (to_number(TO_CHAR(sysdate, 'HH24')) - 1)
                END
                AND START_TIME < TRUNC(sysdate) + INTERVAL '1' HOUR * to_number(TO_CHAR(sysdate, 'HH24'))
                AND RUN_STATUS_CODE IN (3, 15)
                AND WORKFLOW_ID IN (5506, 5454, 5518, 5638, 5557, 5500, 5886, 5871)
        """
        ipc_errors = fetch_error_tuples(
            OracleHook(oracle_conn_id="db_oracle_ipc__edw_ipc", thick_mode=True), ipc_errors_fetching_sql
        )

        for repo_name, task_name, err_message in ipc_errors:
            message = format_message(wrapper, repo_name, task_name, err_message)
            response = notifier.send_message(message, proxies)

    check_and_alert()


taskflow()
