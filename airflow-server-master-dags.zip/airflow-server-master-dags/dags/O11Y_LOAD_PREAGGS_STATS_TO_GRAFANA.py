import datetime as dt
import time
from textwrap import TextWrapper, dedent

from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.postgres.hooks.postgres import PostgresHook

from source.telegram_notifier import TelegramNotifier


spark_files_dir = "/opt/airflow/temp/"
target_info_json_path = "/opt/airflow/dags/apps/DMCLIENTAGGREGATE_SPARK_LOAD/target_info.json"

default_args = {
    "owner": "AkejanA",
    "email": ["AkejanA@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

spark_default_conf = {
    "spark.master": "yarn",
    "spark.submit.deployMode": "cluster",
    "spark.yarn.queue": "dm",
    "spark.hadoop.yarn.timeline-service.enabled": False,  # НЕ УБИРАТЬ!!!!
    "spark.local.dir": spark_files_dir,
    # "spark.driver.extraJavaOptions": f"-Djson.file={target_info_json_path}"
}


def check_source_ready(oracle_hook):
    sql_query = """SELECT CASE
           WHEN COUNT(DISTINCT POR_OBJECTNAME) = 4 THEN 1
           ELSE 0
           END FLG
FROM INFA_MRS_MON_HK.PO_REQUESTSTAT REQSTAT
WHERE 1 = 1
  AND REQSTAT.POR_SERVICENAME = 'DIS_DEI_PROD_HALYKBANK'
  AND TO_DATE((TO_DATE('1970-01-01', 'YYYY-MM-DD') + INTERVAL '5' HOUR) +
              (REQSTAT.POR_STARTTIME / 1000) / (60 * 60 * 24)) > TRUNC(SYSDATE) - 1
  AND REQSTAT.POR_ENDTIME IS NOT NULL
  AND REQSTAT.POR_STATE = 1
  AND upper(REQSTAT.POR_OBJECTNAME) IN ('M_PREAGG_TRANSACTIONS',
                                        'M_PREAGG_ACCOUNT',
                                        'M_PREAGG_LOAN_REFOPER',
                                        'M_PREAGG_DEPOSIT_NEW')
"""
    oracle_conn = oracle_hook.get_conn()
    oracle_cur = oracle_conn.cursor()
    oracle_cur.execute(sql_query)
    data = oracle_cur.fetchone()[0]
    oracle_cur.close()
    oracle_conn.close()
    if data == 1:
        return "launch_spark_job"
    else:
        return "wait_task"


def spark_start_func(file_name):
    return SparkSubmitOperator(
        task_id="launch_spark_job",
        application="/opt/airflow/dags/apps/DMCLIENTAGGREGATE_SPARK_LOAD/" + str(file_name) + ".py",
        principal="ADH_Runner_CDO@HALYKBANK.NB",
        keytab="/opt/airflow/config/credentials/hadoop/krb5.keytab",
        name=file_name,
        py_files="/opt/airflow/dags/apps/DMCLIENTAGGREGATE_SPARK_LOAD/Tables.zip",
        executor_memory="2G",
        driver_memory="20G",
        num_executors=13,
        jars="/opt/airflow/dags/apps/DMCLIENTAGGREGATE_SPARK_LOAD/postgresql-42.6.0.jar",
        verbose=True,
        conf=spark_default_conf,
    )


def log_write(oracle_hook, pg_hook, **context):
    sql_query = """SELECT 
		sysdate AS date_change,
	    upper(REQSTAT.POR_OBJECTNAME) AS load_name,
	    (TO_DATE('1970-01-01','YYYY-MM-DD')+ INTERVAL '5' HOUR) + (REQSTAT.POR_STARTTIME/1000)/(60*60*24) AS begin_time,
        (TO_DATE('1970-01-01','YYYY-MM-DD')+ INTERVAL '5' HOUR) + (REQSTAT.POR_ENDTIME/1000)/(60*60*24) AS end_time,
        'SUCCEEDED' AS state
FROM INFA_MRS_MON_HK.PO_REQUESTSTAT REQSTAT
WHERE 1=1
 AND REQSTAT.POR_SERVICENAME = 'DIS_DEI_PROD_HALYKBANK' 
 AND TO_DATE((TO_DATE('1970-01-01','YYYY-MM-DD')+INTERVAL '5' HOUR) + (REQSTAT.POR_STARTTIME/1000)/(60*60*24)) > TRUNC(SYSDATE) -1
 AND REQSTAT.POR_ENDTIME IS NOT NULL 
 AND REQSTAT.POR_STATE = 1
 AND upper(REQSTAT.POR_OBJECTNAME) IN ('M_PREAGG_TRANSACTIONS',
									   'M_PREAGG_ACCOUNT',
									   'M_PREAGG_LOAN_REFOPER',
									   'M_PREAGG_DEPOSIT_NEW')
"""

    ora_conn = oracle_hook.get_conn()
    ora_cursor = ora_conn.cursor()
    ora_cursor.execute(sql_query)
    data = ora_cursor.fetchall()
    new_data = []
    postgres_conn = pg_hook.get_conn()
    postgres_cur = postgres_conn.cursor()
    postgres_cur.execute(
        """
    delete from public.all_load_log
where date_change >= date(now()) 
  and date_change < date(now())  + 1
  and load_name in ('M_PREAGG_TRANSACTIONS',
					'M_PREAGG_ACCOUNT',
					'M_PREAGG_LOAN_REFOPER',
					'M_PREAGG_DEPOSIT_NEW') 
    """
    )
    postgres_conn.commit()
    postgres_cur.executemany(
        f"insert into public.all_load_log(DATE_CHANGE, LOAD_NAME, BEGIN_TIME,END_TIME, STATE) values (%s, %s, %s, %s, %s)",
        data,
    )
    postgres_conn.commit()
    postgres_cur.close()
    postgres_conn.close()

    # Telegram_notification
    for date_change, load_name, begin_time, end_time, state in data:
        new_data.append(load_name)
    tabs_name = ", ".join(new_data)
    message = f"🛠️<b> {tabs_name} готовы </b>"

    bot_token = context["var"]["value"].get("telegram_bot_token")
    chat_id = context["var"]["value"].get("telegram_notifications_chat_id")
    proxies = {
        "http": context["var"]["value"].get("http_proxy"),
        "https": context["var"]["value"].get("https_proxy"),
    }
    notifier = TelegramNotifier(bot_token=bot_token, chat_id=chat_id)
    response = notifier.send_message(message, proxies)


with DAG(
    dag_id="O11Y_LOAD_PREAGGS_STATS_TO_GRAFANA",
    default_args=default_args,
    start_date=dt.datetime(2024, 11, 16),
    schedule="40 08 * * *",  # '@once', #timedelta(minutes=30),
    description="loading hive tables into postgres",
    catchup=False,
) as dag_spark:

    oracle_hook = OracleHook(oracle_conn_id="ETL_REP", thick_mode=True)
    postgres_hook = PostgresHook("monitoring")
    kwargs = {"oracle_hook": oracle_hook, "pg_hook": postgres_hook}

    start_task = DummyOperator(task_id="start_task")

    check_source_ready_task = BranchPythonOperator(
        task_id="check_source_ready_task", python_callable=check_source_ready, op_kwargs=kwargs
    )

    spark_start = spark_start_func("DMCLIENTAGGREGATE_SPARK_JOB")

    wait_task = PythonOperator(
        task_id="wait_task",
        python_callable=lambda: time.sleep(60 * 15),
    )

    restart_task = TriggerDagRunOperator(
        task_id="restart_task",
        trigger_dag_id="O11Y_LOAD_PREAGGS_STATS_TO_GRAFANA",
        reset_dag_run=True,
    )

    log_write_task = PythonOperator(
        task_id="log_write_task",
        python_callable=log_write,
        op_kwargs=kwargs,
        provide_context=True,
        dag=dag_spark,
    )

    end_task = DummyOperator(task_id="end_task")

    start_task >> check_source_ready_task
    check_source_ready_task >> wait_task >> restart_task
    check_source_ready_task >> spark_start >> log_write_task >> end_task
