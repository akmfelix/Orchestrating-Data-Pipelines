import datetime as dt
import json
import logging
import typing

import oracledb
import pendulum
from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition

from source.telegram_notifications import TelegramErrorNotification


logger = logging.getLogger(__name__)

default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

columns = (
    "EVENT_TIME",
    "EVENT_NAME",
    "HOMEBANK_USER_ID",
    "GLOBAL_BOOKING_ID",
    "CONTACT_NUMBER",
    "EMAIL_ADDRESS",
    "GLOBAL_BOOKING_CURRENCY",
    "GLOBAL_ADDITIONAL_SERVICES",
    "GLOBAL_AIRLINE_ANC_SVC_FEES",
    "GLOBAL_AIRLINE_FARES_TAXES",
    "GLOBAL_BOOKING_AMOUNT",
    "GLOBAL_TICKETING_FEE",
    "CALLBACK_PASSENGERS",
    "PAYMENTS",
    "TICKETING_GROUP",
    "IS_BOOKING_TICKETED",
    "IS_READY_FOR_TICKETING",
    "BOOKINGS",
)


def list_to_clob(s: typing.Union[None, typing.List]) -> str:
    if isinstance(s, list) and not s:
        s = None
    if s:
        s = json.dumps(s, ensure_ascii=False)  # Turn to CLOB
    return s


def parse_callback_resp_body(d: typing.Dict) -> typing.Tuple[typing.Any, ...]:
    if isinstance(d, str):
        d = json.loads(d)

    is_booking_ticketed = None
    is_ready_for_ticketing = None
    global_booking_id = None
    global_booking_currency = None
    global_booking_amount = None
    contact_number = None
    email_address = None
    payments = None

    global_additional_services = None
    global_airline_anc_svc_fees = None
    global_airline_fares_taxes = None
    global_ticketing_fee = None

    callback_passengers = None
    ticketing_group = None

    if d:
        contact_number = d.get("contactNumber")
        email_address = d.get("emailAddress")

        global_amount_details_dict = d.get("globalAmountDetails", None)
        if global_amount_details_dict and isinstance(global_amount_details_dict, dict):
            global_additional_services = global_amount_details_dict.get("globalAdditionalServices")
            global_airline_anc_svc_fees = global_amount_details_dict.get("globalAirlineAncSvcFees")
            global_airline_fares_taxes = global_amount_details_dict.get("globalAirlineFaresTaxes")
            global_booking_amount = global_amount_details_dict.get("globalBookingAmount")
            global_ticketing_fee = global_amount_details_dict.get("globalTicketingFee")

        global_booking_currency = d.get("globalBookingCurrency")
        global_booking_id = d.get("globalBookingID")

        # Convert bools to integers since Oracle can't handle bool values
        is_booking_ticketed = d.get("globalIsBookingTicketed")
        if isinstance(is_booking_ticketed, bool):
            is_booking_ticketed = int(is_booking_ticketed)

        is_ready_for_ticketing = d.get("globalIsReadyForTicketing")
        if isinstance(is_ready_for_ticketing, bool):
            is_ready_for_ticketing = int(is_ready_for_ticketing)

        callback_passengers = d.get("passengers", None)
        callback_passengers = list_to_clob(callback_passengers)

        payments = d.get("payments", None)
        payments = list_to_clob(payments)

        ticketing_group = d.get("ticketingGrp", None)
        ticketing_group = list_to_clob(ticketing_group)

    return (
        global_booking_id,
        contact_number,
        email_address,
        global_booking_currency,
        global_additional_services,
        global_airline_anc_svc_fees,
        global_airline_fares_taxes,
        global_booking_amount,
        global_ticketing_fee,
        callback_passengers,
        payments,
        ticketing_group,
        is_booking_ticketed,
        is_ready_for_ticketing,
    )


def parse_ttn_resp_body(d: typing.Dict) -> str:
    bookings = None

    if d:
        response = d.get("response")
        if response and isinstance(response, dict):
            bookings = response.get("bookings")

    bookings = list_to_clob(bookings)
    return bookings


def transforms(message_dict: dict, message_timestamp: int) -> typing.Tuple[typing.Any, ...]:
    event_time = dt.datetime.fromtimestamp(message_timestamp / 1000, tz=pendulum.timezone("Asia/Oral"))
    event_name = message_dict.get("eventName")
    homebank_user_id = message_dict.get("homebankUserID")

    global_booking_id = None
    contact_number = None
    email_address = None
    global_booking_currency = None
    global_additional_services = None
    global_airline_anc_svc_fees = None
    global_airline_fares_taxes = None
    global_booking_amount = None
    global_ticketing_fee = None
    callback_passengers = None
    payments = None
    ticketing_group = None
    is_booking_ticketed = None
    is_ready_for_ticketing = None

    bookings = None

    if resp_body := message_dict.get("respBody"):
        if event_name == "backend_booking_callback_ttn":
            bookings = parse_ttn_resp_body(resp_body)
        elif event_name == "backend_booking_callback":
            callback_tuple = parse_callback_resp_body(resp_body)
            (
                global_booking_id,
                contact_number,
                email_address,
                global_booking_currency,
                global_additional_services,
                global_airline_anc_svc_fees,
                global_airline_fares_taxes,
                global_booking_amount,
                global_ticketing_fee,
                callback_passengers,
                payments,
                ticketing_group,
                is_booking_ticketed,
                is_ready_for_ticketing,
            ) = callback_tuple

    return (
        event_time,
        event_name,
        homebank_user_id,
        global_booking_id,
        contact_number,
        email_address,
        global_booking_currency,
        global_additional_services,
        global_airline_anc_svc_fees,
        global_airline_fares_taxes,
        global_booking_amount,
        global_ticketing_fee,
        callback_passengers,
        payments,
        ticketing_group,
        is_booking_ticketed,
        is_ready_for_ticketing,
        bookings,
    )


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deserialize_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    target_cols: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(target_cols)) if target_cols else "",
        values=", ".join(f":{i}" for i in range(1, len(target_cols) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.setinputsizes(
            oracledb.DB_TYPE_DATE,
            100,
            50,
            100,
            20,
            100,
            10,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_CLOB,
            oracledb.DB_TYPE_CLOB,
            oracledb.DB_TYPE_CLOB,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_CLOB,
        )
        try:
            cursor.executemany(None, data, batcherrors=True)
        except Exception as e:
            print(e)
            print(data)
            for error in cursor.getbatcherrors():
                print(error.message)
                print(data[error.offset])
            raise e
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    topics: typing.List[str],
    oracle_hook: OracleHook,
    consumer_config: dict,
    table_name: str,
    target_columns: typing.Tuple[str, ...],
    batch_size: int,
    poll_timeout: float = 3.0,
    threshold: int = 0,
) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe(topics, on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages and len(consumed_messages) >= threshold:
                logger.info(f"Consumed {len(consumed_messages)} messages")
                data = list(
                    transforms(deserialize_message(m), m.timestamp()[1])
                    for m in consumed_messages
                    if m is not None  # and m.error() is None  # collect errors in a separate tuple
                )
                bulk_insert(
                    oracle_conn=connection,
                    data=data,
                    table_name=table_name,
                    target_cols=target_columns,
                )
                consumer.commit()
            else:
                logger.info(f"There are no more messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    dag_id="TRAVEL_EVENTS_CONSUMER",
    default_args=default_args,
    description="A DAG that reads Travel related events from the 'DAF_EVENTS_TRAVEL' topic and writes them to the DSSB DB",
    schedule="@hourly",
    start_date=pendulum.datetime(2024, 9, 27),
    catchup=False,
    max_active_runs=1,
    tags=["consumer", "kafka"],
):
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)
    kafka_config_id = "kafka_oper_prod__tribe_ecosystem_reader"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)
    # Override the group.id specified in config, to prevent commit collision with another consumer
    consumer_config["group.id"] = f"{consumer_config['group.id']}_TEST_GROUP"

    table_name = "DSSB_DE.EVENTS_HALYK_TRAVEL"

    kwargs = {
        "topics": ["DAF_EVENTS_TRAVEL"],
        "oracle_hook": oracle_hook,
        "consumer_config": consumer_config,
        "table_name": table_name,
        "target_columns": columns,
        "batch_size": 10,
        "threshold": 10,
        "poll_timeout": 5.0,
    }

    consume_and_write_task = PythonOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        python_callable=consume_and_write,
        op_kwargs=kwargs,
        on_failure_callback=[TelegramErrorNotification()],
    )
    consume_and_write_task
