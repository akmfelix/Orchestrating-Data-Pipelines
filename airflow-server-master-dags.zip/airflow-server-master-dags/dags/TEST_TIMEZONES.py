import datetime as dt
import logging
from importlib.metadata import version

import pendulum
from airflow.decorators import dag, task
from airflow.utils import timezone


logger = logging.getLogger(__name__)


@dag(
    default_args={
        "owner": "TleuserIz",
    },
    dag_id="TEST_TIMEZONES",
    schedule=None,
    start_date=dt.datetime(2024, 11, 11, tzinfo=dt.timezone.utc),
    catchup=False,
    tags=["example"],
)
def taskflow():
    @task(
        task_id="test_timezones",
    )
    def test_timezones():
        logger.info(f"Version of pytz {version('pytz')}")

        logger.info(f"pendulum.now(tz='Asia/Oral') returns {pendulum.now(tz='Asia/Oral')}")
        logger.info(f"pendulum.now(tz='Asia/Almaty') returns {pendulum.now(tz='Asia/Almaty')}")
        logger.info(f"pendulum.now(tz='local') returns {pendulum.now(tz='local')}")

        logger.info(f"dt.datetime.now() returns {dt.datetime.now()}")
        logger.info(f"pendulum.now() returns {pendulum.now()}")
        logger.info(f"timezone.utcnow() returns {timezone.utcnow()}")

    run_this_first = test_timezones()

    run_this_first


taskflow()
