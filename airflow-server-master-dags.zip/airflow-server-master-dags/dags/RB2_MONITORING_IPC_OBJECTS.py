import time
import datetime
import pandas as pd 

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.operators.email import EmailOperator

default_args = {
    "owner": "AkejanA",
    "email": ["AkejanA@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

def sql_check(oracle_hook):
    select = """
SELECT 
 	    WORKFLOW_ID,
	    WORKFLOW_NAME,
	    START_TIME,
	    END_TIME,
	    STATUS,
	    ERROR_MSG
FROM(
SELECT DISTINCT 
 		R1.WORKFLOW_ID,
	    R1.WORKFLOW_NAME,
	    R2.START_TIME,
	    R2.END_TIME,
	    CASE WHEN R2.RUN_ERR_CODE <> 0 THEN 'ERROR/WARNING'
	         WHEN R2.RUN_ERR_CODE = 0 AND R2.START_TIME IS NOT NULL AND R2.END_TIME IS NULL THEN 'RUNNING'
	         WHEN R2.START_TIME IS NULL THEN 'NOT STARTED'
	         ELSE 'SUCCESS'
	    END STATUS,
	    CASE WHEN R2.RUN_ERR_CODE <> 0 THEN R2.RUN_ERR_MSG
		     ELSE NULL 
		END ERROR_MSG,
		ROW_NUMBER() OVER (PARTITION BY R1.WORKFLOW_ID ORDER BY R2.START_TIME desc) AS rn
 FROM RB_REP.OPB_WFLOW_RUN R1
 LEFT JOIN RB_REP.OPB_WFLOW_RUN R2
   ON R1.WORKFLOW_ID = R2.WORKFLOW_ID
  AND R2.START_TIME >= trunc(sysdate)-1
  --AND R2.START_TIME < trunc(sysdate)
 WHERE UPPER(R1.WORKFLOW_ID) IN (4769,4772,3985,4687,4723,
                              4779,4398,4194,4911,3699,
                              5137,5098,4114,4706,4543,
                              5430,5731,5620)
   AND R1.START_TIME >= trunc(sysdate)-30

)
WHERE rn = 1 
"""
    ora_conn = oracle_hook.get_conn()
    cursor = ora_conn.cursor()
    cursor.execute(select)
    data = cursor.fetchall()
    dataframe = pd.DataFrame(data)
    dataframe.columns = ['WORKFLOW_ID','WORKFLOW_NAME','START_TIME','END_TIME','STATUS','ERROR_MSG']
    html_result = dataframe.to_html(index=False)
    ora_conn.close()
    if data is None:
        return None
    else:
        return html_result

with DAG(
        dag_id="RB2_MONITORING_IPC_OBJECTS",
        default_args=default_args,
        start_date=datetime.datetime(2024, 10, 14),
        schedule='0 9 * * *',    #'@once', #timedelta(minutes=30),
        catchup=False,
) as dag:
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_ipc__edw_ipc", thick_mode=True)
    content = sql_check(oracle_hook)
    kwargs = {"oracle_hook": oracle_hook}

    send_email_messege = EmailOperator(
        task_id="send_email_messege",
        to = ["DaniyarMussa@halykbank.kz","AkejanA@halykbank.kz","EstayA@halykbank.kz","ALMASA@halykbank.kz","QuanysQo@halykbank.kz"],
        subject="Cтатус workflow RB2 ",
        html_content=content,
        )
    
    send_email_messege

