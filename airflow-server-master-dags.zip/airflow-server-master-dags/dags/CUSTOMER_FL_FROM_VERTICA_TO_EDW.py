import time
from pathlib import Path, PurePath
import json

import pendulum
from airflow.decorators import dag, task
from airflow.operators.empty import EmptyOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.vertica.hooks.vertica import VerticaHook


sql = PurePath("/opt/airflow/dags/sql/Vertica/")


@dag(
    default_args={
        "owner": "ErbolKo2",
    },
    dag_id="CUSTOMER_FROM_VERTICA_TO_EDW",
    schedule="00 14 3 * *",
    start_date=pendulum.datetime(2024, 11, 13, tz="Asia/Oral"),
    catchup=False,
    max_active_runs=1,
    tags=["vertica", "edw"],
)
def taskflow():
    @task(task_id="start_task")
    def start_task(date):
        vertica_hook = VerticaHook("Vertica_Prod")
        vertica_conn = vertica_hook.get_conn()
        vertica_cursor = vertica_conn.cursor()
        flag_check_sql_fl = f"""
                           SELECT READY_FL from mdm_tech.profile_export_log pel where OPERATION_DATE  = '{date}' and VRT_TABLE_NAME = 'CUSTOMER_FL'
                       """
        vertica_cursor.execute(flag_check_sql_fl)
        flag_fl = vertica_cursor.fetchone()
        flag_check_sql_ul = f"""
                           SELECT READY_FL from mdm_tech.profile_export_log pel where OPERATION_DATE  = '{date}' and VRT_TABLE_NAME = 'CUSTOMER_UL'
                       """
        vertica_cursor.execute(flag_check_sql_ul)
        flag_ul = vertica_cursor.fetchone()

        if flag_fl is None:
            vertica_cursor.execute(
                f"""
                                        INSERT INTO mdm_tech.profile_export_log 
                                        values('CUSTOMER_FL', date '{date}', now(), now(),null , 0, 'Oracle')
                                """
            )
        if flag_ul is None:
            vertica_cursor.execute(
                f"""
                                        INSERT INTO mdm_tech.profile_export_log 
                                        values('CUSTOMER_UL', date '{date}', now(), now(),null , 0, 'Oracle')
                                """
            )
        vertica_conn.commit()
        vertica_cursor.close()
        vertica_conn.close()

        oracle_hook = OracleHook("EDW_ETL_CDO")
        oracle_conn = oracle_hook.get_conn()
        oracle_cursor = oracle_conn.cursor()

        date_obj = pendulum.parse(date).format("YYYYMMDD")
        oracle_cursor.execute(
            f"""
            BEGIN
                DM.TRUNCATE_PARTITION_P('CUSTOMER_UL', '{date_obj}');
                DM.TRUNCATE_PARTITION_P('CUSTOMER_FL', '{date_obj}');
            END;
            """
        )
        oracle_conn.commit()
        oracle_cursor.close()
        oracle_conn.close()

    @task.branch
    def check_flag(date):
        vertica_hook = VerticaHook("Vertica_Prod")
        vertica_conn = vertica_hook.get_conn()
        vertica_cursor = vertica_conn.cursor()
        flag_check_sql_fl = f"""
            SELECT PROC_READY_FL from mdm_tech.profile_log pl where VRT_TABLE_NAME = 'CUSTOMER_FL' AND OPER_DATE = '{date}'
        """
        vertica_cursor.execute(flag_check_sql_fl)
        flag_result_fl = vertica_cursor.fetchone()
        flag_check_sql_ul = f"""
            SELECT PROC_READY_FL from mdm_tech.profile_log pl where VRT_TABLE_NAME = 'CUSTOMER_UL' AND OPER_DATE = '{date}'
        """
        vertica_cursor.execute(flag_check_sql_ul)
        flag_result_ul = vertica_cursor.fetchone()
        vertica_cursor.close()
        vertica_conn.close()

        if flag_result_ul[0] == 1 and flag_result_fl[0] == 1:
            return ["CUSTOMER_FL_check_load_flag", "CUSTOMER_UL_check_load_flag"]
        elif flag_result_fl[0] == 1:
            return "CUSTOMER_FL_check_load_flag"
        elif flag_result_ul[0] == 1:
            return "CUSTOMER_UL_check_load_flag"
        else:
            print(f"Нету зависимости за этот день {date}")
            return "union_task"

    @task.branch
    def check_load_flag(vertica_tb, date):
        vertica_hook = VerticaHook("Vertica_Prod")
        vertica_conn = vertica_hook.get_conn()
        vertica_cursor = vertica_conn.cursor()
        flag_check_sql = f"""
                    SELECT READY_FL from mdm_tech.profile_export_log pel where OPERATION_DATE  = '{date}' and VRT_TABLE_NAME = '{vertica_tb}'
                """
        vertica_cursor.execute(flag_check_sql)
        flag_result = vertica_cursor.fetchone()
        vertica_cursor.close()
        vertica_conn.close()
        print(flag_result)

        if flag_result[0] == 0:
            return f"{vertica_tb}_decide_table"
        elif flag_result[0] == 2:
            return f"{vertica_tb}_decide_table"
        elif flag_result[0] == 1:
            return "skip_task"

    @task(task_id="decide_table")
    def decide_table(vertica_tb, date):
        data = {"CUSTOMER_FL": "CUSTOMER_FL.sql",
                "CUSTOMER_UL": "CUSTOMER_UL.sql"}
        filename = data.get(f"{vertica_tb}")
        query_file_sql = Path(sql / filename).read_text(encoding="utf-8")
        sql_query = query_file_sql.replace("${DATE_VALUE}", f"{date}")
        if vertica_tb == "CUSTOMER_FL":
            query1 = sql_query.replace("${parity}", "0")
            query2 = sql_query.replace("${parity}", "1")
            sql_script = {"even": query1, "odd": query2}
            print(sql_script, type(sql_script))
            return json.dumps(sql_script)
        else:
            sql_ul = {"full": sql_query}
            return json.dumps(sql_ul)

    @task(task_id="task_even_fl")
    def task_even_fl(vertica_tb, oracle_tb, query, date):
        sql_sc = json.loads(query)
        sql_script = sql_sc["even"]
        fetch_data_from_vertica_and_insert_to_oracle(vertica_tb, oracle_tb, sql_script, date)

    @task(task_id="task_odd_fl")
    def task_odd_fl(vertica_tb, oracle_tb, query, date):
        sql_sc = json.loads(query)
        sql_script = sql_sc["odd"]
        fetch_data_from_vertica_and_insert_to_oracle(vertica_tb, oracle_tb, sql_script, date)

    @task(task_id="full_ul")
    def full_ul(vertica_tb, oracle_tb, query, date):
        sql_sc = json.loads(query)
        sql_script = sql_sc["full"]
        fetch_data_from_vertica_and_insert_to_oracle(vertica_tb, oracle_tb, sql_script, date)

    def fetch_data_from_vertica_and_insert_to_oracle(vertica_tb, oracle_tb, sql_query, date):
        vertica_hook = VerticaHook("Vertica_Prod")
        vertica_conn = vertica_hook.get_conn()
        vertica_cursor = vertica_conn.cursor()

        oracle_hook = OracleHook("EDW_ETL_CDO")
        oracle_conn = oracle_hook.get_conn()
        oracle_cursor = oracle_conn.cursor()
        vertica_cursor.execute(
            f"""
            UPDATE mdm_tech.profile_export_log
                                  SET
                                  VRT_TABLE_NAME = '{vertica_tb}',
                                  DATE_START = NOW(),
                                  DATE_CHANGE = NOW(),
                                  DATE_END = NULL,
                                  READY_FL = 2,
                                  TARGET_DB = 'Oracle'
                                  where VRT_TABLE_NAME = '{vertica_tb}' and OPERATION_DATE = '{date}'
        """
        )
        vertica_conn.commit()
        print(f"Чтение и Запись данных за {date} таблица {vertica_tb}")

        vertica_cursor.execute(sql_query)
        oracle_value = ", ".join([":{}".format(i + 1) for i in range(len(vertica_cursor.description))])
        insert_sql = f"INSERT INTO {oracle_tb} VALUES ({oracle_value})"
        read_count = 0

        batch_size = 100000

        start_time = time.time()
        while True:
            batch_data = vertica_cursor.fetchmany(batch_size)
            if not batch_data:
                break
            try:
                oracle_cursor.executemany(insert_sql, batch_data, batcherrors=True)
                oracle_conn.commit()
                read_count += 1

            except Exception as e:
                print(f"Error:  {e}")
                for error in oracle_cursor.getbatcherrors():
                    print("Error", error.message, "at row offset", error.offset)
                    print(f"Problematic row is {batch_data[error.offset]}")
        print(f"Удачно прочитал {read_count * batch_size} количество строк")
        end_time = time.time() - start_time
        #print(end_time)
        vertica_cursor.execute(
            f"""
                                  UPDATE mdm_tech.profile_export_log
                                  SET
                                  VRT_TABLE_NAME = '{vertica_tb}',
                                  DATE_CHANGE = NOW(),
                                  DATE_END = NOW(),
                                  READY_FL = 1,
                                  TARGET_DB = 'Oracle'
                                  where VRT_TABLE_NAME = '{vertica_tb}' and OPERATION_DATE = '{date}'
                              """
        )
        vertica_conn.commit()
        oracle_conn.commit()
        oracle_cursor.close()
        oracle_conn.close()
        vertica_cursor.close()
        vertica_conn.close()

    trigger_next_run = TriggerDagRunOperator(
        task_id="trigger_next_run",
        trigger_dag_id="CUSTOMER_FROM_VERTICA_TO_EDW",
        execution_date=pendulum.now(tz="Asia/Oral") + pendulum.duration(minutes=60),
        wait_for_completion=False,
    )

    @task.branch(trigger_rule="none_failed_or_skipped")
    def union_task(date):
        vertica_hook = VerticaHook("Vertica_Prod")
        vertica_conn = vertica_hook.get_conn()
        vertica_cursor = vertica_conn.cursor()
        flag_check_sql_fl = f"""
            SELECT READY_FL from mdm_tech.profile_export_log pel where OPERATION_DATE  = '{date}' and VRT_TABLE_NAME = 'CUSTOMER_FL'
        """
        vertica_cursor.execute(flag_check_sql_fl)
        flag_result_fl = vertica_cursor.fetchone()
        flag_check_sql_ul = f"""
            SELECT READY_FL from mdm_tech.profile_export_log pel where OPERATION_DATE  = '{date}' and VRT_TABLE_NAME = 'CUSTOMER_UL'
        """
        vertica_cursor.execute(flag_check_sql_ul)
        flag_result_ul = vertica_cursor.fetchone()
        vertica_cursor.close()
        vertica_conn.close()
        time_now = pendulum.now(tz="Asia/Oral").time()
        stop_time = pendulum.time(23, 0, 0)

        if flag_result_fl[0] == 0 or flag_result_ul[0] == 0:
            if time_now <= stop_time:
                return "trigger_next_run"
            else:
                return "skip_task"
        else:
            return "skip_task"

    in_date = pendulum.now(tz="Asia/Oral").subtract(days=3).format("YYYY-MM-DD")
    start_task = start_task(in_date)
    skip_task = EmptyOperator(task_id="skip_task")
    union_task = union_task(in_date)

    check_flag = check_flag(in_date)

    check_load_flag_fl = check_load_flag.override(task_id="CUSTOMER_FL_check_load_flag")("CUSTOMER_FL", in_date)
    decide_table_fl = decide_table.override(task_id="CUSTOMER_FL_decide_table")("CUSTOMER_FL", in_date)
    task_even = task_even_fl("CUSTOMER_FL", "DM.CUSTOMER_FL", decide_table_fl, in_date)
    task_odd = task_odd_fl("CUSTOMER_FL", "DM.CUSTOMER_FL", decide_table_fl, in_date)

    check_load_flag_ul = check_load_flag.override(task_id="CUSTOMER_UL_check_load_flag")("CUSTOMER_UL", in_date)
    decide_table_ul = decide_table.override(task_id="CUSTOMER_UL_decide_table")("CUSTOMER_UL", in_date)
    full_ul = full_ul("CUSTOMER_UL", "DM.CUSTOMER_UL", decide_table_ul, in_date)

    full_fl = EmptyOperator(task_id="full_fl")

    start_task >> check_flag >> [check_load_flag_fl, check_load_flag_ul, union_task]

    check_load_flag_fl >> [decide_table_fl, skip_task]
    decide_table_fl >> [task_even, task_odd]
    [task_even, task_odd] >> full_fl

    check_load_flag_ul >> [decide_table_ul, skip_task]
    decide_table_ul >> full_ul

    [full_fl, full_ul] >> union_task
    union_task >> [trigger_next_run, skip_task]


taskflow()
