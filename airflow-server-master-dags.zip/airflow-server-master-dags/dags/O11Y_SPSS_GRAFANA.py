from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.postgres.hooks.postgres import PostgresHook


home = "/opt/airflow/"
dags = home + "dags/"
sql = dags + "sql/"

default_args = {
    "owner": "NikitaMi",
    "email_on_failure": True,
    "start_date": datetime(2023, 12, 19),
    "retries": 5,
    "retry_delay": timedelta(minutes=5),
    "catchup": False,
}

user_SPSS = "db_oracle_spss__spss_user_dracrm"
user_WF_MONITOR = "monitoring"

SQL_QUERY_1_path = sql + "SPSS_LOAD.sql"
SQL_QUERY_1 = open(SQL_QUERY_1_path, "r").read()
print(SQL_QUERY_1)


def extract_load(sql_query, user_oracle, user_postgres, postgres_table):
    oracle_hook = OracleHook(user_oracle)
    oracle_conn = oracle_hook.get_conn()
    oracle_cursor = oracle_conn.cursor()
    oracle_cursor.execute(sql_query)
    print(oracle_cursor)
    oracle_data = oracle_cursor.fetchall()

    postgres_hook = PostgresHook(user_postgres)
    postgres_hook.run(f"DELETE FROM {postgres_table}")
    postgres_query = "INSERT INTO " + postgres_table + " VALUES ({})".format(",".join(["%s"] * len(oracle_data[0])))
    print(postgres_query)
    postgres_conn = postgres_hook.get_conn()
    postgres_cursor = postgres_conn.cursor()
    postgres_cursor.executemany(postgres_query, oracle_data)
    postgres_conn.commit()
    postgres_cursor.close()
    postgres_conn.close()
    oracle_conn.close()


with DAG(
    tags=["GRAFANA", "O11Y", "MONITORING", "SPSS"],
    start_date=datetime(2023, 12, 19),
    catchup=False,
    dag_id="O11Y_SPSS_GRAFANA",
    description="ETL process to migrate data for SPSS Pre/Soft Collection Grafana",
    owner_links={"NikitaMi": "https://confluence.halykbank.kz/display/CDO/SoftPreCollection"},
    schedule_interval="0,5,10,15,20,25,30,35,40,45,50,55 8-19 * * 1-5",
    default_args=default_args,
) as dag:
    start_task = DummyOperator(task_id="start_task", dag=dag)
    end_task = DummyOperator(task_id="end_task", dag=dag)

    spss_load = PythonOperator(
        task_id="spss_load",
        python_callable=extract_load,
        op_args=[SQL_QUERY_1, user_SPSS, user_WF_MONITOR, "public.spss_monitoring"],
        provide_context=True,
        dag=dag,
    )


start_task >> spss_load >> end_task
