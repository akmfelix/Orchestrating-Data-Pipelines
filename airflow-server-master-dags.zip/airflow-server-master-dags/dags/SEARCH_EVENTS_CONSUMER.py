import datetime as dt
import json
import logging
import typing

import oracledb
import pendulum
from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition

from source.telegram_notifications import TelegramErrorNotification


logger = logging.getLogger(__name__)

default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
    "on_failure_callback": [TelegramErrorNotification()],
}

columns = (
    "SESSION_ID",
    "SEARCH_SESSION_ID",
    "PUBLIC_ID",
    "LANGUAGE",
    "LOGIN",
    "CLIENT_ID",
    "SEARCH_DATE",
    "IP",
    "DEVICE_ID",
    "OPERATION_SYSTEM",
    "OPERATION_SYSTEM_VERSION",
    "APP_VERSION_CODE",
    "APP_VERSION_NAME",
    "ACTION_",
    "HIT",
    "PAGE",
    "SEARCH_TYPE",
    '"SIZE"',
    "SOURCE",
    "TAB_NAME",
    "SEARCH_RESULT",
    "KEYWORDS",
)


def transforms(message: dict) -> typing.Tuple[typing.Any, ...]:
    session_id = message["sessionId"]
    search_session_id = message["searchSessionId"]
    public_id = message["publicId"]
    language = message["language"]
    login = message["login"]
    client_id = message["clientId"]
    date = message["date"]
    ip = message["ip"]
    device_id = message["deviceId"]
    operation_system = message["operationSystem"]
    operation_system_version = message["operationSystemVersion"]
    app_version_code = message["appVersionCode"]
    app_version_name = message["appVersionName"]
    action = message["action"]

    params = message.get("params")
    if params:
        hit = params.get("hit")
        keywords = params.get("keywords")
        page = params.get("page")
        search_type = params.get("search_type")
        size = params.get("size")
        source = params.get("source")
        tab_name = params.get("tab_name")
        search_result = params.get("search_result")
        if search_result:  # Check if it is an empty list
            search_result = json.dumps(search_result, ensure_ascii=False)
        else:
            search_result = None
    else:
        hit = None
        keywords = None
        page = None
        search_type = None
        size = None
        source = None
        tab_name = None
        search_result = None

    date = dt.datetime.strptime(date, "%Y-%m-%d %H:%M:%S")

    return (
        session_id,
        search_session_id,
        public_id,
        language,
        login,
        client_id,
        date,
        ip,
        device_id,
        operation_system,
        operation_system_version,
        app_version_code,
        app_version_name,
        action,
        # fields from inner dictionary
        hit,
        page,
        search_type,
        size,
        source,
        tab_name,
        search_result,
        keywords,
    )


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deserialize_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    target_cols: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(target_cols)) if target_cols else "",
        values=", ".join(f":{i}" for i in range(1, len(target_cols) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.setinputsizes(
            64,
            64,
            64,
            64,
            64,
            64,
            oracledb.DB_TYPE_DATE,
            64,
            64,
            64,
            64,
            64,
            64,
            64,
            oracledb.DB_TYPE_NUMBER,
            oracledb.DB_TYPE_NUMBER,
            64,
            oracledb.DB_TYPE_NUMBER,
            64,
            64,
            oracledb.DB_TYPE_CLOB,
            oracledb.DB_TYPE_CLOB,
        )
        cursor.executemany(None, data)
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    topics: typing.List[str],
    oracle_hook: OracleHook,
    consumer_config: dict,
    table_name: str,
    target_columns: typing.Tuple[str, ...],
    batch_size: int,
    poll_timeout: float = 3.0,
    threshold: int = 0,
) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe(topics, on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages and len(consumed_messages) >= threshold:
                data = list(
                    transforms(deserialize_message(m))
                    for m in consumed_messages
                    if m is not None  # and m.error() is None  # collect errors in a separate tuple
                )
                logger.info(f"Consumed {len(data)} messages")
                bulk_insert(
                    oracle_conn=connection,
                    data=data,
                    table_name=table_name,
                    target_cols=target_columns,
                )
                consumer.commit()
            else:
                logger.info(f"There are no more messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    dag_id="SEARCH_EVENTS_CONSUMER",
    default_args=default_args,
    description="A DAG that reads search-related events from the 'event-search' topic and writes them to db",
    schedule="@hourly",
    start_date=pendulum.datetime(2024, 9, 27),
    catchup=False,
    max_active_runs=1,
    tags=["consumer", "kafka"],
):
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)
    kafka_config_id = "kafka_homebank_prod__event-search"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)
    table_name = "DSSB_DE.search_events"
    kwargs = {
        "topics": ["event-search"],
        "oracle_hook": oracle_hook,
        "consumer_config": consumer_config,
        "table_name": table_name,
        "target_columns": columns,
        "batch_size": 5_000,
        "poll_timeout": 3.0,
        "threshold": 5_000,
    }

    consume_and_write_task = PythonOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        python_callable=consume_and_write,
        op_kwargs=kwargs,
    )
    consume_and_write_task
