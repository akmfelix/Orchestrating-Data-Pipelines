import datetime

from airflow.decorators import dag, task

from source.telegram_notifications import (
    TelegramErrorNotification,
    TelegramSuccessNotification,
)


@dag(
    default_args={
        "owner": "TleuserIz",
        "on_failure_callback": [TelegramErrorNotification()],
        "on_success_callback": [TelegramSuccessNotification()],
    },
    dag_id="EXAMPLE_OF_USING_CALLBACK_NOTIFICATIONS",
    schedule=None,
    start_date=datetime.datetime(2024, 7, 23, tzinfo=datetime.timezone.utc),
    catchup=False,
    tags=["example", "o11y"],
)
def taskflow():
    @task(
        task_id="test_error_callback",
    )
    def deliberately_fail():
        raise Exception("I've failed you!")

    @task(
        task_id="test_success_callback",
    )
    def deliberately_succeed():
        return None

    run_this_first = deliberately_succeed()
    run_this_second = deliberately_fail()

    run_this_first >> run_this_second


taskflow()
