from pyspark.sql import SparkSession
from pyspark.sql.functions import col, concat_ws, length, lit, concat, when
from pyspark.sql.types import StringType, DateType, FloatType, IntegerType,BooleanType
import json
import datetime

sparkSession = SparkSession.builder.appName("dmclientaggr_spark_job").getOrCreate()

import Tables.target_info as trgt

#print(trgt.table_info['target_table'])


json_df = sparkSession.read.json("hdfs:///user/ADH_Runner_CDO/postgres_db_inf.json")

js_dbtable = json_df.first()['dbtable']
js_url = json_df.first()['url']
js_password = json_df.first()['password']
js_user = json_df.first()['user']


df_load = sparkSession.read.orc(trgt.table_info['preagg_loan_ref_oper']['source_path'])
df_load = df_load.withColumn('new_oper_year',df_load["oper_year"].cast(StringType()))\
                    .withColumn('new_oper_month',df_load["oper_month"].cast(StringType()))\
                    .withColumn('new_oper_day',df_load["oper_day"].cast(StringType()))

df_load = df_load.withColumn("new_oper_month", when(length(df_load['new_oper_month'])<2,concat_ws("",lit("0"),col('new_oper_month'))).otherwise(df_load['new_oper_month']))\
                .withColumn("new_oper_day", when(length(df_load['new_oper_day'])<2,concat_ws("",lit("0"),col('new_oper_day'))).otherwise(df_load['new_oper_day']))

df_load.groupby(concat_ws("-",col("new_oper_year"),col("new_oper_month"),col("new_oper_day")).cast(DateType()).alias("act_date"))\
            .count().withColumnRenamed("count","cnt").withColumn("target_table",lit(trgt.table_info['preagg_loan_ref_oper']['target_table']))\
            .withColumn("table_type",lit(trgt.table_info['preagg_loan_ref_oper']['table_type']))\
            .withColumn("s$change_date",lit(datetime.date.today()))\
            .write.format("jdbc")\
            .option("url", js_url) \
            .option("truncate", True)\
            .option("driver", "org.postgresql.Driver").option("dbtable", js_dbtable) \
            .option("user", js_user).option("password", js_password).mode("overwrite").save()

del df_load

df_load = sparkSession.read.orc(trgt.table_info["preagg_deposit_new"]['source_path'])

df_load.groupby(df_load.act_date.alias("act_date"))\
            .count().withColumnRenamed("count","cnt").withColumn("target_table",lit(trgt.table_info['preagg_deposit_new']['target_table']))\
            .withColumn("table_type",lit(trgt.table_info['preagg_deposit_new']['table_type']))\
            .withColumn("s$change_date",lit(datetime.date.today()))\
            .write.format("jdbc")\
            .option("url", js_url) \
            .option("driver", "org.postgresql.Driver").option("dbtable", js_dbtable) \
            .option("user", js_user).option("password", js_password).mode("append").save()

del df_load

df_load = sparkSession.read.orc(trgt.table_info["preagg_tr_transactions"]['source_path'])

df_load.groupby(df_load.act_date.alias("act_date"))\
            .count().withColumnRenamed("count","cnt").withColumn("target_table",lit(trgt.table_info['preagg_tr_transactions']['target_table']))\
            .withColumn("table_type",lit(trgt.table_info['preagg_tr_transactions']['table_type']))\
            .withColumn("s$change_date",lit(datetime.date.today()))\
            .write.format("jdbc")\
            .option("url", js_url) \
            .option("driver", "org.postgresql.Driver").option("dbtable", js_dbtable) \
            .option("user", js_user).option("password", js_password).mode("append").save()

del df_load

df_load = sparkSession.read.orc(trgt.table_info["preagg_trns_account"]['source_path'])

df_load.groupby(df_load.act_date.alias("act_date"))\
            .count().withColumnRenamed("count","cnt").withColumn("target_table",lit(trgt.table_info['preagg_trns_account']['target_table']))\
            .withColumn("table_type",lit(trgt.table_info['preagg_trns_account']['table_type']))\
            .withColumn("s$change_date",lit(datetime.date.today()))\
            .write.format("jdbc")\
            .option("url", js_url) \
            .option("driver", "org.postgresql.Driver").option("dbtable", js_dbtable) \
            .option("user", js_user).option("password", js_password).mode("append").save()



#df_load.filter((df_load.act_year == '2024')&(df_load.act_month=='10')&(df_load.act_day=='23'))\
#    .select('iin_bin','credit_sum_nat','debet_sum_nat','load_date','act_date','act_year','act_month','act_day')\
 #   .write.format("jdbc")\
#    .option("url", "jdbc:postgresql://172.28.82.21:5432/monitoring") \
 #   .option("driver", "org.postgresql.Driver").option("js_dbtable", "public.akz_test") \
 #   .option("user", "wf_monitor").option("js_password", "wfmonitorDB").mode("append").save()

#df_load.select('iin_bin','credit_sum_nat','debet_sum_nat','load_date','act_date','act_year','act_month','act_day').write.format("jdbc")\
#    .option("url", "jdbc:postgresql://172.28.82.21:5432/monitoring") \
#    .option("driver", "org.postgresql.Driver").option("js_dbtable", "public.akz_test") \
#    .option("user", "wf_monitor").option("js_password", "wfmonitorDB").mode("append").save()
