from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType


def connect():
    # Read

    conf = SparkConf().setAppName("RISK_PKB_REPORTS_TABLES").set("spark.hadoop.yarn.timeline-service.enabled", "false") \
        .set("spark.driver.extraClassPath", "ojdbc8-21.1.0.0.jar")#.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    sc = SparkContext(conf=conf)
    sq = SQLContext(sc)

    return sq


schema = StructType([
    StructField("idx", StringType(), True),
    StructField("extid", StringType(), True),
    StructField("receivetime", StringType(), True),
    StructField("status_", StringType(), True),
    StructField("qid", StringType(), True),
    StructField("seltype", StringType(), True),
    StructField("selval", StringType(), True),
    StructField("reporttype", StringType(), True),
    StructField("qtype", StringType(), True),
    StructField("comm", StringType(), True),
    StructField("userid", StringType(), True),
    StructField("actfl", StringType(), True),
    StructField("mplace", StringType(), True),
    StructField("btype", StringType(), True),
    StructField("customdep", StringType(), True),
    StructField("company", StringType(), True),
    StructField("load_date", StringType(), True)
])


def hdfs_list(sq, path, subtract_one=True):
    fs = sq._jvm.org.apache.hadoop.fs.FileSystem.get(sq._jsc.hadoopConfiguration())
    list_status = fs.listStatus(sq._jvm.org.apache.hadoop.fs.Path(path))
    files_names = [file.getPath().getName() for file in list_status]

    return files_names


def run(path):
    df = sq.read.parquet(path)
    xml_list = [[row.report_xml, row.idx, row.reporttype] for row in df.collect()]
    xml_list_filter = []
    for p in xml_list:
        if p[2] in (4, 6):
            xml_list_filter.append(p)
    xml_list = []
    l_temp_reports = parse(sq, log, xml_list_filter, 'Pkb_reports')
    l_temp_contracts = parse(sq, log, xml_list_filter, 'Pkb_contracts')
    l_temp_payments = parse(sq, log, xml_list_filter, 'Pkb_payments')
    df = df.drop("report_xml")

    return l_temp_reports, l_temp_contracts, l_temp_payments, df


def oracleWriter(df, df_base, schema, SID, table_name, flag=0):
    df = sq.createDataFrame(df, schema)
    if table_name == 'DDS.PKB_CLIENT_REPORTS_FL':
        df = df_base.join(df, df_base.idx == df.idx_xml, "left")
    else:
        df = df_base.join(df, df_base.idx == df.idx_xml, "inner")
    df = dataFrameTransformDDS(df)
    df = dfAdditionalTransform(df, table_name, flag)
    # Write to Oracle
    log.WARN('DF saving to Oracle started')
    dfToOracle(df, SID, table_name, log, sq)
    df.unpersist()
    log.WARN('DF successfully saved to Oracle')


if __name__ == '__main__':

    # Creating Application
    sq = connect()

    import Schemas.shemaStructs as sch

    from Logging.Logger import Logger
    from Writers.functions import *

    log = Logger('WARN')

    sql = "(" \
          "SELECT MIN(OPER_DATE) as OPER_DATE FROM RISKDM.AIRFLOW_ETL_DATA WHERE STATUS = 'WAITING' AND DAG_NAME = 'EDW_PKB_RISKDM'" \
          ") t"

    from Writers.functions import getPass

    url = "jdbc:oracle:thin:@EDWDB_PROD:1521/EDW"
    driver = "oracle.jdbc.driver.OracleDriver"
    user = "EDW_ETL_CDO"
    password = getPass(sq, 'EDW', user)

    # Getting start date
    df_date = sq.read.format("jdbc").option("url", url) \
        .option("driver", driver) \
        .option("user", user).option("password", password).load(
        dbtable=sql
    )
    date = df_date.collect()
    date = str(date[0][0])

    path = "/nifi/raw/HBPROJ/REPORTS/oper_date_year=" + date[0:4] + "/oper_date_month=" + date[
                                                                                          5:7] + "/oper_date_day=" + date[
                                                                                                                     8:10] + "/version=1/"
    path_to_parse = "/edi_raw/risk/forload/buroscope/reports/"

    df = sq.read.orc(path)
    df.write.save('/edi_raw/risk/forload/buroscope/reports/', format='parquet', mode='overwrite')
    df.unpersist()

    files_names = hdfs_list(sq, path_to_parse)
    # files_names = hdfs_list(sq, path)
    files_names = [path_to_parse + s for s in files_names]
    files_names = [file for file in files_names if file != '/edi_raw/risk/forload/buroscope/reports/_SUCCESS']

    l_final_reports = []
    l_final_contracts = []
    l_final_payments = []
    df_orc = sq.createDataFrame([], schema)
    for chunk in files_names:
        l_temp_reports, l_temp_contracts, l_temp_payments, df = run(chunk)
        l_final_reports = l_final_reports + l_temp_reports
        l_final_contracts = l_final_contracts + l_temp_contracts
        l_final_payments = l_final_payments + l_temp_payments
        df_orc = df_orc.union(df)

    log.WARN('Final Reports: ' + str(len(l_final_reports)))
    log.WARN('Final Contracts: ' + str(len(l_final_contracts)))
    log.WARN('Final Contract Payments: ' + str(len(l_final_payments)))

    # try:
    oracleWriter(l_final_reports, df_orc, sch.schema_reports, 'EDW', 'DDS.PKB_CLIENT_REPORTS_FL')
    # except:
        # log.WARN('DDS.PKB_CLIENT_REPORTS_FL Writer failed')

    # try:
    oracleWriter(l_final_contracts, df_orc, sch.schema_contracts, 'EDW', 'DDS.PKB_CLIENT_CONTRACTS_FL')
    # except:
        # log.WARN('DDS.PKB_CLIENT_CONTRACTS_FL Writer failed')

    # try:
    oracleWriter(l_final_payments, df_orc, sch.schema_payments, 'EDW', 'DDS.PKB_CONTRACT_PAYMENTS_FL')
    # except:
        # log.WARN('DDS.PKB_CONTRACT_PAYMENTS_FL Writer failed')

    log.INFO('Program finished')
