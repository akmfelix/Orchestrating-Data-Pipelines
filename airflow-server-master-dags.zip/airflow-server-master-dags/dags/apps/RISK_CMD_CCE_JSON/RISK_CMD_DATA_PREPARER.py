from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType, DateType, TimestampType, DecimalType, ArrayType,LongType
from pyspark.sql import Row
from collections import OrderedDict
from subprocess import Popen, PIPE
from pyspark.sql.functions import regexp_replace, lit, to_date
import time
from datetime import datetime, timedelta
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number

url = "jdbc:oracle:thin:@172.28.74.10:1521/EDW"
driver = "oracle.jdbc.driver.OracleDriver"
user = "EDW_ETL_CDO"


def connect():
    # Read
    conf = SparkConf().setAppName("RISK_CMD_DATA_PREPARER").set("spark.hadoop.yarn.timeline-service.enabled", "false")\
        .set("spark.driver.extraClassPath","/opt/airflow/dags/apps/RISK_CMD_CCE_JSON/jars/ojdbc8-21.1.0.0.jar") #\
        #.set("spark.hadoop.avro.mapred.ignore.inputs.without.extension", "false")
    sc = SparkContext(conf=conf)
    sq = SQLContext(sc)
    return sq

    # hdfs dfs -rm -r /edi_raw/risk/airflow_etl_data

if __name__ == '__main__':

    sql = "(" \
          "SELECT MIN(OPER_DATE) as OPER_DATE FROM RISKDM.AIRFLOW_ETL_DATA WHERE STATUS = 'WAITING' AND DAG_NAME = 'EDW_CMD_RISKDM'" \
          ") t"

    sq = connect()
    from Writers.functions import getPass
    print("LOGGER WARN Connected")

    password = getPass(sq, 'EDW', user)
    # Getting start date
    df_date = sq.read.format("jdbc").option("url", url) \
        .option("driver", driver) \
        .option("user", user).option("password", password).load(
        dbtable=sql
    )
    date = df_date.collect()
    date = str(date[0][0])
    print("LOGGER WARN Start date " + date)

    path = "/nifi/raw/kafka_styx/camunda/CMND_CREDIT_COMMODITYCREDITEVENTS/" + date[0:4] + "/" + date[5:7] + "/" +  date[8:10] + "/"

    print("LOGGER WARN Reading data")
    # df = sq.read.format("com.databricks.spark.avro").load(path)
    df = sq.read.json(path)
    print("LOGGER WARN Data successfully read")

    df = df.withColumn("row", row_number().over(Window.partitionBy("processID").orderBy(col("lastUpdatedTime").desc())))\
        .filter(col("row") == 1).drop("row")

    print("LOGGER WARN Saving data")
    df.write.save('/edi_raw/risk/forload/camunda/commodity-credit-events/', format='json', mode='overwrite')
    print("LOGGER WARN Data successfully saved")
