from datetime import datetime, timedelta
from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType, DateType, TimestampType, DecimalType
import time
from pyspark.sql.functions import regexp_replace, lit, to_date
from setting_funcs.ORA_CONF import getEDWTESTConf, getPass, dfToOracle
from setting_funcs.HDFS_CONF import  hdfs_list, connect

schema = StructType([
    StructField("processID", StringType(), True),
    StructField("processCreate", TimestampType(), True),
    StructField("iin", StringType(), True),
    StructField("clientID", StringType(), True),
    StructField("orderID", StringType(), True),
    StructField("creditProductType", StringType(), True),
    StructField("requestAmount", DecimalType(20,2), True),
    StructField("amountDuration", DecimalType(), True),
    StructField("paymentType", StringType(), True),
    StructField("deliveryType", DecimalType(), True),
    StructField("deliveryCity", StringType(), True),
    StructField("deliveryAddress", StringType(), True),
    StructField("pickupPointName", StringType(), True),
    StructField("ipAddress", StringType(), True),
    StructField("deviceID", StringType(), True),
    StructField("browserType", StringType(), True),
    StructField("browserVersion", StringType(), True),
    StructField("osType", StringType(), True),
    StructField("osVersion", StringType(), True),
    StructField("appDTInstall", DateType(), True),
    StructField("appVersion", StringType(), True),
    StructField("latitude", DecimalType(), True),
    StructField("longitude", DecimalType(), True),
    StructField("fio", StringType(), True),
    StructField("mobile", StringType(), True),
    StructField("birthDate", DateType(), True),
    StructField("email", StringType(), True),
    StructField("city", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("processReference", StringType(), True)
])

def dataFrameTransform(df):
    df = df.withColumn('DATE_VALUE', df.processCreate)
    df = df.withColumn('DATE_VALUE', df.DATE_VALUE.cast(DateType()))
    df = df.withColumn('GM_SYSTEM_CODE', lit("CMD"))
    df = df.withColumn('DATE_CHANGE', lit(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    df = df.withColumn('DATE_CHANGE', df.DATE_CHANGE.cast(TimestampType()))

    df = df.withColumnRenamed('amountDuration', 'AMOUNT_DURATION')
    df = df.withColumnRenamed('appDTInstall', 'APP_DTINSTALL')
    df = df.withColumnRenamed('appVersion', 'APP_VERSION')
    df = df.withColumnRenamed('birthDate', 'BIRTH_DATE')
    df = df.withColumnRenamed('browserType', 'BROWSER_TYPE')
    df = df.withColumnRenamed('browserVersion', 'BROWSER_VERSION')
    df = df.withColumnRenamed('city', 'CITY')
    df = df.withColumnRenamed('clientID', 'CLIENTID')
    df = df.withColumnRenamed('creditProductType', 'CREDIT_PRODUCT_TYPE')
    df = df.withColumnRenamed('deliveryAddress', 'DELIVERY_ADDRESS')
    df = df.withColumnRenamed('deliveryCity', 'DELIVERY_CITY')
    df = df.withColumnRenamed('deliveryType', 'DELIVERY_TYPE')
    df = df.withColumnRenamed('deviceID', 'DEVICE_ID')
    df = df.withColumnRenamed('email', 'EMAIL')
    df = df.withColumnRenamed('fio', 'FIO')
    df = df.withColumnRenamed('gender', 'GENDER')
    df = df.withColumnRenamed('iin', 'IIN')
    df = df.withColumnRenamed('ipAddress', 'IP_ADDRESS')
    df = df.withColumnRenamed('latitude', 'LATITUDE')
    df = df.withColumnRenamed('longitude', 'LONGITUDE')
    df = df.withColumnRenamed('mobile', 'MOBILE')
    df = df.withColumnRenamed('orderID', 'ORDERID')
    df = df.withColumnRenamed('osType', 'OS_TYPE')
    df = df.withColumnRenamed('osVersion', 'OS_VERSION')
    df = df.withColumnRenamed('paymentType', 'PAYMENT_TYPE')
    df = df.withColumnRenamed('pickupPointName', 'PICKUP_POINT_NAME')
    df = df.withColumnRenamed('processCreate', 'PROCESSCREATE')
    df = df.withColumnRenamed('processID', 'PROCESSID')
    df = df.withColumnRenamed('requestAmount', 'REQUEST_AMOUNT')
    df = df.withColumnRenamed('processReference', 'PROCESS_REF')
    
    return df

def oracleWriter(df, SID, table_name):

    dfToOracle(df, SID, table_name, sq)
    df.unpersist()

def loader(df):
    df_load = dataFrameTransform(df)

    oracleWriter(df_load, 'EDW', 'RISKDM.CMD_CCE_PROCESSES_FL_STAGE')
    df_load.unpersist()

if __name__ == '__main__':

    sq = connect()

    path = "/edi_raw/risk/forload/camunda/commodity-credit-events/"

    files_names = hdfs_list(sq, path)
    files_names = [path + s for s in files_names]

    df = sq.read.json(files_names, schema)
    loader(df)
