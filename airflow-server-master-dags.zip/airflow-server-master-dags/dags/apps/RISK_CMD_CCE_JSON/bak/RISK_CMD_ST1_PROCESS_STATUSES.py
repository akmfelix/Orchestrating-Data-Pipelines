from datetime import datetime, timedelta
from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType, DateType, TimestampType, DecimalType, ArrayType, LongType
import time
from pyspark.sql.functions import regexp_replace, lit, to_date
from setting_funcs.ORA_CONF import getEDWTESTConf, getPass, dfToOracle
from setting_funcs.HDFS_CONF import  hdfs_list, connect
from pyspark.sql import Row
from collections import OrderedDict
from subprocess import Popen, PIPE

schema = StructType([
    StructField("processID", StringType()),
    StructField("processCreate", TimestampType()),
    StructField("processStatuses", ArrayType(
        StructType([
            StructField("id", StringType()),
            StructField("processState", LongType()),
            StructField("stateDate", TimestampType())
        ])
    ))
])

def dataFrameTransform(df):
    df = df.withColumn('DATE_VALUE', df.processCreate)
    df = df.withColumn('DATE_VALUE', df.DATE_VALUE.cast(DateType()))
    df = df.withColumn('GM_SYSTEM_CODE', lit("CMD"))
    df = df.withColumn('DATE_CHANGE', lit(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    df = df.withColumn('DATE_CHANGE', df.DATE_CHANGE.cast(TimestampType()))

    df = df.withColumnRenamed('id', 'ID')
    df = df.withColumnRenamed('processState', 'PROCESS_STATE')
    df = df.withColumnRenamed('stateDate', 'STATE_DATE')
    df = df.withColumnRenamed('processID', 'PROCESS_ID')
    df = df.drop('processCreate')

    return df

def oracleWriter(df, SID, table_name):

    dfToOracle(df, SID, table_name, sq)
    df.unpersist()

def check_actual_files(sq, files_names):
    check_list = []

    for item in files_names:
        item_id = str(item).split("_", 1)[0]
        item_timestamp = int(item.split("_", 1)[1])
        item_timestamp = datetime.fromtimestamp(item_timestamp / 1e3)
        check_list.append([item, item_id, item_timestamp])

    df = sq.createDataFrame(check_list, ['file_name', 'id', 'change_date'])
    df.createOrReplaceTempView('l')

    l = sq.sql(
        "select file_name, id, change_date, row_number() over(partition by id order by change_date desc) as rn from l where 1=1")
    l = l.filter(l.rn == 1)

    files_names = [row.file_name for row in l.collect()]
    l.unpersist()

    return files_names

def loader(df):
    df_load = dataFrameTransform(df)
    #df_load = df_load.filter(df_load["DATE_VALUE"] == lit("2022-08-17"))

    oracleWriter(df_load, 'EDW', 'RISKDM.CMD_CCE_PROCESS_STATUSES_FL_STAGE')
    df_load.unpersist()

if __name__ == '__main__':

    sq = connect()

    date = str(datetime.now() - timedelta(days=1))
    path = "/nifi/raw/kafka/camunda/commodity-credit-events/" + date[0:4] + "/" + date[5:7] + "/" + date[8:10] + "/"


    files_names = hdfs_list(sq, path)
    files_names = check_actual_files(sq, files_names)
    files_names = [path + s for s in files_names]

    df = sq.read.json(files_names, schema)
    flat_list = []
    for xs in df.collect():
        for x in xs.processStatuses:
            temp = x.asDict()
            temp["processID"] = xs.processID
            temp["processCreate"] = xs.processCreate
            d = Row(**temp)
            flat_list.append(d)
    df = sq.createDataFrame(flat_list)
    loader(df)
