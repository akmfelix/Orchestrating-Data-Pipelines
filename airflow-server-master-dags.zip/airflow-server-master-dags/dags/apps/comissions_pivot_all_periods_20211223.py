#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
# import numpy as np
import cx_Oracle
import sqlalchemy
from sqlalchemy import create_engine
# библиотека для отчистки print() в юпитер ноутбуке. Просто визуал
# import datetime
# from math import sqrt
# from numpy.random import seed
# from scipy.stats import sem
# from scipy.stats import t
# import json

pd.options.display.float_format = '{:.2f}'.format
pd.set_option('display.max_columns', None)
pd.set_option('display.expand_frame_repr', False)
# pd.set_option('max_colwidth', -1)
import datetime
from datetime import date

# In[2]:


# блок инициализации
periods_start_date = datetime.datetime.now().date()
ok_min_date_in_table = datetime.datetime(2021, 1, 12).date()
period_step = 30

loop_date_start = periods_start_date
loop_date_end = loop_date_start - datetime.timedelta(period_step)
counter = 1
db_table_name = 'COMISSIONS_PIVOT_ALL_PERIODS'


# In[3]:


# блок с функциями
def date_for_select_from_datetime(datetime_date, separator='-'):
    '''
    преобразует datetime формат в строку для запросов в SQL
    '''
    str_for_return = '\''
    if datetime_date.day >= 10:
        str_for_return += str(datetime_date.day)
    else:
        str_for_return += '0' + str(datetime_date.day)
    if datetime_date.month >= 10:
        str_for_return += separator + str(datetime_date.month)
    else:
        str_for_return += separator + '0' + str(datetime_date.month)
    str_for_return += separator + str(datetime_date.year) + '\''
    return str_for_return


# In[6]:


# pass_json = '/app/airflow_local/apps/LP2.json'
# with open(pass_json, "r") as fp:
#     lp = json.loads(fp.read())

lp = {
	"DSSB_SE": {
        "SERVICE_NAME": "DSSB",
        "LOGIN": "DSSB_SE",
        "PASS": "Kcell2006!aa",
        "HOST": "172.27.62.13",
        "PORT": 1521
    }
}


def connect_db(lp):
    '''connection to  DB (sandbox)'''
    dsn_tns = cx_Oracle.makedsn(host=lp['HOST'], port=lp['PORT'], service_name=lp['SERVICE_NAME'])
    connection = cx_Oracle.connect(user=lp['LOGIN'], password=lp['PASS'], dsn=dsn_tns)
    return connection


# In[7]:


### 2. For DSSB_APP user:

host_DSSB_APP = lp['DSSB_SE']['HOST']
port_DSSB_APP = lp['DSSB_SE']['PORT']
sid_DSSB_APP = lp['DSSB_SE']['SERVICE_NAME']
user_DSSB_APP = lp['DSSB_SE']['LOGIN']
password_DSSB_APP = lp['DSSB_SE']['PASS']
sid_DSSB_APP = cx_Oracle.makedsn(host_DSSB_APP, port_DSSB_APP, sid=sid_DSSB_APP)
cstr_DSSB_APP = 'oracle://{user}:{password}@{sid}'.format(
    user=user_DSSB_APP,
    password=password_DSSB_APP,
    sid=sid_DSSB_APP
)

engine_DSSB_APP = create_engine(
    cstr_DSSB_APP,
    convert_unicode=False,
    pool_recycle=10,
    pool_size=50,
    echo=False)

db_conn_DSSB_APP = cx_Oracle.connect(user=user_DSSB_APP, password=password_DSSB_APP,
                                     dsn=sid_DSSB_APP)
cursor_DSSB_APP = db_conn_DSSB_APP.cursor()

# In[8]:


final_table = pd.read_sql('select P_SID from  dssb_app.ecg_epg_split', db_conn_DSSB_APP)

# In[10]:


while loop_date_end >= ok_min_date_in_table:
    date_start_for_sql = date_for_select_from_datetime(loop_date_start)
    date_end_for_sql = date_for_select_from_datetime(loop_date_end)

    # пример того, как может выглядеть запрос
    sql_text = f'''
    select p_sid,
       sum(amount) as kd_sum
    from dssb_de.agg_all_commissions a
    where act_date between TO_DATE({date_end_for_sql}, 'DD-MM-YYYY') AND TO_DATE({date_start_for_sql}, 'DD-MM-YYYY')
    and ccode in (120,121,122,131) --карточные
    group by p_sid
    '''
    #     print(sql_text)

    CR_table = pd.read_sql(sql_text, db_conn_DSSB_APP)  # тут твой запрос
    col_name = 'PERIOD_' + str(counter)
    CR_table.columns = ['P_SID', col_name]  # тут переименовать колонку с ком доходами в col_name
    final_table = final_table.merge(CR_table, on='P_SID', how='left').fillna(0)

    counter += 1
    loop_date_start = loop_date_end - datetime.timedelta(1)
    loop_date_end = loop_date_start - datetime.timedelta(period_step)

# In[11]:


final_table.head()

# In[12]:


final_table['P_SID'] = final_table['P_SID'].astype('int')

# In[13]:


final_table.head()

# In[14]:


date.today()

# In[15]:


final_table['SNAPSHOT_DATE'] = date.today()

# In[16]:


final_table.head()

# In[19]:


final_table = final_table[
    ['P_SID', 'PERIOD_1', 'PERIOD_2', 'PERIOD_3', 'PERIOD_4', 'PERIOD_5', 'PERIOD_6', 'PERIOD_7', 'PERIOD_8', 'SNAPSHOT_DATE']]

# In[20]:


final_table.head()

# In[21]:


# Удаляем таблицу
query_drop = f'''
                DROP TABLE {db_table_name} '''

cursor_DSSB_APP.execute(query_drop)
db_conn_DSSB_APP.commit()

# In[23]:


# Создаемм таблицу
query_create = f'''
CREATE TABLE {db_table_name}
   (   P_SID INTEGER, 
       PERIOD_1 INTEGER, 
       PERIOD_2 INTEGER, 
       PERIOD_3 INTEGER, 
       PERIOD_4 INTEGER, 
       PERIOD_5 INTEGER, 
       PERIOD_6 INTEGER, 
       PERIOD_7 INTEGER, 
       PERIOD_8 INTEGER,
       SNAPSHOT_DATE DATE
   ) 
  TABLESPACE "DSSB_NEW" '''

cursor_DSSB_APP.execute(query_create)
db_conn_DSSB_APP.commit()

# In[25]:


final_table.to_sql(name=db_table_name.upper(), con=engine_DSSB_APP, if_exists='append'
                   , index=False,
                   chunksize=1000, dtype={'P_SID': sqlalchemy.types.Numeric,
                                          'PERIOD_1': sqlalchemy.types.Numeric,
                                          'PERIOD_2': sqlalchemy.types.Numeric,
                                          'PERIOD_3': sqlalchemy.types.Numeric,
                                          'PERIOD_4': sqlalchemy.types.Numeric,
                                          'PERIOD_5': sqlalchemy.types.Numeric,
                                          'PERIOD_6': sqlalchemy.types.Numeric,
                                          'PERIOD_7': sqlalchemy.types.Numeric,
                                          'PERIOD_8': sqlalchemy.types.Numeric,
                                          'SNAPSHOT_DATE': sqlalchemy.types.Date
                                          })
