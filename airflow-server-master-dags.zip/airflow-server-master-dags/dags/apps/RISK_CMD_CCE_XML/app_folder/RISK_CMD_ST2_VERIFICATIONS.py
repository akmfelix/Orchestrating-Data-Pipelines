from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType, DateType, TimestampType
from pyspark.sql import Row
from collections import OrderedDict
from subprocess import Popen, PIPE
from pyspark.sql.functions import regexp_replace, lit, to_date
import time
from datetime import datetime, timedelta

schema_xml = StructType([
    StructField("dmRequestXML", StringType(), True)
])


def connect():
    # Read

    conf = SparkConf().setAppName("RISK_CMD_ST2_TABLES").set("spark.hadoop.yarn.timeline-service.enabled", "false") \
        .set("spark.driver.extraClassPath", "ojdbc8-21.1.0.0.jar")
    # sc = SparkContext.getOrCreate(conf=conf)
    sc = SparkContext(conf=conf)
    # log4j = sc._jvm.org.apache.log4j
    # log4j.LogManager.getRootLogger().setLevel(log4j.Level.INFO)
    sq = SQLContext(sc)

    return sq


def readTable(files_names):
    df_hdfs = sq.read.json(files_names, schema_xml)
    return df_hdfs


def run(files_names):
    df = readTable(files_names)
    xml_list = [row.dmRequestXML for row in df.collect()]

    l_temp_verifications = parse(sq, log, xml_list, 'Verifications')
    l_temp_verification_fields = parse(sq, log, xml_list, 'Verification_Fields')
    l_temp_verification_answers = parse(sq, log, xml_list, 'Verification_Answers')

    return l_temp_verifications, l_temp_verification_fields, l_temp_verification_answers


def check_etl_date():
    url = "jdbc:oracle:thin:@172.28.74.10:1521/EDW"
    driver = "oracle.jdbc.driver.OracleDriver"
    user = "EDW_ETL_CDO"
    password = getPass(sq, 'EDW', user)

    sql = "(" \
          "SELECT MIN(OPER_DATE) as OPER_DATE FROM RISKDM.AIRFLOW_ETL_DATA WHERE STATUS = 'WAITING' AND DAG_NAME = 'EDW_CMD_RISKDM'" \
          ") t"

    # Getting start date
    df_date = sq.read.format("jdbc").option("url", url) \
        .option("driver", driver) \
        .option("user", user).option("password", password).load(
        dbtable=sql
    )
    date = df_date.collect()
    date = str(date[0][0])

    return date


def oracleWriter(df, schema, SID, table_name, flag=0):
    df = sq.createDataFrame(df, schema)
    df = dataFrameTransformDDS(df)
    df = dfAdditionalTransform(df, table_name, flag)
    date = check_etl_date()
    df = df.filter((df.date_value) == lit(date[0:4] + "-" + date[5:7] + "-" + date[8:10]))

    # Write to Oracle
    log.WARN('DF saving to Oracle started')
    dfToOracle(df, SID, table_name, log, sq)
    df.unpersist()
    log.WARN('DF successfully saved to Oracle')


if __name__ == '__main__':

    # Creating Application
    sq = connect()

    import Schemas.shemaStructs as sch

    from Logging.Logger import Logger
    from Writers.functions import *

    log = Logger('WARN')

    path = "/edi_raw/risk/forload/camunda/commodity-credit-events/"

    files_names = hdfs_list(sq, path)[2]
    files_names = [path + s for s in files_names]

    l_final_verifications, l_final_verification_fields, l_final_verification_answers = [], [], []

    chunked_list = []
    for i in range(0, len(files_names), 5):
        chunked_list.append(files_names[i:i + 5])

    for chunk in chunked_list:
        l_temp_verifications, l_temp_verification_fields, l_temp_verification_answers = run(chunk)

        l_final_verifications = l_final_verifications + l_temp_verifications

        l_final_verification_fields = l_final_verification_fields + l_temp_verification_fields

        l_final_verification_answers = l_final_verification_answers + l_temp_verification_answers

        log.WARN('Final verifications: ' + str(len(l_final_verifications)))
        log.WARN('Final verification fields: ' + str(len(l_final_verification_fields)))
        log.WARN('Final verification answers: ' + str(len(l_final_verification_answers)))

    try:
        oracleWriter(l_final_verifications, sch.schema_verifications, 'EDW', 'DDS.CMD_CCE_VERIFICATIONS_FL')
    except:
        log.WARN('DDS.CMD_CCE_VERIFICATIONS_FL Writer failed')

    try:
        oracleWriter(l_final_verification_fields, sch.schema_verification_fields, 'EDW', 'DDS.CMD_CCE_VERIFICATION_FIELDS_FL')
    except:
        log.WARN('DDS.CMD_CCE_VERIFICATION_FIELDS_FL Writer failed')

    try:
        oracleWriter(l_final_verification_answers, sch.schema_verification_answers, 'EDW', 'DDS.CMD_CCE_VERIFICATION_ANSWERS_FL')
    except:
        log.WARN('DDS.CMD_CCE_VERIFICATION_ANSWERS_FL Writer failed')

    log.INFO('Program finished')
