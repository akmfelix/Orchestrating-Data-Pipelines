from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType, DateType, TimestampType
from pyspark.sql import Row
from collections import OrderedDict
from subprocess import Popen, PIPE
from pyspark.sql.functions import regexp_replace, lit, to_date
import time
from datetime import datetime, timedelta

schema_xml = StructType([
    StructField("processID", StringType(), True),
    StructField("processCreate", TimestampType(), True),
    StructField("clientID", StringType(), True),
    StructField("processReference", StringType(), True),
    StructField("dmRequestXML", StringType(), True)
])

schema_json = StructType([
    StructField("processID", StringType(), True),
    StructField("processCreate", TimestampType(), True),
    StructField("clientID", StringType(), True),
    StructField("processReference", StringType(), True)
])

def connect():
    # Read

    conf = SparkConf().setAppName("RISK_CMD_ST2_TABLES").set("spark.hadoop.yarn.timeline-service.enabled", "false") \
        .set("spark.driver.extraClassPath", "ojdbc8-21.1.0.0.jar")
    # sc = SparkContext.getOrCreate(conf=conf)
    sc = SparkContext(conf=conf)
    # log4j = sc._jvm.org.apache.log4j
    # log4j.LogManager.getRootLogger().setLevel(log4j.Level.INFO)
    sq = SQLContext(sc)

    return sq


def readTable(files_names):
    df_hdfs = sq.read.json(files_names, schema_xml)
    return df_hdfs


def run(files_names):
    df = readTable(files_names)
    xml_list = [row.dmRequestXML for row in df.collect()]
    l_temp_app_link = parse(sq, log, xml_list, 'Application_link')
    df = df.drop("dmRequestXML")

    return l_temp_app_link, df


def check_etl_date():
    url = "jdbc:oracle:thin:@172.28.74.10:1521/EDW"
    driver = "oracle.jdbc.driver.OracleDriver"
    user = "EDW_ETL_CDO"
    password = getPass(sq, 'EDW', user)

    sql = "(" \
          "SELECT MIN(OPER_DATE) as OPER_DATE FROM RISKDM.AIRFLOW_ETL_DATA WHERE STATUS = 'WAITING' AND DAG_NAME = 'EDW_CMD_RISKDM'" \
          ") t"

    # Getting start date
    df_date = sq.read.format("jdbc").option("url", url) \
        .option("driver", driver) \
        .option("user", user).option("password", password).load(
        dbtable=sql
    )
    date = df_date.collect()
    date = str(date[0][0])

    return date


def oracleWriter(df, df_json, schema, SID, table_name, flag=0):
    df = sq.createDataFrame(df, schema)
    df = df_json.join(df, df_json.processID == df.ProcessID_XML, "left")
    df = dfAdditionalTransform(df, table_name, flag)
    date = check_etl_date()
    df = df.filter(df.date_value == lit(date[0:4] + "-" + date[5:7] + "-" + date[8:10]))
    # Write to Oracle
    log.WARN('DF saving to Oracle started')
    dfToOracle(df, SID, table_name, log, sq)
    df.unpersist()
    log.WARN('DF successfully saved to Oracle')


if __name__ == '__main__':

    # Creating Application
    sq = connect()

    import Schemas.shemaStructs as sch

    from Logging.Logger import Logger
    from Writers.functions import *

    log = Logger('WARN')

    path = "/edi_raw/risk/forload/camunda/commodity-credit-events/"

    files_names = hdfs_list(sq, path)[2]
    files_names = [path + s for s in files_names]

    l_final_app_link = []
    df_json = sq.createDataFrame([], schema_json)

    for chunk in files_names:
        l_temp_app_link, df = run(chunk)
        l_final_app_link = l_final_app_link + l_temp_app_link
        df_json = df_json.union(df)
        log.WARN('Final App Link: ' + str(len(l_final_app_link)))

    try:
        oracleWriter(l_final_app_link, df_json, sch.schema_app_link, 'EDW', 'DDS.CMD_CCE_APPLICATION_PKB_L')
    except:
        log.WARN('DDS.CMD_CCE_APPLICATION_PKB_L Writer failed')

    log.INFO('Program finished')
