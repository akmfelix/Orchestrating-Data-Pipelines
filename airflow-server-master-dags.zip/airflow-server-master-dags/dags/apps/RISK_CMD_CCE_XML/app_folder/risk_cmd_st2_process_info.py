from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.types import StructField, StructType, StringType, DateType, TimestampType
from pyspark.sql import Row
from collections import OrderedDict
from subprocess import Popen, PIPE
from datetime import datetime, timedelta
import time
from pyspark.sql.functions import regexp_replace, lit, to_date

schema_xml = StructType([
    StructField("dmRequestXML", StringType(), True)
])

def connect():
    # Read
    conf = SparkConf().setAppName("RISK_CMD_ST2_PROCESS_INFO").set("spark.hadoop.yarn.timeline-service.enabled", "false")\
        .set("spark.driver.extraClassPath","ojdbc8-21.1.0.0.jar")
    sc = SparkContext(conf=conf)
    sq = SQLContext(sc)
    return sq

def check_etl_date():
    url = "jdbc:oracle:thin:@172.28.74.10:1521/EDW"
    driver = "oracle.jdbc.driver.OracleDriver"
    user = "EDW_ETL_CDO"
    password = getPass(sq, 'EDW', user)

    sql = "(" \
          "SELECT MIN(OPER_DATE) as OPER_DATE FROM RISKDM.AIRFLOW_ETL_DATA WHERE STATUS = 'WAITING' AND DAG_NAME = 'EDW_CMD_RISKDM'" \
          ") t"

    # Getting start date
    df_date = sq.read.format("jdbc").option("url", url) \
        .option("driver", driver) \
        .option("user", user).option("password", password).load(
        dbtable=sql
    )
    date = df_date.collect()
    date = str(date[0][0])

    return date

def readTable(files_names):
    df_hdfs = sq.read.json(files_names, schema_xml)
    return df_hdfs

def run(files_names):

    df = readTable(files_names)
    xml_list = [row.dmRequestXML for row in df.collect()]

    l_temp_ProcessInfo = parse(sq, log, xml_list, 'ProcessInfo')
    l_temp_ProcessAggregates = parse(sq, log, xml_list, 'ProcessAggregates')

    return l_temp_ProcessInfo, l_temp_ProcessAggregates


def oracleWriter(df, schema, SID, table_name, flag=0):

    df = sq.createDataFrame(df, schema)
    df = dataFrameTransformDDS(df)
    df = dfAdditionalTransform(df, table_name, flag)
    date = check_etl_date()

    df = df.filter((df.date_value) == lit(date[0:4] + "-" + date[5:7] + "-" + date[8:10]))

    # dfCheck(df)
    # Write to Oracle
    log.WARN('DF saving to Oracle started')
    dfToOracle(df, SID, table_name, log, sq)
    df.unpersist()
    log.WARN('DF successfully saved to Oracle')


if __name__ == '__main__':

    # Creating Application
    sq = connect()

    import Schemas.shemaStructs as sch
    from Parsers import p_ItemsParser as it
    from Mappers import m_ProcessAggregates, m_priority_1, m_ProcessInfo, m_verificationSet

    from Logging.Logger import Logger
    from Writers.functions import *

    log = Logger('WARN')

    path = "/edi_raw/risk/forload/camunda/commodity-credit-events/"

    totol_size_in_MB, total_num_files, files_names = hdfs_list(sq, path)
    files_names = [path + s for s in files_names]

    l_final_ProcessInfo, l_final_ProcessAggregates = [], []

    chunked_list = []

    for i in range(0, len(files_names), 5):
        chunked_list.append(files_names[i:i + 5])

    for chunk in chunked_list:
        l_temp_ProcessInfo, l_temp_ProcessAggregates = run(chunk)
        l_final_ProcessInfo = l_final_ProcessInfo + l_temp_ProcessInfo
        l_final_ProcessAggregates = l_final_ProcessAggregates + l_temp_ProcessAggregates

        log.WARN('Final ProcessInfo: ' + str(len(l_final_ProcessInfo)))
        log.WARN('Final ProcessAggregates: ' + str(len(l_final_ProcessAggregates)))


    try:
        oracleWriter(l_final_ProcessInfo, sch.schema_ProcessInfo,  'EDW', 'DDS.CMD_CCE_PROCESS_INFO_FL')
    except:
        log.WARN('Writer failed')

    try:
        oracleWriter(l_final_ProcessAggregates, sch.schema_ProcessAggregates, 'EDW', 'DDS.CMD_CCE_POV_CLIENT_FL')
    except:
        log.WARN('Writer failed')


    log.INFO('Program finished')
