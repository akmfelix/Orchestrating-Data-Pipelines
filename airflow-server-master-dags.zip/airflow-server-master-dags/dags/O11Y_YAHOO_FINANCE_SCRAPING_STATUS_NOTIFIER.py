import textwrap
import typing

import pendulum
from airflow.decorators import dag, task
from airflow.providers.postgres.hooks.postgres import PostgresHook

from source.telegram_notifications import TelegramErrorNotification
from source.telegram_notifier import TelegramNotifier


@dag(
    default_args={
        "owner": "TleuserIz",
        "on_failure_callback": [TelegramErrorNotification()],
    },
    dag_id="O11Y_YAHOO_FINANCE_SCRAPING_STATUS_NOTIFIER",
    schedule="35 9 * * *",
    start_date=pendulum.datetime(2024, 10, 31, tz="Asia/Oral"),
    catchup=False,
    tags=["o11y"],
)
def taskflow():
    @task(
        task_id="check_and_alert",
    )
    def check_and_alert(postgres_hook: PostgresHook, **context) -> typing.Tuple[str, str]:
        bot_token = context["var"]["value"].get("telegram_bot_token")
        chat_id = context["var"]["value"].get("telegram_notifications_chat_id")
        proxies = {
            "http": context["var"]["value"].get("http_proxy"),
            "https": context["var"]["value"].get("https_proxy"),
        }
        notifier = TelegramNotifier(bot_token, chat_id)

        sql_statement = "select status, traceback from public.etl_jobs_statuses where oper_date = current_date"
        with postgres_hook.get_conn() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql_statement)
                result_set: typing.Tuple[str, str] = cursor.fetchone()
                status, traceback = result_set
                if status == "finished":
                    cursor.execute("select count(*) from public.issuer_detail where scraping_date = current_date")
                    result_set: typing.Tuple[int] = cursor.fetchone()
                    message = f"✅ <b>Yahoo Finance Scraper</b> fetched <u>{result_set[0]}</u> records on <i>{pendulum.now('Asia/Oral').to_datetime_string()}</i>"
                else:
                    traceback = textwrap.fill(
                        textwrap.dedent(traceback),
                        width=24,
                        initial_indent="> ",
                        subsequent_indent="> ",
                        max_lines=6,
                        replace_whitespace=True,
                    )
                    message = (
                        f"❌ <b>Yahoo Finance Scraper</b> failed with the following error:\n<code>{traceback}</code>"
                    )

        notifier.send_message(message, proxies)
        return status, traceback

    check_and_alert(PostgresHook(postgres_conn_id="db_postgress_guaranteedb__guaranteedb_uid_user"))


taskflow()
