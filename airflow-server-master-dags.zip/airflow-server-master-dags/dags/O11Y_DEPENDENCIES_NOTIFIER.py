import json
from typing import List

import pandas as pd
import pendulum
import requests
from airflow.decorators import dag, task
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.vertica.hooks.vertica import VerticaHook

from source.telegram_notifications import (
    TelegramErrorNotification,
)
from source.telegram_notifier import TelegramNotifier


@dag(
    default_args={
        "owner": "TleuserIz",
    },
    dag_id="O11Y_DEPENDENCIES_READINESS_NOTIFIER",
    schedule="0 7,12,15 * * *",
    start_date=pendulum.datetime(2024, 9, 2, tz="Asia/Oral"),
    catchup=False,
    tags=["o11y"],
)
def taskflow():
    vertica_hook = VerticaHook("Vertica_Prod")
    oracle_hook = OracleHook(oracle_conn_id="EDW_ETL_CDO", thick_mode=True)

    requirements: str = """
    plottable
    matplotlib
    pandas
    """
    # directory = Variable.get("root_dir")
    directory = "/opt/airflow/temp/"

    @task(
        task_id="read_profile_readiness_vertica_table_to_dataframe",
        on_failure_callback=[TelegramErrorNotification()],
    )
    def fetch_mdm_profile_dependencies_df(vertica_hook: VerticaHook) -> pd.DataFrame:
        vertica_conn = vertica_hook.get_conn()
        statement = """
        SELECT to_char(OPER_DATE), PRIORITY, DEPEND_READY, PROC_RUNNING, PROC_ERROR, PROC_READY, TOTAL
from (

       SELECT pl.*
                    , p.PRIORITY
                    , sum(case when pl.DEPEND_READY_FL = 1 then 1 else 0 end) over(partition by p.PRIORITY) as DEPEND_READY
                    , sum(case when pl.PROC_READY_FL = 1 then 1 else 0 end) over(partition by p.PRIORITY) as PROC_READY
                    , sum(case when pl.PROC_READY_FL = 2 then 1 else 0 end) over(partition by p.PRIORITY) as PROC_RUNNING
                    , sum(case when pl.PROC_READY_FL = 3 then 1 else 0 end) over(partition by p.PRIORITY) as PROC_ERROR
                    , count(p.PRIORITY) over(partition by p.PRIORITY) as TOTAL
             from mdm_tech.profile_log pl
             left join (
                    SELECT DISTINCT VRT_TABLE_NAME, PRIORITY
                    from mdm_tech.profile_relation
             ) p on lower(p.VRT_TABLE_NAME) = lower(pl.VRT_TABLE_NAME)
             where OPER_DATE = (SELECT max(OPER_DATE) from mdm_tech.profile_log) - 0 --date '2024-03-24'
             order by OPER_DATE, PRIORITY, VRT_TABLE_NAME

       ) t
group by OPER_DATE, PRIORITY, DEPEND_READY, PROC_READY, PROC_RUNNING, PROC_ERROR, TOTAL
order by PRIORITY;
        """
        with vertica_conn.cursor("dict") as cursor:
            result_set = cursor.execute(statement).fetchall()
            df = pd.read_json(json.dumps(result_set), orient="records")

        vertica_conn.close()
        return df

    @task(
        task_id="read_dm_readiness_oracle_table_to_dataframe",
        on_failure_callback=[TelegramErrorNotification()],
    )
    def fetch_dm_readiness_df(oracle_hook: OracleHook) -> pd.DataFrame:
        oracle_conn = oracle_hook.get_conn()
        statement = """
        SELECT table_name,
       '-' || delay_days                                 AS delay_days,
       to_char(trunc(sysdate) - delay_days, 'YYYY-MM-DD') AS last_actual_date
FROM (SELECT SUBSTR(dst.WF_NAME, 4, 200) AS table_name
           , trunc(sysdate) - DATE_VALUE AS delay_days
           , ROW_NUMBER()                   OVER(PARTITION BY wf_name ORDER BY DATE_VALUE DESC) rn
      FROM PREDDS.DM_SHED_TABLE dst) f
WHERE rn = 1
  AND delay_days != 1
order by table_name, delay_days
        """
        with oracle_conn.cursor() as cursor:
            cursor = cursor.execute(statement)
            columns = [col[0] for col in cursor.description]
            cursor.rowfactory = lambda *args: dict(zip(columns, args))
            result_set = cursor.fetchall()
            df = pd.read_json(json.dumps(result_set))
        oracle_conn.close()
        return df

    @task.virtualenv(
        task_id="run_script_in_env",
        requirements=requirements,
        python_version=None,
        # serializer=None,
        system_site_packages=False,
        pip_install_options=[
            "--no-cache-dir",
            # "-vvv",
            "--index-url",
            "https://nexus.halykbank.nb/repository/di-group-pypi/simple",
            "--trusted-host",
            "nexus.halykbank.nb",
        ],
        # op_args=None,
        # op_kwargs=None,
        # string_args=None,
        expect_airflow=False,
        # venv_cache_path="/opt/airflow/venv_cache/",
        on_failure_callback=[TelegramErrorNotification()],
    )
    def render_images(dfs, directory: str):  # Add a typing hint after bumping Airflow version
        import datetime as dt
        import typing
        from pathlib import Path

        import matplotlib.pyplot as plt
        import pandas as pd
        from plottable import ColumnDefinition, Table

        mdm_profile_dependencies_readiness_df, dm_readiness_df = dfs[0], dfs[1]
        # dm_readiness_df may contain zero rows — when all tables are ready; usually, in the beginning of a month

        def appropriate_fig_size(n_records: int) -> typing.Tuple[int, int]:
            if n_records <= 2:
                return 16, 8
            elif 2 < n_records <= 10:
                return 17, 10
            else:
                return 17, 17

        def render_mdm_profile_dependencies_readiness_table(df, directory):
            colnames = [
                "Опер. День",
                "Приоритет",
                "Готовые Зависимости",
                "В Процессе",
                "С Ошибкой",
                "Завершённые",
                "Всего",
            ]
            columns = df.columns.tolist()
            col_to_name = dict(zip(columns, colnames))
            df = df.rename(col_to_name, axis=1)
            col_defs = [
                ColumnDefinition(
                    name="Опер. День",
                    textprops={"ha": "center", "weight": "heavy"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="Приоритет",
                    textprops={"ha": "center"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="Готовые Зависимости",
                    textprops={"ha": "center"},
                    width=2.3,
                ),
                ColumnDefinition(
                    name="В Процессе",
                    textprops={"ha": "center"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="С Ошибкой",
                    textprops={"ha": "center"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="Завершённые",
                    textprops={"ha": "center"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="Всего",
                    textprops={"ha": "center", "fontstyle": "italic"},
                    width=1.5,
                ),
            ]

            plt.rcParams["font.family"] = ["DejaVu Sans"]
            plt.rcParams["savefig.bbox"] = "tight"
            fig, ax = plt.subplots(figsize=(17, 10))
            tab = Table(
                df,
                column_definitions=col_defs,
                index_col="Опер. День",
                row_dividers=True,
                footer_divider=True,
                ax=ax,
                textprops={"fontsize": 16},
                row_divider_kw={"linewidth": 1, "linestyle": (0, (1, 5))},
                # col_label_divider_kw={"linewidth": 1, "linestyle": "-"},
                # col_label_divider=True,
                # column_border_kw={"linewidth": 1, "linestyle": (0, (1, 5))},
            )
            path = Path(directory)
            filepath = path / f"{dt.datetime.now().strftime('%F_%H-%M-%S')}_mdm_profile_dependencies.png"  # In utc
            plt.savefig(filepath)
            return filepath.as_posix()

        def render_dm_readiness_table(df, directory):
            if df.empty:
                cols = ("TABLE_NAME", "DELAY_DAYS", "LAST_ACTUAL_DATE")
                df = pd.concat([df, pd.DataFrame(data=[["-", "-", "-"]], columns=cols)], ignore_index=True)
            colnames = [
                "Название Таблицы",
                "Задержка (в днях)",
                "Последняя Актуальная Дата",
            ]
            columns = df.columns.tolist()
            col_to_name = dict(zip(columns, colnames))
            df = df.rename(col_to_name, axis=1)
            col_defs = [
                ColumnDefinition(
                    name="Название Таблицы",
                    textprops={"ha": "left", "weight": "heavy"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="Задержка (в днях)",
                    textprops={"ha": "center", "fontstyle": "italic"},
                    width=1.5,
                ),
                ColumnDefinition(
                    name="Последняя Актуальная Дата",
                    textprops={"ha": "center"},
                    width=2.3,
                ),
            ]

            plt.rcParams["font.family"] = ["DejaVu Sans"]
            plt.rcParams["savefig.bbox"] = "tight"
            fig, ax = plt.subplots(figsize=appropriate_fig_size(len(df)))
            tab = Table(
                df,
                column_definitions=col_defs,
                index_col="Название Таблицы",
                row_dividers=True,
                footer_divider=True,
                ax=ax,
                textprops={"fontsize": 14},
                row_divider_kw={"linewidth": 1, "linestyle": (0, (1, 5))},
                # col_label_divider_kw={"linewidth": 1, "linestyle": "-"},
                # col_label_divider=True,
                # column_border_kw={"linewidth": 1, "linestyle": (0, (1, 5))},
            )
            path = Path(directory)
            filepath = path / f"{dt.datetime.now().strftime('%F_%H-%M-%S')}_dm_readiness.png"  # In utc
            plt.savefig(filepath)
            return filepath.as_posix()

        # if not mdm_profile_dependencies_readiness_df.empty:
        file_paths = [
            render_mdm_profile_dependencies_readiness_table(mdm_profile_dependencies_readiness_df, directory),
            render_dm_readiness_table(dm_readiness_df, directory),
        ]
        return file_paths

    @task(
        task_id="send_images_to_telegram",
        on_failure_callback=[TelegramErrorNotification()],
    )
    def send_images(file_paths: List[str], **context) -> None:
        bot_token = context["var"]["value"].get("telegram_bot_token")
        chat_id = context["var"]["value"].get("telegram_notifications_chat_id")
        proxies = {
            "http": context["var"]["value"].get("http_proxy"),
            "https": context["var"]["value"].get("https_proxy"),
        }
        # notifier = TelegramNotifier(bot_token=bot_token, chat_id=chat_id)
        for file_path in file_paths:
            if file_path:
                response = requests.post(
                    f"https://api.telegram.org/bot{bot_token}/sendPhoto",
                    data={"chat_id": chat_id},
                    files={"photo": open(file_path, "rb")},
                    verify=False,
                    proxies=proxies,
                )
                print(response.text)
            # notifier.send_image(file_path, proxies=proxies)
        return None

    send_images(
        file_paths=render_images(
            dfs=[
                fetch_mdm_profile_dependencies_df(vertica_hook),
                fetch_dm_readiness_df(oracle_hook),
            ],
            directory=directory,
        )
    )


taskflow()
