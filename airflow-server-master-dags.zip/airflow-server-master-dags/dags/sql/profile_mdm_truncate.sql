SELECT drop_partitions('mdm.document_masters', 1, {{ load_id }});
SELECT drop_partitions('mdm.party_instance', 1, {{ load_id }});
SELECT drop_partitions('mdm.contact_masters', 1, {{ load_id }});
SELECT drop_partitions('mdm.party_masters', 1, {{ load_id }});