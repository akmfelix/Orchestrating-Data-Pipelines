SELECT 
       f.TABLE_NAME, TO_CHAR(f.DATE_VALUE, 'YYYY-MM-DD') AS DATE_VALUE, "DELAY DAYS (T-N)", f.READY_FLAG
from(
       SELECT SUBSTR(dst.WF_NAME, 4, 40) AS table_name
       , DATE_VALUE
       , 't'  || to_char(-1*(trunc(SYSDATE) - DATE_VALUE)) AS "DELAY DAYS (T-N)"
       , CASE WHEN DM_READY_FL = 0 THEN 'In progress' ELSE 'Success' END AS ready_flag
       , ROW_NUMBER() OVER(PARTITION BY wf_name ORDER BY DATE_VALUE DESC) rn
       FROM PREDDS.DM_SHED_TABLE dst
) f
WHERE rn = 1