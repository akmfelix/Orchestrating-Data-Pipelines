SELECT 							
	 f.TABLE_NAME
	,f.DATE_VALUE
	,f."delay days (t-n)"
	,f.READY_FLAG
	,f.SCH_FLAG
	,f.DATE_START
	,f.DATE_END						
from(							
	SELECT SUBSTR(dst.WF_NAME, 4, 1000) AS table_name						
	, DATE_VALUE						
	, 't'  || to_char(-1*(trunc(SYSDATE) - DATE_VALUE)) AS "delay days (t-n)"						
	, CASE WHEN DM_READY_FL = 0 THEN 'In progress' ELSE 'Success' END AS ready_flag						
	, CASE WHEN DM_READY_FL = 1 AND DATE_VALUE - trunc(SYSDATE - 1) = 0 THEN 'On schedule' ELSE 'Delayed' END AS SCH_FLAG						
	, DATE_START						
	, DATE_END 						
	, ROW_NUMBER() OVER(PARTITION BY wf_name ORDER BY DATE_VALUE DESC) rn						
	FROM PREDDS.DM_SHED_TABLE dst						
) f							
WHERE rn = 1							
