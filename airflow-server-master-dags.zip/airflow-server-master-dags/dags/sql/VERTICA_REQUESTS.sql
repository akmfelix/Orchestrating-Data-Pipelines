select DISTINCT user_name, 
	   COUNT(*) AS request_count,
	   AVG(request_duration_ms)/1000 AS avg_execution_time_sec,
	   MIN(request_duration_ms)/1000 AS min_execution_time_sec,
	   MAX(request_duration_ms)/1000 AS max_execution_time_sec,
	   SYSDATE AS oper_date
from query_requests 
where TO_CHAR(start_timestamp, 'YYYY-MM-DD') = TO_CHAR(SYSDATE, 'YYYY-MM-DD')
      --AND user_name not in ('vertica_dbadmin', 'vrtc_internal')
      AND request_type = 'QUERY'
	  and request ilike '%profile_dm%'
GROUP BY user_name
ORDER BY COUNT(*) DESC
