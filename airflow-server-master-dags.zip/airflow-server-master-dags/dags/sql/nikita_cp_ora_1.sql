DELETE
FROM DDS.CMD_CCE_PROCESSES_PARCED_FL
WHERE DATE_VALUE = to_date(CURRENT_DATE) - 1
  AND rowid not in
      (
          SELECT MIN(rowid)
          FROM DDS.CMD_CCE_PROCESSES_PARCED_FL
          WHERE DATE_VALUE = to_date(CURRENT_DATE) - 1
          GROUP BY DATE_VALUE,
                   GM_SYSTEM_CODE,
                   DATE_CHANGE,
                   PROCESSID,
                   DATEPROCESSSTART,
                   CLIENTID,
                   DEFINITIONKEY,
                   CHANNEL,
                   CREDITPRODUCTTYPE,
                   INITIATORNAME,
                   INITIATORCODE,
                   POSCODE,
                   DELIVERYCITY,
                   MOBILEPHONE,
                   TRUSTEDPHONE,
                   STATUS,
                   TIMEOUT,
                   SCORE,
                   COUNT,
                   CODE
      );
