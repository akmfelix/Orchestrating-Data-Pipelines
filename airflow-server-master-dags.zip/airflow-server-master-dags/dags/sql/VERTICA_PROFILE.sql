SELECT OPER_DATE, PRIORITY, DEPEND_READY, PROC_RUNNING, PROC_ERROR, PROC_READY, TOTAL
from (
SELECT pl.*
             , p.PRIORITY 
             , sum(case when pl.DEPEND_READY_FL = 1 then 1 else 0 end) over(partition by p.PRIORITY) as DEPEND_READY
             , sum(case when pl.PROC_READY_FL = 1 then 1 else 0 end) over(partition by p.PRIORITY) as PROC_READY
             , sum(case when pl.PROC_READY_FL = 2 then 1 else 0 end) over(partition by p.PRIORITY) as PROC_RUNNING
             , sum(case when pl.PROC_READY_FL = 3 then 1 else 0 end) over(partition by p.PRIORITY) as PROC_ERROR
             , count(p.PRIORITY) over(partition by p.PRIORITY) as TOTAL       
       from mdm_tech.profile_log pl 
       left join (
             SELECT DISTINCT VRT_TABLE_NAME, PRIORITY 
             from mdm_tech.profile_relation 
       ) p on lower(p.VRT_TABLE_NAME) = lower(pl.VRT_TABLE_NAME)
       where OPER_DATE = (SELECT max(OPER_DATE) from mdm_tech.profile_log)--date '2024-03-24'
       order by OPER_DATE, PRIORITY, VRT_TABLE_NAME
       ) t 
group by OPER_DATE, PRIORITY, DEPEND_READY, PROC_READY, PROC_RUNNING, PROC_ERROR, TOTAL
order by PRIORITY
