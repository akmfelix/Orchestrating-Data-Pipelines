SELECT *
FROM TMD.DDS_LOAD_LOG 
WHERE 1=1
	AND operation_date = to_char(sysdate-1, 'YYYYMMDD')
