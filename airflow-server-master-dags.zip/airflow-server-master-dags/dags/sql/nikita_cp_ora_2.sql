DELETE
FROM DDS.CMD_CCE_VERIFICATION_SET_FL
WHERE DATE_VALUE = to_date(CURRENT_DATE) - 1
  AND rowid not in
      (
          SELECT MIN(rowid)
          FROM DDS.CMD_CCE_VERIFICATION_SET_FL
          WHERE DATE_VALUE = to_date(CURRENT_DATE) - 1
          GROUP BY DATE_VALUE,
                   GM_SYSTEM_CODE,
                   DATE_CHANGE,
                   PROCESSID,
                   DATEPROCESSSTART,
                   ID,
                   DEFINITIONKEY,
                   DEFINITIONVERSION,
                   USERID,
                   CREATEDATE,
                   IIN,
                   STATUS,
                   STATUSCHANGEDATE,
                   TIMEOUT,
                   DETAILS,
                   CURRENT_PROCESSID
      );