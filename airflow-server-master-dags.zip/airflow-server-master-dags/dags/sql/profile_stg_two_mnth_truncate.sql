SELECT DROP_PARTITIONS('profile_stg.HB_STATISTICS_FL', date '{{ date_from }}', date '{{ date_to }}');
SELECT DROP_PARTITIONS('profile_stg.P_HB_STATISTICS_AGGR_MNTH', date '{{ date_from }}', date '{{ date_to }}', 'true');
SELECT DROP_PARTITIONS('profile_stg.P_HB_STATISTICS_HIST_SNPSH', date '{{ date_from }}', date '{{ date_to }}');