select max(load_id) max_load_id,
       case
           when (rs_is_ready + bs_is_ready + w4_is_ready + ocrm_is_ready) = 4
               and rs_date_start = '{{ load_date }}'
               and bs_date_start = '{{ load_date }}'
               and w4_date_start = '{{ load_date }}'
               and ocrm_date_start = '{{ load_date }}' then 1
           else 0 end as mdm_is_ready
from (
         select m.load_id,
                rs_log.is_ready           as rs_is_ready,
                date(rs_log.date_start)   as rs_date_start,
                date(rs_log.date_end)     as rs_date_end,
                bs_log.is_ready           as bs_is_ready,
                date(bs_log.date_start)   as bs_date_start,
                date(bs_log.date_end)     as bs_date_end,
                w4_log.is_ready           as w4_is_ready,
                date(w4_log.date_start)   as w4_date_start,
                date(w4_log.date_end)     as w4_date_end,
                ocrm_log.is_ready         as ocrm_is_ready,
                date(ocrm_log.date_start) as ocrm_date_start,
                date(ocrm_log.date_end)   as ocrm_date_end
         from mdm.mdm_load_process_log m
                  left join mdm.mdm_log rs_log on m.last_succ_load_id_rs = rs_log.load_id and rs_log.source_code = 'RS'
                  left join mdm.mdm_log bs_log on m.last_succ_load_id_bs = bs_log.load_id and bs_log.source_code = 'CBS'
                  left join mdm.mdm_log w4_log on m.last_succ_load_id_w4 = w4_log.load_id and w4_log.source_code = 'W4'
                  left join mdm.mdm_log ocrm_log on m.last_succ_load_id_ocrm = ocrm_log.load_id and ocrm_log.source_code = 'OCRM'
         where m.load_id > 30
         order by m.load_id desc) tt
where mdm_is_ready = 1
group by rs_is_ready, bs_is_ready, w4_is_ready, ocrm_is_ready, rs_date_start, bs_date_start, w4_date_start, ocrm_date_start
