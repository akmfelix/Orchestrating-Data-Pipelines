call {{ procedure_name }}('{{ load_date }}', {{ load_id }}); 
