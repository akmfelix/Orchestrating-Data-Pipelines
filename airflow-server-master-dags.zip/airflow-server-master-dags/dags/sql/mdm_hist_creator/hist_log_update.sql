update mdm_tech.mdmhist_log
set {{ upd_column }} = {{ success_fl }}
where loaded_date = '{{ load_date }}'
and loaded_id = {{ load_id }}
and state = 'RUNNING'
