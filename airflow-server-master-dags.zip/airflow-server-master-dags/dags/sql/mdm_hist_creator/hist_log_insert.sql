INSERT INTO mdm_tech.mdmhist_log(loaded_id, loaded_date, state, date_begin)
values({{ load_id }} , '{{ load_date }}', 'RUNNING', current_timestamp)

