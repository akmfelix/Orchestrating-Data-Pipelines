update mdm_tech.mdmhist_log
set date_end = current_timestamp, state = '{{ load_state }}'
where loaded_date = '{{ load_date }}'
and loaded_id = {{ load_id }}
and state = 'RUNNING'

