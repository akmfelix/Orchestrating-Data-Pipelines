SELECT to_char(statement_date,'dd.mm.yyyy'), count(IIN)
FROM compensation.participant_list
group by to_char(statement_date,'dd.mm.yyyy')
order by 1 desc;