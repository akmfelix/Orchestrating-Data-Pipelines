SELECT
	campaigncode
	, campaignname
	, flowchartname
	, channel
	, status
	, count(*)
FROM uac_sys.hb_output_table
WHERE created_datetime >= trunc(sysdate)
	AND campaigncode IN  (
		'C000006477', 
		'C000004030', 
		'C000001680', 
		'C000008216', 
		'C000007892', 
		'C000002214', 
		'C000007504',
		'C000007291', 
		'C000007486', 
		'C000007306', 
		'C000007490',
		'C000001984',
		'C000008481',
		'C000009185',
		'C000004070',
		'C000004068',
		'C000004018',
		'C000002293',
		'C000001381',
		'C000001486',
		'C000001490',
		'C000007256')
GROUP BY campaigncode, campaignname, flowchartname, channel, status
