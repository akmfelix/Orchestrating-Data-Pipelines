SELECT count(*) FROM mdm_tech.mdmhist_log WHERE loaded_date='${VAL_DATE}' AND state = 'OK'
