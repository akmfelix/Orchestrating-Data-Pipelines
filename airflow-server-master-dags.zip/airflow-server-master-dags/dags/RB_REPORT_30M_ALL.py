import time
from datetime import datetime

import pandas as pd
from airflow import DAG
from airflow.operators.email import EmailOperator
from airflow.operators.python import BranchPythonOperator, PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.utils.dates import days_ago

home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"
apps = dags + "apps/"

default_args = {"owner": "00029260", "email": ["AiygerimIB@halykbank.kz"]}

timestr = time.strftime("%Y-%m-%d")

fname = temp_dir + timestr + ".csv"
xls_fname = temp_dir + timestr + ".xlsx"

sql = """select P_SID,IIN,CAMPAIGNCODE,SHORT_DESC,UPLOAD_DATE,PHONE,P_SID_OCRM from spss_se.rb2_tm_campaigns c where c.upload_date=(select max(upload_date) from spss_se.rb2_tm_campaigns ) order by c.CAMPAIGNCODE"""

ORACLE_CONN_ID = "SPSS_SE"

def get_data_from_oracle():
    oracle_hook = OracleHook(oracle_conn_id=ORACLE_CONN_ID)
    pd.DataFrame(
        oracle_hook.get_records(sql=sql),
        columns=["P_SID","IIN","CAMPAIGNCODE","SHORT_DESC","UPLOAD_DATE","PHONE","P_SID_OCRM"],
    ).to_csv(fname, index=False)
    return fname

def validate_csv():
    df = pd.read_csv(fname, converters={"iin": str})
    if not df.empty:
        sheetname = timestr
        writer = pd.ExcelWriter(xls_fname, engine="xlsxwriter")
        df.to_excel(writer, sheet_name=sheetname, index=False)  # send df to writer
        worksheet = writer.sheets[sheetname]  # pull worksheet object
        for idx, col in enumerate(df):  # loop through all columns
            series = df[col]
            max_len = (
                max(
                    (
                        series.astype(str).map(len).max(),  # len of largest item
                        len(str(series.name)),  # len of column name/header
                    )
                )
                + 1
            )  # adding a little extra space
            worksheet.set_column(idx, idx, max_len)  # set column width
        # writer.save()
        writer.close()
        # df.to_excel(xls_fname, index=False)
        return "branch_ok"
    else:
        return "branch_not_ok"

with DAG(
    tags=["AiygerimIB@halykbank.kz", "daily", "email", "dssb_se", "oracle", "aygeimibrayeva", "rb"],
    dag_id="RB_REPORT_30M_ALL",
    description="Отчет по кампаниям C00020512, C00020549, C00020586",
    start_date=datetime(2025, 1, 13),
    schedule_interval="*/30 * * * *",    
    catchup=False,
    default_args=default_args,
) as dag:
    ora_extract = PythonOperator(task_id="ora_extract_task", python_callable=get_data_from_oracle)
    branch_task = BranchPythonOperator(
        task_id="validate_csv",
        python_callable=validate_csv,
        dag=dag,
    )
    branch_ok = EmailOperator(
        task_id="branch_ok",
        to=["KuanysKu@halykbank.kz", "ZanfarBe@halykbank.kz"],
        subject="Отчет по 30 минут",
        html_content="Отчет по кампаниям C00020512, C00020549, C00020586. "
        "",
        files=[xls_fname],
    )
    branch_not_ok = EmailOperator(
        task_id="branch_not_ok",
        to=["AiygerimIB@halykbank.kz"],
        subject="ERROR in DAG RB_REPORT_30M_ALL",
        html_content="Dataset is empty",
    )

ora_extract >> branch_task
branch_task >> branch_ok
branch_task >> branch_not_ok
