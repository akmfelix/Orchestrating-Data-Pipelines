from datetime import datetime, timedelta

import airflow
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.providers.oracle.operators.oracle import OracleOperator

from source.telegram_notifications import (
    TelegramErrorNotification,
    TelegramSuccessNotification,
)


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"
apps = dags + "apps/"


home_dir = apps + "RISK_CMD_CCE_JSON/"
spark_files_dir = temp_dir

default_args = {
    "owner": "AlibekDz",
    "email": ["NikitaMi@halykbank.kz", "AlibekDz@halykbank.kz", "AiysulySH@halykbank.kz"],
    "email_on_failure": True,
    "start_date": datetime(2023, 6, 4),
    "on_failure_callback": [TelegramErrorNotification()],
}

spark_default_conf = {
    "spark.master": "yarn",
    "spark.submit.deployMode": "cluster",
    "spark.yarn.queue": "dm",
    "spark.rpc.message.maxSize": 256,
    "spark.hadoop.yarn.timeline-service.enabled": False,
    "spark.local.dir": spark_files_dir,
}


def spark_submit_generator(name, driver_memory="16G"):
    return SparkSubmitOperator(
        task_id=str(name),
        conn_id="spark_default",
        application=home_dir + str(name + ".py"),
        executor_memory="8G",
        driver_memory=driver_memory,
        num_executors=8,
        principal="ADH_Runner_CDO@HALYKBANK.NB",
        keytab="/opt/airflow/config/credentials/hadoop/krb5.keytab",
        py_files=home_dir + "setting_funcs.zip",
        name=name,
        jars=home_dir + "ojdbc8-21.1.0.0.jar",
        verbose=True,
        conf=spark_default_conf,
    )


def spark_submit_generator_kastyl(name, driver_memory="16G"):
    return SparkSubmitOperator(
        task_id=str(name),
        conn_id="spark_default",
        application=home_dir + str(name + ".py"),
        executor_memory="24G",
        driver_memory="24G",
        num_executors=8,
        principal="ADH_Runner_CDO@HALYKBANK.NB",
        keytab="/opt/airflow/config/credentials/hadoop/krb5.keytab",
        name=name,
        jars="/opt/airflow/dags/apps/RISK_CMD_CCE_JSON/jars/ojdbc8-21.1.0.0.jar",
        py_files=home_dir + "Writers.zip",
        verbose=True,
        conf=spark_default_conf,
    )


def bash_sleep_1m_generator(name, trigger_rule):
    return BashOperator(task_id=str(name), bash_command="sleep 1m", trigger_rule=trigger_rule)


def bash_sleep_custom_generator(name, minutes: str):
    return BashOperator(task_id=str(name), bash_command="sleep " + minutes)


def oracle_operator_generator(name, path):
    return OracleOperator(task_id=str(name), oracle_conn_id="EDW_ETL_CDO", sql=str(path), autocommit=True)


def truncate_partion(name):
    query = """
        DECLARE
            extract_date DATE;
            table_list SYS.ODCIVARCHAR2LIST;
        BEGIN
            SELECT
                OPER_DATE 
            INTO 
                extract_date
            FROM
    	        RISKDM.AIRFLOW_ETL_DATA
            WHERE
                DAG_NAME = 'EDW_CMD_RISKDM'
                AND STATUS = 'WAITING';

            table_list := SYS.ODCIVARCHAR2LIST(
                'CMD_CCE_OFFERS_FL',
                'CMD_CCE_PROCESS_STATUSES_FL', 
                'CMD_CCE_PROCESSES_FL',
                'CMD_CCE_RESPONSES_FL', 
                'CMD_CCE_SHOPPING_CARTS_FL'
            );

            FOR i IN 1 .. table_list.COUNT LOOP
                DDS.TRUNCATE_PARTITION_CDO_P(table_list(i),TO_CHAR(extract_date, 'YYYYMMDD'));
            END LOOP;
        END;    
        """
    return OracleOperator(task_id=str(name), oracle_conn_id="EDW_ETL_CDO", sql=query, autocommit=True)


with airflow.DAG(
    dag_id="EDW_LOADER_CMD_CCE_JSON",
    tags=["EDW_LOADER", "CMD", "DDS", "EDW", "SPARK", "ODS"],
    default_args=default_args,
    schedule_interval="20 1 * * *",
    # schedule_interval='@once',
    dagrun_timeout=timedelta(minutes=360),
    description="Парсинг и загрузка данных процесса кредитования в ХД",
    catchup=False,
) as dag_spark:

    RISK_CMD_DATA_PREPARER: SparkSubmitOperator = spark_submit_generator_kastyl("RISK_CMD_DATA_PREPARER")
    # SPARK SUBMIT JOBS
    RISK_CMD_ST1_OFFERS: SparkSubmitOperator = spark_submit_generator("RISK_CMD_ST1_OFFERS")
    # RISK_CMD_ST1_APPLICATION_FIELD: SparkSubmitOperator = spark_submit_generator('RISK_CMD_ST1_APPLICATION_FIELD')
    RISK_CMD_ST1_PROCESS_STATUSES: SparkSubmitOperator = spark_submit_generator("RISK_CMD_ST1_PROCESS_STATUSES")
    RISK_CMD_ST1_PROCESSES: SparkSubmitOperator = spark_submit_generator("RISK_CMD_ST1_PROCESSES")
    RISK_CMD_ST1_RESPONSES: SparkSubmitOperator = spark_submit_generator("RISK_CMD_ST1_RESPONSES")
    RISK_CMD_ST1_SHOPPING_CARTS: SparkSubmitOperator = spark_submit_generator("RISK_CMD_ST1_SHOPPING_CARTS")

    # Oracle Jobs
    # App_F1
    # AppF_1: OracleOperator = oracle_operator_generator('AppF_1', 'sql/Application_Fields/AppF_1.sql')
    # AppF_2: OracleOperator = oracle_operator_generator('AppF_2', 'sql/Application_Fields/AppF_2.sql')
    # AppF_3: OracleOperator = oracle_operator_generator('AppF_3', 'sql/Application_Fields/AppF_3.sql')
    # AppF_4: OracleOperator = oracle_operator_generator('AppF_4', 'sql/Application_Fields/AppF_4.sql')
    # AppF_5: OracleOperator = oracle_operator_generator('AppF_5', 'sql/Application_Fields/AppF_5.sql')
    # AppF_6: OracleOperator = oracle_operator_generator('AppF_6', 'sql/Application_Fields/AppF_6.sql')

    # offers
    offers_1: OracleOperator = oracle_operator_generator("offers_1", "sql/Offers/offers_1.sql")
    offers_2: OracleOperator = oracle_operator_generator("offers_2", "sql/Offers/offers_2.sql")
    offers_3: OracleOperator = oracle_operator_generator("offers_3", "sql/Offers/offers_3.sql")
    offers_4: OracleOperator = oracle_operator_generator("offers_4", "sql/Offers/offers_4.sql")
    offers_5: OracleOperator = oracle_operator_generator("offers_5", "sql/Offers/offers_5.sql")
    offers_6: OracleOperator = oracle_operator_generator("offers_6", "sql/Offers/offers_6.sql")

    # Process_Statuses
    ProcS_1: OracleOperator = oracle_operator_generator("ProcS_1", "sql/Process_Statuses/ProcS_1.sql")
    ProcS_2: OracleOperator = oracle_operator_generator("ProcS_2", "sql/Process_Statuses/ProcS_2.sql")
    ProcS_3: OracleOperator = oracle_operator_generator("ProcS_3", "sql/Process_Statuses/ProcS_3.sql")
    ProcS_4: OracleOperator = oracle_operator_generator("ProcS_4", "sql/Process_Statuses/ProcS_4.sql")
    ProcS_5: OracleOperator = oracle_operator_generator("ProcS_5", "sql/Process_Statuses/ProcS_5.sql")
    ProcS_6: OracleOperator = oracle_operator_generator("ProcS_6", "sql/Process_Statuses/ProcS_6.sql")

    # Processes
    processes_1: OracleOperator = oracle_operator_generator("processes_1", "sql/Processes/processes_1.sql")
    processes_2: OracleOperator = oracle_operator_generator("processes_2", "sql/Processes/processes_2.sql")
    processes_3: OracleOperator = oracle_operator_generator("processes_3", "sql/Processes/processes_3.sql")
    processes_4: OracleOperator = oracle_operator_generator("processes_4", "sql/Processes/processes_4.sql")
    processes_5: OracleOperator = oracle_operator_generator("processes_5", "sql/Processes/processes_5.sql")
    processes_6: OracleOperator = oracle_operator_generator("processes_6", "sql/Processes/processes_6.sql")

    # Responses
    responses_1: OracleOperator = oracle_operator_generator("responses_1", "sql/Responses/responses_1.sql")
    responses_2: OracleOperator = oracle_operator_generator("responses_2", "sql/Responses/responses_2.sql")
    responses_3: OracleOperator = oracle_operator_generator("responses_3", "sql/Responses/responses_3.sql")
    responses_4: OracleOperator = oracle_operator_generator("responses_4", "sql/Responses/responses_4.sql")
    responses_5: OracleOperator = oracle_operator_generator("responses_5", "sql/Responses/responses_5.sql")
    responses_6: OracleOperator = oracle_operator_generator("responses_6", "sql/Responses/responses_6.sql")

    # Shopping Carts
    ShopC_1: OracleOperator = oracle_operator_generator("ShopC_1", "sql/Shopping_Carts/ShopC_1.sql")
    ShopC_2: OracleOperator = oracle_operator_generator("ShopC_2", "sql/Shopping_Carts/ShopC_2.sql")
    ShopC_3: OracleOperator = oracle_operator_generator("ShopC_3", "sql/Shopping_Carts/ShopC_3.sql")
    ShopC_4: OracleOperator = oracle_operator_generator("ShopC_4", "sql/Shopping_Carts/ShopC_4.sql")
    ShopC_5: OracleOperator = oracle_operator_generator("ShopC_5", "sql/Shopping_Carts/ShopC_5.sql")
    ShopC_6: OracleOperator = oracle_operator_generator("ShopC_6", "sql/Shopping_Carts/ShopC_6.sql")

    Sleep_1: BashOperator = bash_sleep_1m_generator("Sleep_1", trigger_rule="all_done")
    Sleep_2: BashOperator = bash_sleep_1m_generator("Sleep_2", trigger_rule="all_done")

    truncate_task: OracleOperator = truncate_partion(name='trunc_task')

    start: EmptyOperator = EmptyOperator(task_id="start")
    preparer: EmptyOperator = EmptyOperator(task_id="preparer")
    end: EmptyOperator = EmptyOperator(
        task_id="end",
        on_success_callback=[TelegramSuccessNotification()],
    )

start >> truncate_task

truncate_task >> RISK_CMD_DATA_PREPARER >> RISK_CMD_ST1_OFFERS >> RISK_CMD_ST1_PROCESSES >> Sleep_1
# start >> RISK_CMD_ST1_APPLICATION_FIELD >> RISK_CMD_ST1_RESPONSES >> Sleep_1
truncate_task >> RISK_CMD_DATA_PREPARER >> RISK_CMD_ST1_RESPONSES >> Sleep_1

truncate_task >> RISK_CMD_DATA_PREPARER >> RISK_CMD_ST1_PROCESS_STATUSES >> RISK_CMD_ST1_SHOPPING_CARTS >> Sleep_1

RISK_CMD_ST1_OFFERS >> Sleep_2 >> offers_1 >> offers_2 >> offers_3 >> offers_4 >> offers_5 >> offers_6 >> preparer
# RISK_CMD_ST1_APPLICATION_FIELD >> Sleep_2 >> AppF_1 >> AppF_2 >> AppF_3 >> AppF_4 >> AppF_5 >> AppF_6 >> end
RISK_CMD_ST1_PROCESS_STATUSES >> Sleep_2 >> ProcS_1 >> ProcS_2 >> ProcS_3 >> ProcS_4 >> ProcS_5 >> ProcS_6 >> preparer

Sleep_1 >> processes_1 >> processes_2 >> processes_3 >> processes_4 >> processes_5 >> processes_6 >> preparer
Sleep_1 >> responses_1 >> responses_2 >> responses_3 >> responses_4 >> responses_5 >> responses_6 >> preparer
Sleep_1 >> ShopC_1 >> ShopC_2 >> ShopC_3 >> ShopC_4 >> ShopC_5 >> ShopC_6 >> preparer
preparer >> end
