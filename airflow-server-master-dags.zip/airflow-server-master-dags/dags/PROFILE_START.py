from datetime import datetime, timedelta

from airflow import DAG, AirflowException
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator, PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.vertica.hooks.vertica import VerticaHook


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/MDM/"
profile = dags + "profile/"

default_args = {
    "owner": "NikitaMi",
    "email_on_failure": True,
    "start_date": datetime(2024, 3, 11),
    "email": ["NikitaMi@halykbank.kz", "AiysulySH@halykbank.kz"],
    # 'retries': 5,
    # 'retry_delay': timedelta(minutes=10),
    "catchup": False,
}

days = 0

user_EDW_ETL_CDO = "EDW_ETL_CDO"
user_ETL_REP = "ETL_REP"
user_VERTICA = "Vertica_Prod"
profile_relation = "mdm_tech.profile_relation"
profile_log = "mdm_tech.profile_log"


def set_date(**kwargs):  # функция устанавливает максимальную дату из логов по умолчанию
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    # vertica_cursor.execute("\
    #     SELECT MAX(OPER_DATE)+1 as OPER_DATE \
    #     FROM mdm_tech.PROFILE_LOG \
    #     WHERE DATE_TRUNC('DAY', DATE_CHANGE) <> CURRENT_DATE AND PROC_READY_FL=1"
    # )

    # ЕСЛИ ХОТИТЕ ЗАГРУЗИТЬ ДАННЫЕ ЗА ОТСТАВШИЙ ДЕНЬ ЗАКОММЕНТИТЕ СКРИПТ ВЫШЕ И РАСКОММЕНТИТЕ НИЖЕ И ИЗМЕНИТЕ ДАТУ !!!!
    vertica_cursor.execute("SELECT CURRENT_DATE-2")

    oper = vertica_cursor.fetchone()
    # print(oper, 'oper')
    global days
    days = (datetime.now().date() - oper[0]).days
    # print('set date',days)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="max_date", value=days)


def start_log(**kwargs):
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    print("pulled  max_date", days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    sql_delete = (
        "\
        DELETE FROM mdm_tech.profile_log \
        WHERE OPER_DATE = CURRENT_DATE -"
        + str(days)
    )

    vertica_cursor.execute(sql_delete)

    sql_start = (
        "\
        INSERT INTO mdm_tech.profile_log \
        SELECT DISTINCT\
            upper(VRT_TABLE_NAME),\
            upper(VRT_PROC_NAME),\
            CURRENT_DATE-"
        + str(days)
        + ",\
            CURRENT_TIMESTAMP,\
            NULL,\
            NULL,\
            SRC_DATABASE,\
            0,\
            0\
        FROM mdm_tech.profile_relation"
    )

    vertica_cursor.execute(sql_start)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def branch_date():  # проверяет если таск старта уже сработал то запускай дату максимальную
    now = datetime.now()

    current_time = now.strftime("%H:%M:%S")
    print("current_time", current_time)
    if (
        current_time <= "01:10:00"
    ):  # airflow UTC+5, но питон показывает UTC+0 ------------------------------------------------------------------------
        return "start_log"
    else:
        return "empty_operator"


def extract_relation(**kwargs):
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # print('pulled  max_date', days)

    # VERTICA
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()
    vertica_cursor.execute(
        " \
        SELECT distinct upper(pr.VRT_PROC_NAME), \
            CASE \
                WHEN SRC_SCHEMA = 'DDS' THEN SRC_SCHEMA || '.' || upper(NVL(SRC_SESSION, SRC_TABLE_NAME)) \
                WHEN SRC_SCHEMA = 'DM' THEN SRC_SCHEMA || '.' || upper(NVL(SRC_TABLE_NAME, SRC_SESSION)) \
                WHEN pr.SRC_SYSTEM = 'VERTICA' THEN pr.SRC_SYSTEM || '.' || upper(NVL(SRC_TABLE_NAME, SRC_SESSION))  \
                WHEN SRC_DATABASE = 'DSSB' THEN SRC_DATABASE || '.' || upper(NVL(SRC_TABLE_NAME, SRC_SESSION)) \
                WHEN SRC_DATABASE = 'ACRM' THEN SRC_DATABASE || '.' || upper(NVL(SRC_TABLE_NAME, SRC_SESSION)) \
                WHEN SRC_DATABASE = 'MSBSPSS' THEN SRC_DATABASE || '.' || upper(NVL(SRC_TABLE_NAME, SRC_SESSION)) \
            END SRC \
        FROM mdm_tech.profile_relation pr \
        JOIN mdm_tech.profile_log pl \
            ON upper(pl.VRT_TABLE_NAME) = upper(pr.VRT_TABLE_NAME) \
            AND upper(pl.VRT_PROC_NAME) = upper(pr.VRT_PROC_NAME) \
            AND pl.PROC_READY_FL in (0, 3) \
            AND pl.OPER_DATE = CURRENT_DATE -"
        + str(days)
        + " WHERE IS_ACTUAL=1"
    )
    cnt_dep_total = vertica_cursor.fetchall()
    # print(str(days), 'extract_relation')
    print("cnt_dep_total", cnt_dep_total)

    # -> создаем словать {процедура vertica : схема.зависимость (dds или dm)}
    relation_dict = {}
    for i in cnt_dep_total:
        if i[0] in relation_dict:
            relation_dict[i[0]].append(i[1])
        else:
            relation_dict[i[0]] = [i[1]]

    # получается что-то на примере
    """
    {'UL_PROC_10': ['DM.GR_GUARANTEES_DM'], 
        'UL_PROC_25': ['DDS.M_BS_CR_CONTRACT_SCD_S', 'DM.PD_RKO_DM'] ...., }
    """
    print(relation_dict)
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(
        key="relation", value=relation_dict
    )  # пешим словать в xcom чтобы запулить с других тасков значение


def count_dependencies(**kwargs):
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # print('pulled  max_date', days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    # берем из вертики таблицу и подсчитываем количество ее зависимостей
    vertica_cursor.execute(
        "\
        SELECT distinct upper(VRT_PROC_NAME), \
            count(DISTINCT \
                CASE \
                    WHEN SRC_SCHEMA IN ('DM') OR SRC_SYSTEM = 'VERTICA' THEN upper(NVL(SRC_TABLE_NAME, SRC_SESSION)) \
                    WHEN SRC_SCHEMA = 'DDS' THEN upper(NVL(SRC_SESSION, SRC_TABLE_NAME)) \
                    else upper(NVL(SRC_SESSION, SRC_TABLE_NAME)) \
            END) cnt \
        FROM mdm_tech.profile_relation pr \
        WHERE IS_ACTUAL=1\
        group by VRT_PROC_NAME"
    )

    # создаем словать {таблица вертики : e.g. 5 зависимостей}  для дальнейшей проверки
    cnt = vertica_cursor.fetchall()
    cnt_dict = {}
    for i in cnt:
        cnt_dict[i[0]] = i[1]
    print("cnt_dict", cnt_dict)
    """
     {'CARD_PROC': 13, 'CARD_PROC2': 8, 'CARD_PROC3': 8, ...}
    """
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="count_dict", value=cnt_dict)


def extract_EDW(**kwargs):
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # print('pulled  max_date', days)

    # ORACLE DDS DEIR_P
    oracle_hook = OracleHook(user_ETL_REP)
    oracle_conn = oracle_hook.get_conn()
    oracle_cursor = oracle_conn.cursor()

    # вытаскиваем все маппинги из ДДС которые отработали
    # для M_RS_CR_SHEDULE_FL - исключение так как даные хранятся только за t-1 остальное удялаяют
    sql_dds = (
        """
        SELECT FIRST_VALUE(upper(ENTITY)) OVER(PARTITION BY ENTITY ORDER BY BEGIN_DATETIME DESC) entity, 
            CASE WHEN STATE = 'true' THEN 1 ELSE 0 END AS state 
        FROM tmd.DDS_LOAD_LOG d 
        WHERE 1=1
        AND upper(ENTITY) NOT LIKE 'M_RS_CR_SHEDULE_FL%'
        AND OPERATION_DATE  = TO_CHAR(SYSDATE - """
        + str(days)
        + """, 'YYYYMMDD')
        UNION
        SELECT FIRST_VALUE(upper(ENTITY)) OVER(PARTITION BY ENTITY ORDER BY BEGIN_DATETIME DESC) entity, 
            CASE WHEN STATE = 'true' THEN 1 ELSE 0 END AS state 
        FROM tmd.DDS_LOAD_LOG d 
        WHERE 1=1
        AND upper(ENTITY) LIKE 'M_RS_CR_SHEDULE_FL%'
        AND OPERATION_DATE  = TO_CHAR(SYSDATE - 1, 'YYYYMMDD') 
    """
    )

    oracle_cursor.execute(sql_dds)
    dds_ready = oracle_cursor.fetchall()
    # print('dds_ready', dds_ready)
    dds_ready_dict = {}
    for i in dds_ready:
        dds_ready_dict[i[0]] = i[1]
    print("dds_ready_dict", dds_ready_dict)
    """
    [('M_AML_FL_CLIENTS_PROFILES_FL', 1), ('M_AML_TB_DICT_COUNTRY_H', 1), ('M_AML_TB_DICT_OKED_H', 0), ... ]
    """
    oracle_cursor.close()
    oracle_conn.close()

    # ORACLE DDS EDW_ETL_CDO RISKDM
    oracle_hook = OracleHook(user_EDW_ETL_CDO)
    oracle_conn = oracle_hook.get_conn()
    oracle_cursor = oracle_conn.cursor()

    # вытаскиваем все маппинги из ДДС которые отработали
    sql_dds = (
        "\
        SELECT upper(TABLE_NAME), cast(STATUS AS int) STATUS\
        FROM riskdm.AIRFLOW_TABLES_DATA \
        union \
        SELECT upper(DAG_NAME) AS entity, \
            CASE WHEN STATUS = 'SUCCESSFULLY' THEN 1 ELSE 0 END status \
        FROM riskdm.AIRFLOW_ETL_DATA  \
        WHERE OPER_DATE = trunc(SYSDATE)-"
        + str(days)
    )

    oracle_cursor.execute(sql_dds)
    risdm_ready = oracle_cursor.fetchall()
    # print('risdm_ready', risdm_ready)
    risdm_ready_dict = {}
    for i in risdm_ready:
        risdm_ready_dict[i[0]] = i[1]
    print("risdm_ready_dict", risdm_ready_dict)
    """
     [('CMD_CCE_ACCOUNT_DEBT_FL', 1), ('CMD_CCE_APPLICATION_FIELDS_FL', 1), ...
    """
    oracle_cursor.close()
    oracle_conn.close()

    # ORACLE DM
    oracle_hook = OracleHook(user_EDW_ETL_CDO)
    oracle_conn = oracle_hook.get_conn()
    oracle_cursor = oracle_conn.cursor()

    # вытаскиваем все витрины из ДМ которые отработали
    sql_dm = (
        "\
        SELECT FIRST_VALUE(SUBSTR(upper(WF_NAME), 4, 100)) OVER(PARTITION BY WF_NAME ORDER BY DATE_CHANGE DESC) entity,\
	        DM_READY_FL\
        FROM predds.DM_SHED_TABLE \
        WHERE DATE_VALUE  = TRUNC(SYSDATE) -"
        + str(days)
    )
    oracle_cursor.execute(sql_dm)
    dm_ready = oracle_cursor.fetchall()
    dm_ready_dict = {}
    for i in dm_ready:
        dm_ready_dict[i[0]] = i[1]
    print("dm_ready_dict", dm_ready_dict)
    """
    {'AP_APPLICATION_DM': 1, 'BS_CREDIT_DM': 1, 'CA_ACCOUNT_DM': 1, ...
    """
    oracle_cursor.close()
    oracle_conn.close()

    dds_ready_dict.update(risdm_ready_dict)  # соедиянем два словаря RISKDM and DDS
    kwargs["ti"].xcom_push(key="dds_ready_dict", value=dds_ready_dict)
    kwargs["ti"].xcom_push(key="dm_ready_dict", value=dm_ready_dict)


def extract_VERTICA(**kwargs):
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # print('pulled  max_date', days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    sql_vertica = (
        """SELECT DISTINCT upper(pr.VRT_TABLE_NAME2), pl.DEPEND_READY_FL 
        FROM mdm_tech.PROFILE_LOG pl 
        JOIN ( 
            SELECT DISTINCT pr.VRT_TABLE_NAME, pr.VRT_PROC_NAME, pr2.VRT_TABLE_NAME VRT_TABLE_NAME2, pr2.VRT_PROC_NAME VRT_PROC_NAME2 
            FROM mdm_tech.profile_relation pr 
            JOIN mdm_tech.profile_relation pr2 
                ON upper(pr.SRC_TABLE_NAME) = upper(pr2.VRT_TABLE_NAME) 
                AND upper(pr.SRC_SESSION)  = upper(pr2.VRT_PROC_NAME) 
                AND pr2.IS_ACTUAL = 1
                AND pr2.PRIORITY IN (1, 2, 3)) pr 
            ON upper(pr.VRT_TABLE_NAME2) = upper(pl.VRT_TABLE_NAME) 
            AND upper(pr.VRT_PROC_NAME2) = upper(pl.VRT_PROC_NAME) 
        WHERE pl.PROC_READY_FL = 1 AND pl.OPER_DATE = CURRENT_DATE - """
        + str(days)
        + """ 
        UNION
        SELECT DISTINCT upper(pr.VRT_TABLE_NAME2), pl.PROC_READY_FL 
        FROM mdm_tech.PROFILE_LOG pl 
        JOIN ( 
            SELECT DISTINCT pr.VRT_TABLE_NAME, pr.VRT_PROC_NAME, pr2.VRT_TABLE_NAME VRT_TABLE_NAME2, pr2.VRT_PROC_NAME VRT_PROC_NAME2 
            FROM mdm_tech.profile_relation pr 
            JOIN mdm_tech.profile_relation pr2 
                ON upper(pr.SRC_TABLE_NAME) = upper(pr2.VRT_TABLE_NAME) 
                AND upper(pr.SRC_SESSION)  = upper(pr2.VRT_PROC_NAME) 
                AND pr2.IS_ACTUAL = 1
                AND pr2.PRIORITY IN (5, 6, 7, 8)) pr 
            ON upper(pr.VRT_TABLE_NAME2) = upper(pl.VRT_TABLE_NAME) 
            AND upper(pr.VRT_PROC_NAME2) = upper(pl.VRT_PROC_NAME) 
        WHERE pl.PROC_READY_FL = 1 AND pl.OPER_DATE = CURRENT_DATE - """
        + str(days)
    )
    vertica_cursor.execute(sql_vertica)
    vertica_ready = vertica_cursor.fetchall()

    vertica_ready_dict = {}
    for i in vertica_ready:
        vertica_ready_dict[i[0]] = i[1]
    # print('sql_vertica', sql_vertica)
    print("vertica_ready_dict", vertica_ready_dict)
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()
    """
    {'HB_STATISTICS_FL': 0, 'OTHER_11': 0, 'OTHER_21': 0, ...
    """
    kwargs["ti"].xcom_push(key="vertica_ready_dict", value=vertica_ready_dict)


def final_result(**kwargs):
    # ниже мы забираем все нужные данные с xcom

    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # print('pulled  max_date', days)

    vertica_ready_dict = kwargs["ti"].xcom_pull(key="vertica_ready_dict", task_ids="extractVERTICA")
    print("pulled  vertica_ready_dict", vertica_ready_dict)

    dds_ready_dict = kwargs["ti"].xcom_pull(key="dds_ready_dict", task_ids="extractEDW")
    print("pulled  dds_ready_dict", dds_ready_dict)

    dm_ready_dict = kwargs["ti"].xcom_pull(key="dm_ready_dict", task_ids="extractEDW")
    print("pulled  dm_ready_dict", dm_ready_dict)

    relation_dict = kwargs["ti"].xcom_pull(key="relation", task_ids="extract_relations")
    print("pulled  relation_dict", relation_dict)

    cnt_dict = kwargs["ti"].xcom_pull(key="count_dict", task_ids=["count_depend"])
    print("pulled cnt_dict", cnt_dict)

    result = {}

    # для процедура вертики : зависимость
    for procedure, dependencies in relation_dict.items():
        # print('dependencies', dependencies)
        result[procedure] = {}
        for dependency in dependencies:
            # print('dependency', dependency)
            if (
                dependency is not None
            ):  # исключаем потому что иногда в таблице relations может быть не заполнена зависимость процедуры
                # тут мы добавляем в резалт
                if dependency.startswith("DDS."):  # если зависимоть начинается с ДДС.
                    dds_key = dependency[4:]
                    if dds_ready_dict.get(dds_key) is None:
                        result[procedure][dependency] = 0
                    else:
                        result[procedure][dependency] = dds_ready_dict.get(dds_key)
                elif dependency.startswith("DM."):  # если зависимость начинается с ДМ.
                    dm_key = dependency[3:]
                    if dm_ready_dict.get(dm_key) is None:
                        result[procedure][dependency] = 0
                    else:
                        result[procedure][dependency] = dm_ready_dict.get(dm_key)
                elif dependency.startswith("VERTICA."):  # если зависимость начинается с VERTICA.
                    vertica_key = dependency[8:]
                    if vertica_ready_dict.get(vertica_key) is None:
                        result[procedure][dependency] = 0
                    else:
                        result[procedure][dependency] = vertica_ready_dict.get(vertica_key)
                elif procedure in cnt_dict[0].keys():
                    if dependency.startswith("ACRM."):
                        dependency = dependency[5:]
                    elif dependency.startswith("MSBSPSS."):
                        dependency = dependency[8:]
                    elif dependency.startswith("DSSB."):
                        dependency = dependency[5:]
                    result[procedure][dependency] = 1
    #  {'DSSB_PROC_712': {'M_MCG': 1, 'VERTICA.AMPLITUDE_HOMEBANK': 0, 'KINO_MODEL_SCORES': 1, 'WALLET': 1,
    # print(result)
    kwargs["ti"].xcom_push(key="result", value=result)


def update_dependencies(procedure, days):
    sql_update = (
        " \
        UPDATE mdm_tech.profile_log \
        SET DEPEND_READY_FL = 1, DATE_CHANGE = SYSDATE \
        WHERE upper(VRT_PROC_NAME) = upper('"
        + procedure
        + "') AND PROC_READY_FL <> 3 AND OPER_DATE = CURRENT_DATE-"
        + str(days)
    )

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()
    vertica_cursor.execute(sql_update)
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def load_log(**kwargs):
    # тут мы уже знаем сколько зависимостей у каждой процедура в вертике
    # и проверяем если сумма готовых зависимойстей 1+1+1 == всего зависимостей например 3
    # тогда в логи записываем 1, else 0
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # print('pulled  max_date', days)
    result = kwargs["ti"].xcom_pull(key="result", task_ids=["finalResult"])
    print("pulled result", result)
    cnt_dict = kwargs["ti"].xcom_pull(key="count_dict", task_ids=["count_depend"])
    print("pulled cnt_dict", cnt_dict)

    for procedure, dependencies in result[0].items():
        sum_ready_dependencies = sum(dependencies.values())
        expected_count = cnt_dict[0].get(procedure, 0)
        if sum_ready_dependencies == expected_count:
            update_dependencies(procedure, days)


def actual_date():
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    try:
        vertica_cursor.execute(
            """
            UPDATE mdm_tech.profile_log
            SET DATE_CHANGE = SYSDATE, DATE_START = SYSDATE, PROC_READY_FL = 2, DEPEND_READY_FL = 1
            WHERE UPPER(VRT_PROC_NAME) = 'PROFILE_ACTUAL_DATE_PROC'
        """
        )
        vertica_cursor.execute(
            """
            CALL profile_dm.profile_actual_date_proc();
        """
        )
        vertica_cursor.execute(
            """
            UPDATE mdm_tech.profile_log
            SET DATE_CHANGE = SYSDATE, DATE_END = SYSDATE, PROC_READY_FL = 1
            WHERE UPPER(VRT_PROC_NAME) = 'PROFILE_ACTUAL_DATE_PROC'
        """
        )
    except Exception as e:
        print("ERROR:", e)
        vertica_cursor.execute(
            """
            UPDATE mdm_tech.profile_log
            SET DATE_CHANGE = SYSDATE, DATE_END = SYSDATE, PROC_READY_FL = 3
            WHERE UPPER(VRT_PROC_NAME) = 'PROFILE_ACTUAL_DATE_PROC'
        """
        )

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def branch_proc(**kwargs):
    now = datetime.now()

    current_time = now.strftime("%H:%M:%S")
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    # проверяем если все процедуры отработали успешно то всЁ останавливаем!
    sql_proc_ready_fl = """
        SELECT sum(proc_ready_fl) 
        FROM mdm_tech.profile_log p
        WHERE OPER_DATE = CURRENT_DATE - """ + str(
        days
    )

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()
    print(user_VERTICA)
    vertica_cursor.execute(sql_proc_ready_fl)
    ready = vertica_cursor.fetchone()
    print(ready[0], type(ready[0]))

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    if str(current_time) > "16:00:00" or int(ready[0]) == 130:
        return "actual_date"
    elif str(current_time) <= "16:00:00":
        return "trigger_proc"


with DAG(
    tags=["PROFILE", "STEP_1"],
    catchup=False,
    dag_id="PROFILE_START",
    description="Ежедневная загрузка профиля клиента. 1-этап. Проверка зависимостей, обновление логов.",
    owner_links={"NikitaMi": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=727749873"},
    schedule_interval="0 6 * * *",
    default_args=default_args,
) as dag:
    set_date = PythonOperator(
        task_id="set_date",
        python_callable=set_date,
        dag=dag,
    )

    branch_date = BranchPythonOperator(
        task_id="branch_date",
        python_callable=branch_date,
        dag=dag,
    )

    empty_operator = DummyOperator(task_id="empty_operator", dag=dag)

    start_log = PythonOperator(
        task_id="start_log",
        provide_context=True,
        python_callable=start_log,
        dag=dag,
    )

    extract_relations = PythonOperator(
        task_id="extract_relations",
        provide_context=True,
        python_callable=extract_relation,
        trigger_rule="none_failed",
        dag=dag,
    )

    count_depend = PythonOperator(
        task_id="count_depend",
        provide_context=True,
        python_callable=count_dependencies,
        trigger_rule="none_failed",
        dag=dag,
    )

    extractEDW = PythonOperator(
        task_id="extractEDW",
        provide_context=True,
        python_callable=extract_EDW,
        trigger_rule="none_failed",
        dag=dag,
    )

    extractVERTICA = PythonOperator(
        task_id="extractVERTICA",
        provide_context=True,
        python_callable=extract_VERTICA,
        trigger_rule="none_failed",
        dag=dag,
    )

    finalResult = PythonOperator(
        task_id="finalResult",
        provide_context=True,
        python_callable=final_result,
        trigger_rule="none_failed",
        dag=dag,
    )

    loadLog = PythonOperator(
        task_id="loadLog",
        provide_context=True,
        python_callable=load_log,
        trigger_rule="none_failed",
        dag=dag,
    )

    branch_proc = BranchPythonOperator(
        task_id="branch_proc",
        python_callable=branch_proc,
        dag=dag,
    )

    trigger_proc = TriggerDagRunOperator(
        task_id="trigger_proc",
        trigger_dag_id="PROFILE_EXTERNAL_LOAD",
        conf={"days": "{{ti.xcom_pull(key='max_date', task_ids='set_date')}}"},
        wait_for_completion=False,
        dag=dag,
    )

    actual_date = PythonOperator(
        task_id="actual_date",
        provide_context=True,
        python_callable=actual_date,
        trigger_rule="none_failed",
        dag=dag,
    )


(
    set_date
    >> branch_date
    >> [start_log, empty_operator]
    >> extract_relations
    >> count_depend
    >> [extractEDW, extractVERTICA]
    >> finalResult
    >> loadLog
    >> branch_proc
    >> [actual_date, trigger_proc]
)
