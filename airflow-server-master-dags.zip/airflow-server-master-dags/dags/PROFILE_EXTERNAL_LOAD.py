import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python_operator import BranchPythonOperator, PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.vertica.hooks.vertica import VerticaHook


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/MDM/"
profile = dags + "profile/"

default_args = {
    "owner": "NikitaMi",
    "email_on_failure": True,
    "start_date": datetime(2024, 3, 11),
    "email": ["NikitaMi@halykbank.kz", "AiysulySH@halykbank.kz"],
    "email_on_failure": True,
    "catchup": False,
}

user_EDW_ETL_CDO = "EDW_ETL_CDO"
user_ETL_REP = "ETL_REP"
user_VERTICA = "Vertica_Prod"
profile_relation = "mdm_tech.profile_relation"
profile_log = "mdm_tech.profile_log"


def run_this_func(**kwargs):
    # print('kwargs', kwargs)
    global days
    days = kwargs["dag_run"].conf["days"]
    global DATE_VALUE
    DATE_VALUE = "to_char(CURRENT_DATE-" + str(days) + ")"
    # print('days', days)

    kwargs["ti"].xcom_push(key="days", value=days)
    kwargs["ti"].xcom_push(key="DATE_VALUE", value=DATE_VALUE)


def check_logs(**kwargs):
    days = kwargs["ti"].xcom_pull(key="days", task_ids=["trigger_proc"])[0]
    # print('pulled days', days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(
        """ 
        SELECT VRT_PROC_NAME
        FROM (SELECT distinct upper(pl.VRT_PROC_NAME) VRT_PROC_NAME, pr.PRIORITY 
        FROM mdm_tech.profile_log pl
        JOIN mdm_tech.profile_relation pr 
            ON upper(PL.VRT_TABLE_NAME) = upper(pr.VRT_TABLE_NAME)
            AND upper(pl.VRT_PROC_NAME) = upper(pr.VRT_PROC_NAME)
            AND PRIORITY IN (1, 2, 3) 	
        WHERE 1=1
        AND DEPEND_READY_FL = 1 
        AND PROC_READY_FL IN (0, 3) 
        AND OPER_DATE = CURRENT_DATE-"""
        + str(days)
        + ")t ORDER BY PRIORITY"
    )

    ready_proc = vertica_cursor.fetchall()
    # print('ready_proc', ready_proc)

    procedures = []
    for i in ready_proc:
        procedures.extend(i)
    # print('procedures', procedures)
    # ['OTHER_PROC2', 'UL_PROC_4', 'UL_PROC_11', 'UL_PROC_2', ...
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="procedures", value=procedures)


def update_start(proc, days):
    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    sql_update = (
        " \
        UPDATE "
        + profile_log
        + " SET DATE_START = SYSDATE, PROC_READY_FL = 2 \
        WHERE upper(VRT_PROC_NAME) in(upper('"
        + proc
        + "')) AND OPER_DATE = CURRENT_DATE-"
        + str(days)
    )

    vertica_cursor.execute(sql_update)
    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def proc_call(**kwargs):
    procedures = kwargs["ti"].xcom_pull(key="procedures", task_ids=["check_logs"])
    procedures = procedures[0]
    # print('pulled procedures', procedures)

    DATE_VALUE = kwargs["ti"].xcom_pull(key="DATE_VALUE", task_ids="trigger_proc")
    # print('pulled  max_date', DATE_VALUE)

    days = kwargs["ti"].xcom_pull(key="days", task_ids=["trigger_proc"])[0]
    # print('pulled days', days)

    vertica_hook = VerticaHook(user_VERTICA)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()
    for proc in procedures:
        if proc is None:
            continue
        if proc == "INS_SUBJECT_PROC":
            sql_call = "CALL profile_stg." + proc + "()"
        else:
            sql_call = "CALL profile_stg." + proc + "(" + DATE_VALUE + ")"

        # if proc == 'INS_SUBJECT_PROC':
        #     sql_call = "CALL public."+proc+"()"
        # else:
        #     sql_call = "CALL public."+proc+"("+ DATE_VALUE +")"

        # print (sql_call)
        sql_update = (
            " \
        UPDATE "
            + profile_log
            + " SET DATE_END = SYSDATE, PROC_READY_FL = 1 \
        WHERE upper(VRT_PROC_NAME) in(upper('"
            + proc
            + "')) AND OPER_DATE = CURRENT_DATE-"
            + str(days)
        )

        sql_error = (
            " \
        UPDATE "
            + profile_log
            + " SET DATE_END = SYSDATE, PROC_READY_FL = 3 \
        WHERE upper(VRT_PROC_NAME) in(upper('"
            + proc
            + "')) AND OPER_DATE = CURRENT_DATE-"
            + str(days)
        )

        # show_error = "SELECT m.transaction_id, m.error_code, m.message, event_timestamp \
        #     FROM v_monitor.error_messages m \
        #     WHERE date_trunc('second',event_timestamp) = '" +str((datetime.now()+ timedelta(hours=6)).strftime("%Y-%m-%d %H:%M:00"))+"'"
        # print((datetime.now()+ timedelta(hours=6)).strftime("%Y-%m-%d %H:%M:00"))

        vertica_cursor.execute(
            """
            SELECT distinct upper(pr.VRT_TABLE_NAME), TRUNCATE_FLAG
            FROM mdm_tech.profile_relation pr 
            WHERE IS_ACTUAL=1 and upper(VRT_PROC_NAME)='"""
            + proc
            + "'"
        )

        vrt_tables = vertica_cursor.fetchall()
        # print('vrt_tables', vrt_tables)

        vrt_tables_dict = {}
        for i in vrt_tables:
            vrt_tables_dict[i[0]] = i[1]
        # print('vrt_tables_dict', vrt_tables_dict)

        for vrt_tbl in vrt_tables_dict.keys():
            if vrt_tbl != "AMPLITUDE_HOMEBANK" or vrt_tbl != "DI_SERVICES":
                try:
                    flg = False
                    if vrt_tables_dict[vrt_tbl] == -1:
                        # print("select DROP_PARTITIONS ('profile_stg."+ vrt_tbl +"', CURRENT_DATE-" + str(days) + ", CURRENT_DATE-" + str(days) + ");")
                        vertica_cursor.execute(
                            "select DROP_PARTITIONS ('profile_stg."
                            + vrt_tbl
                            + "', CURRENT_DATE-"
                            + str(days)
                            + ", CURRENT_DATE-"
                            + str(days)
                            + ");"
                        )
                        flg = True
                    elif vrt_tables_dict[vrt_tbl] == 0:
                        # print("select DROP_PARTITIONS ('profile_stg."+ vrt_tbl +"', CURRENT_DATE, CURRENT_DATE);")
                        vertica_cursor.execute(
                            "select DROP_PARTITIONS ('profile_stg." + vrt_tbl + "', CURRENT_DATE, CURRENT_DATE);"
                        )
                        flg = True
                    elif vrt_tables_dict[vrt_tbl] is None:
                        flg = True
                except Exception:
                    print("Exception:", Exception)
        if flg:
            try:
                update_start(proc, days)
                # print('sql_call', sql_call)
                vertica_cursor.execute(sql_call)
            except Exception as e:
                print("ERROR:", e)
                print("SQL ERROR on script", sql_call)
                vertica_cursor.execute(sql_error)
            else:
                vertica_cursor.execute(sql_update)

        vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


with DAG(
    tags=["PROFILE", "STEP_2"],
    catchup=False,
    dag_id="PROFILE_EXTERNAL_LOAD",
    description="Ежедневная загрузка профиля клиента. 2-этап. Запуск внешних процедур Vertica",
    owner_links={"NikitaMI ": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=727749873"},
    schedule_interval=None,
    default_args=default_args,
) as dag:
    trigger_proc = PythonOperator(
        task_id="trigger_proc",
        provide_context=True,
        python_callable=run_this_func,
        dag=dag,
    )

    check_logs = PythonOperator(
        task_id="check_logs",
        provide_context=True,
        python_callable=check_logs,
        dag=dag,
    )

    proc_call = PythonOperator(
        task_id="proc_call",
        provide_context=True,
        python_callable=proc_call,
        trigger_rule="all_success",
        dag=dag,
    )

    trigger_proc2 = TriggerDagRunOperator(
        task_id="trigger_proc2",
        trigger_dag_id="PROFILE_INTERNAL_LOAD",
        conf={"days": "{{ti.xcom_pull(key='days', task_ids='trigger_proc')}}"},
        wait_for_completion=False,
        dag=dag,
    )


trigger_proc >> check_logs >> proc_call >> trigger_proc2
