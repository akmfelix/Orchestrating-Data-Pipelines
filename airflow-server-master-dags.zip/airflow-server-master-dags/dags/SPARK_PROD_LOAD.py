from datetime import datetime, timedelta

import airflow
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.providers.oracle.operators.oracle import OracleOperator


home = "/opt/airflow/"
spark_files_dir = home + "temp/"

dags = home + "dags/"
apps = dags + "apps/"

home_dir = apps + "RISK_CMD_CCE_XML/"


default_args = {
    "owner": "AiysulySH",
    "email": ["AiysulySH@halykbank.kz"],
    "email_on_failure": True,
    "start_date": datetime(2024, 6, 4),
}


spark_default_conf = {
    "spark.master": "yarn",
    "spark.submit.deployMode": "cluster",
    "spark.yarn.queue": "dm",
    "spark.hadoop.yarn.timeline-service.enabled": False,  # НЕ УБИРАТЬ!!!!
    "spark.local.dir": spark_files_dir,
}


def spark_start_func(name):
    return SparkSubmitOperator(
        task_id=str(name),
        #   conn_id='spark_default',
        application="/opt/airflow/dags/apps/test_spark_hadoop/" + str(name + ".py"),
        principal="ADH_Runner_CDO@HALYKBANK.NB",
        keytab="/opt/airflow/config/credentials/hadoop/krb5.keytab",
        name=name,
        executor_memory="8G",
        driver_memory="16G",
        num_executors=8,
        jars=home_dir + "ojdbc8-21.1.0.0.jar",
        verbose=True,
        conf=spark_default_conf,
    )


with airflow.DAG(
    dag_id="SPARK_PROD_LOAD",
    tags=["test", "4Tleusher"],
    default_args=default_args,
    schedule_interval="@once",
    description="Тест работы Airflow с Spark",
    catchup=False,
) as dag_spark:
    spark_start: SparkSubmitOperator = spark_start_func("edw_raw")
    start: EmptyOperator = EmptyOperator(task_id="start")

    start >> spark_start
