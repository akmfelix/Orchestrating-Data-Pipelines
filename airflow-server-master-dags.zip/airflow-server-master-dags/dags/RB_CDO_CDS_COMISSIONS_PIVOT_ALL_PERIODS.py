import subprocess
from datetime import datetime

from airflow import DAG
from airflow.operators.python import PythonOperator


def run_script():
    script_path = apps + "comissions_pivot_all_periods_20211223.py"
    subprocess.check_call(["python3", script_path])


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"
apps = dags + "apps/"

default_args = {
    "owner": "AdiletAl",
    "email": ["AdiletAl@halykbank.kz"],
    "email_on_failure": True,
    "start_date": datetime(2023, 5, 24),
    "retries": 0,
}

with DAG(
    default_args=default_args,
    tags=["sberdali", "daily", "python"],
    dag_id="RB_COMISSIONS_PIVOT_ALL_PERIODS",
    schedule_interval="30 0 * * *",
    catchup=False,
) as dag:
    comissions_pivot_all_periods = PythonOperator(
        task_id="launch_script_comissions_pivot_all_periods", python_callable=run_script
    )
