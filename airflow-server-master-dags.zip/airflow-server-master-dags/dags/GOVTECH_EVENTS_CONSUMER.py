import datetime as dt
import json
import logging
import typing

import oracledb
import pendulum
from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition

from source.telegram_notifications import TelegramErrorNotification


logger = logging.getLogger(__name__)

default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

columns = (
    "EVENT",
    "USER_ID",
    "SNAPSHOT_DATE",
    "TYPE",
    "DOCUMENT_TYPE",
    "ERROR_CODE",
    "ERROR_DESCRIPTION",
    "IIN",
    "REGION_ID",
    "REGION_LABEL",
    "LANG",
    "USER_AGENT",
    "CURRENT_VERSION",
    "OPERATION_DATE",
    "OPERATION_SYSTEM",
    "OPERATION_SYSTEM_VERSION",
)


def transforms(message_dict: dict) -> typing.Tuple[typing.Any, ...]:
    event = message_dict.get("event")
    user_id = message_dict.get("userId")
    _timestamp = message_dict.get("timestamp")
    if _timestamp:
        snapshot_date = dt.datetime.fromisoformat(_timestamp).date()
    else:
        snapshot_date = None

    inner_data_dict = message_dict.get("data")
    if inner_data_dict:
        _type = inner_data_dict.get("type")
        document_type = inner_data_dict.get("document_type")
        error_code = inner_data_dict.get("error_code")
        error_description = inner_data_dict.get("error_description")
        if error_description and len(error_description.encode("utf-8")) > 3000:
            # The target column for this field expects bytes and since the message value is deserialized to UTF-8, we
            # need to first encode the string to bytes, clip the bytes such that only 3000 remain, and decode back to
            # UTF-8.
            error_description = error_description.encode("utf-8")[0:3000].decode("utf-8", errors="ignore")

        iin = inner_data_dict.get("IIN")

        region_inner_dict = inner_data_dict.get("region")
        if region_inner_dict:
            region_id = region_inner_dict.get("id")
            if region_id and type(region_id) is int:
                region_id = str(region_id)
            region_label = region_inner_dict.get("label")
        else:
            region_id = None
            region_label = None
    else:
        _type = None
        document_type = None
        error_code = None
        error_description = None
        iin = None
        region_id = None
        region_label = None

    lang = message_dict.get("lang")
    user_agent = message_dict.get("userAgent")
    current_version = message_dict.get("currentVersion")
    if _timestamp:
        operation_date = dt.datetime.fromisoformat(_timestamp)
    else:
        operation_date = None

    operation_system = message_dict.get("operationSystem")
    operation_system_version = message_dict.get("operationSystemVersion")

    return (
        event,
        user_id,
        snapshot_date,
        _type,
        document_type,
        error_code,
        error_description,
        iin,
        region_id,
        region_label,
        lang,
        user_agent,
        current_version,
        operation_date,
        operation_system,
        operation_system_version,
    )


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deserialize_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    target_cols: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(target_cols)) if target_cols else "",
        values=", ".join(f":{i}" for i in range(1, len(target_cols) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.setinputsizes(
            256,
            256,
            oracledb.DB_TYPE_DATE,
            256,
            256,
            1000,
            3000,
            256,
            256,
            2000,
            30,
            1000,
            256,
            oracledb.DB_TYPE_DATE,
            1000,
            500,
        )
        try:
            cursor.executemany(None, data)
        except Exception as e:
            print(e)
            print(data)
            raise e
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    topics: typing.List[str],
    oracle_hook: OracleHook,
    consumer_config: dict,
    table_name: str,
    target_columns: typing.Tuple[str, ...],
    batch_size: int,
    poll_timeout: float = 3.0,
    threshold: int = 0,

) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe(topics, on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages and len(consumed_messages) >= threshold:
                logger.info(f"Consumed {len(consumed_messages)} messages")
                data = list(
                    transforms(deserialize_message(m))
                    for m in consumed_messages
                    if m is not None  # and m.error() is None  # collect errors in a separate tuple
                )

                c = dt.datetime.now(tz=pendulum.timezone("Asia/Oral"))
                data = list(d for d in data if d[13] is not None and d[13] < c)
                bulk_insert(
                    oracle_conn=connection,
                    data=data,
                    table_name=table_name,
                    target_cols=target_columns,
                )
                consumer.commit()
            else:
                logger.info(f"There are no more messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    dag_id="GOVTECH_EVENTS_CONSUMER",
    default_args=default_args,
    description="A DAG that reads govtech-related events from the 'GOVT_EVENTS' topic and writes them to DSSB DB",
    schedule="@hourly",
    start_date=pendulum.datetime(2024, 9, 27),
    catchup=False,
    max_active_runs=1,
    tags=["consumer", "kafka"],
):
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)
    kafka_config_id = "kafka_oper_prod__govtech_dud"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)

    table_name = "DSSB_DE.rb_govtech_event"
    kwargs = {
        "topics": ["GOVT_EVENTS"],
        "oracle_hook": oracle_hook,
        "consumer_config": consumer_config,
        "table_name": table_name,
        "target_columns": columns,
        "batch_size": 25_000,
        "threshold": 25_000,
        "poll_timeout": 5.0,
    }

    consume_and_write_task = PythonOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        python_callable=consume_and_write,
        op_kwargs=kwargs,
        on_failure_callback=[TelegramErrorNotification()],
    )
    consume_and_write_task
