import datetime as dt
import json
import logging
import typing

import oracledb
import pendulum
from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition

from source.telegram_notifications import TelegramErrorNotification


logger = logging.getLogger(__name__)

default_args = {
    "owner": "TleuserIz",
    "email": ["TleuserIz@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}

columns = (
    "EVENT_DATE",
    "EVENT_TIME",
    "SOURCE",
    "EVENT_NAME",
    "USER_ID",
    "CITY",
    "DEVICE_ID",
    "EMAIL",
    "EVENT_AGENT",
    "DATA_EVENT_NAME",
    "EVENT_TYPE",
    "ID",
    "LANGUAGE",
    "PAGE_TITLE",
    "PAGE_URL",
    "PHONE",
    "REFERRER",
    "SESSION_ID",
    "SIGNUP_TIME",
    "HB_USER_ID",
    "SEATS",
    "PRICE",
)


def transforms(message_dict: dict) -> typing.Tuple[typing.Any, ...]:
    source = message_dict.get("source")
    event_name = message_dict.get("event_name")
    user_id = message_dict.get("user_id")

    if isinstance(user_id, str):
        if user_id == "":
            user_id = None

    data = message_dict.get("data")

    city = None
    device_id = None
    email = None
    event_agent = None
    data_event_name = None
    event_time = None
    event_date = None
    event_type = None
    id_ = None
    language = None
    page_title = None
    page_url = None
    phone = None
    price = None
    referrer = None
    seats = None
    session_id = None
    signup_time = None
    hb_user_id = None

    if data:
        city = data.get("city")
        device_id = data.get("device_id")
        email = data.get("email")
        event_agent = data.get("event_agent")
        data_event_name = data.get("event_name")
        event_time = data.get("event_time")
        event_type = data.get("event_type")
        id_ = data.get("id")
        language = data.get("language")
        page_title = data.get("page_title")
        page_url = data.get("page_url")
        phone = data.get("phone")
        price = data.get("price")
        referrer = data.get("referrer")
        seats = data.get("seats")
        session_id = data.get("session_id")
        signup_time = data.get("signup_time")
        hb_user_id = data.get("hb_user_id")

    if event_time:
        event_time = dt.datetime.strptime(event_time, "%Y-%m-%dT%H:%M:%S.%fZ")
        event_date = event_time.date()
    if signup_time:
        signup_time = dt.datetime.strptime(signup_time, "%Y-%m-%dT%H:%M:%S.%fZ")

    if seats:
        seats = json.dumps(seats, ensure_ascii=False)  # Turn to nvarchar

    if event_type or isinstance(event_type, list):
        event_type = json.dumps(event_type, ensure_ascii=False)  # Turn to varchar

    return (
        event_date,
        event_time,
        source,
        event_name,
        user_id,
        city,
        device_id,
        email,
        event_agent,
        data_event_name,
        event_type,
        id_,
        language,
        page_title,
        page_url,
        phone,
        referrer,
        session_id,
        signup_time,
        hb_user_id,
        seats,
        price,
    )


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deserialize_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    target_cols: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(target_cols)) if target_cols else "",
        values=", ".join(f":{i}" for i in range(1, len(target_cols) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.setinputsizes(
            oracledb.DB_TYPE_DATE,
            oracledb.DB_TYPE_DATE,
            300,
            400,
            oracledb.DB_TYPE_NUMBER,
            100,
            150,
            150,
            512,
            250,
            1024,
            oracledb.DB_TYPE_NUMBER,
            100,
            300,
            2048,
            200,
            1536,
            500,
            oracledb.DB_TYPE_DATE,
            oracledb.DB_TYPE_NVARCHAR,
            1024,
            oracledb.DB_TYPE_NUMBER,
        )
        try:
            cursor.executemany(None, data, batcherrors=True)
        except Exception as e:
            print(e)
            print(data)
            for error in cursor.getbatcherrors():
                print(error.message)
                print(data[error.offset])
            raise e
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    topics: typing.List[str],
    oracle_hook: OracleHook,
    consumer_config: dict,
    table_name: str,
    target_columns: typing.Tuple[str, ...],
    batch_size: int,
    poll_timeout: float = 3.0,
    threshold: int = 0,
) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe(topics, on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages and len(consumed_messages) >= threshold:
                logger.info(f"Consumed {len(consumed_messages)} messages")
                data = list(
                    transforms(deserialize_message(m))
                    for m in consumed_messages
                    if m is not None  # and m.error() is None  # collect errors in a separate tuple
                )
                bulk_insert(
                    oracle_conn=connection,
                    data=data,
                    table_name=table_name,
                    target_cols=target_columns,
                )
                consumer.commit()
            else:
                logger.info(f"There are no more messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    dag_id="KINOKZ_EVENTS_CONSUMER",
    default_args=default_args,
    description="A DAG that reads kino.kz-related events from the 'KINO_EVENTS' topic and writes them to the DSSB DB",
    schedule="@hourly",
    start_date=pendulum.datetime(2024, 9, 27),
    catchup=False,
    max_active_runs=1,
    tags=["consumer", "kafka"],
):
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)
    kafka_config_id = "kafka_oper_prod__kinokz_consumer"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)

    table_name = "DSSB_DE.EVENTS_KINOKZ"
    kwargs = {
        "topics": ["KINO_EVENTS"],
        "oracle_hook": oracle_hook,
        "consumer_config": consumer_config,
        "table_name": table_name,
        "target_columns": columns,
        "batch_size": 25_000,
        "threshold": 25_000,
        "poll_timeout": 5.0,
    }

    consume_and_write_task = PythonOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        python_callable=consume_and_write,
        op_kwargs=kwargs,
        on_failure_callback=[TelegramErrorNotification()],
    )
    consume_and_write_task
