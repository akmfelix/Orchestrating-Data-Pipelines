import datetime
from datetime import timedelta

import oracledb
import pandas as pd
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.postgres.hooks.postgres import PostgresHook

default_args = {
    "owner": "AkejanA",
    "email": ["AkejanA@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": False,
}

#postgres_table = "rb_rep_workflow_run"

def load_oracle_logs(oracle_hook,pg_hook):
    sql_select = """
SELECT 	WORKFLOW_ID,
		WORKFLOW_NAME,
		START_TIME,
		END_TIME,
		RUN_ERR_CODE,
		RUN_ERR_MSG
FROM RB_REP.OPB_WFLOW_RUN
WHERE START_TIME >= TRUNC(SYSDATE)-7 
ORDER BY WORKFLOW_NAME,START_TIME 
"""
    ora_conn = oracle_hook.get_conn()
    ora_cursor = ora_conn.cursor()
    ora_cursor.execute(sql_select)
    data = ora_cursor.fetchall()
    new_data = []
    postgres_conn = pg_hook.get_conn()
    postgres_cur = postgres_conn.cursor()

    postgres_cur.execute("truncate table rb_rep_workflow_run")
    values = ','.join(postgres_cur.mogrify("(%s, %s, %s, %s, %s, %s)",row).decode("utf-8") for row in data)
    insert_query = "insert into rb_rep_workflow_run (WORKFLOW_ID, WORKFLOW_NAME, START_TIME, END_TIME, RUN_ERR_CODE, RUN_ERR_MSG) VALUES"
    postgres_cur.execute(insert_query + values)
    postgres_cur.execute("commit")

    postgres_cur.close()
    postgres_conn.close()


with DAG(
        dag_id="RB_REP_MONITORING_GRAFANA",
        default_args=default_args,
        start_date=datetime.datetime(2024, 10, 18),
        schedule= timedelta(minutes=15),
        catchup=False,
) as dag:

    oracle_hook = OracleHook(oracle_conn_id="db_oracle_ipc__edw_ipc", thick_mode=True)
    postgres_hook = PostgresHook("monitoring")

    kwargs = {"oracle_hook": oracle_hook,
              "pg_hook":postgres_hook
              }


    logs_load = PythonOperator(
        task_id="rb_rep_log_table",
        python_callable=load_oracle_logs,
        op_kwargs=kwargs,
        provide_context=True,
        dag=dag,
    )
    
    logs_load
