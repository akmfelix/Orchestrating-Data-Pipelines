import json
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator, PythonOperator

# from airflow.providers.vertica.operators.vertica import VerticaOperator
from airflow.providers.vertica.hooks.vertica import VerticaHook
from airflow.utils.email import send_email
from jinja2 import Template


VERTICA_CONN = "Vertica_Prod"
home = "/opt/airflow/"
dags = home + "dags/"
sql = dags + "sql/mdm_hist_creator/"

default_args = {
    "owner": "NikitaMi",
    "retries": 5,
    "retry_delay": timedelta(minutes=60),
    # 'catchup': False
}


def set_date(**kwargs):  # функция устанавливает максимальную дату из логов по умолчанию
    vertica_hook = VerticaHook("Vertica_Prod")
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(
        "\
        SELECT MAX(loaded_date)+1 as loaded_date \
        FROM mdm_tech.mdmhist_log \
        WHERE state='OK'"
    )

    # ЕСЛИ ХОТИТЕ ЗАГРУЗИТЬ ДАННЫЕ ЗА ОТСТАВШИЙ ДЕНЬ ЗАКОММЕНТИТЕ СКРИПТ ВЫШЕ И РАСКОММЕНТИТЕ НИЖЕ И ИЗМЕНИТЕ ДАТУ !!!!
    # vertica_cursor.execute('SELECT CURRENT_DATE-1')

    oper = vertica_cursor.fetchone()
    # print(oper, 'oper')
    global days
    days = (datetime.now().date() - oper[0]).days
    print("set date", days)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="max_date", value=days)


def email_text(context):
    task_instance = context["task_instance"]

    subject = f"Airflow Task {task_instance.task_id}"
    body = f"The task {task_instance.task_id} finished with status {task_instance.current_state()}. Log URL: {task_instance.log_url}\n\n"

    to_email = ["NyrlanTo@halykbank.kz", "NikitaMi@halykbank.kz"]

    send_email(to=to_email, subject=subject, html_content=body)


def say_hello():
    return "salem alem"


procedures = [
    {"procedure_name": "mdm.p_load_data_hist_party_instance_seq_proc", "upd_column": "contact_masters_fl"},
    {"procedure_name": "mdm.p_load_data_hist_party_masters_seq_proc", "upd_column": "document_masters_fl"},
    {"procedure_name": "mdm.p_load_data_hist_party2party_masters_seq_proc", "upd_column": "party2party_masters_fl"},
    {"procedure_name": "mdm.p_load_data_hist_document_masters_seq_proc", "upd_column": "party_instance_fl"},
    {"procedure_name": "mdm.p_load_data_hist_contact_masters_seq_proc", "upd_column": "party_masters_fl"},
]


def decide_branch(**kwargs):
    is_ready = json.loads(kwargs["ti"].xcom_pull(key="load_parameters", task_ids=["check_mdm_log"])[0])["is_ready"]

    if is_ready == 1:
        return "hist_log_start"
    else:
        return "dummy"


def hist_log_start(**kwargs):
    log_detail = json.loads(kwargs["ti"].xcom_pull(key="load_parameters", task_ids=["check_mdm_log"])[0])

    hist_log_sql = open(sql + "hist_log_insert.sql", "r").read()
    templated_sql = Template(hist_log_sql).render(load_date=log_detail["load_date"], load_id=log_detail["load_id"])

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(templated_sql)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def hist_start(**kwargs):
    log_detail = json.loads(kwargs["ti"].xcom_pull(key="load_parameters", task_ids=["check_mdm_log"])[0])

    hist_procedure_call_sql = open(sql + "hist_procedure_call.sql", "r").read()
    hist_log_sql = open(sql + "hist_log_update.sql", "r").read()

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    success_cnt = 0

    for proc in procedures:
        templated_call = Template(hist_procedure_call_sql).render(
            load_date=log_detail["load_date"], load_id=log_detail["load_id"], procedure_name=proc["procedure_name"]
        )

        try:
            vertica_cursor.execute(templated_call)
            success_cnt += 1
            success_fl = 1
        except Exception as e:
            print("Exception:", e)
            success_fl = -1

        templated_log = Template(hist_log_sql).render(
            load_date=log_detail["load_date"],
            load_id=log_detail["load_id"],
            upd_column=proc["upd_column"],
            success_fl=success_fl,
        )
        vertica_cursor.execute(templated_log)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="successfully_worked", value=success_cnt)
    return "successfully worked :" + str(success_cnt)


def hist_log_end(**kwargs):
    log_detail = json.loads(kwargs["ti"].xcom_pull(key="load_parameters", task_ids=["check_mdm_log"])[0])
    for_proc_check = kwargs["ti"].xcom_pull(key="successfully_worked", task_ids=["hist_start"])[0]

    hist_log_sql = open(sql + "hist_log_end.sql", "r").read()

    load_state = "NOT OK"
    if for_proc_check == len(procedures):
        load_state = "OK"

    templated_sql = Template(hist_log_sql).render(
        load_date=log_detail["load_date"], load_id=log_detail["load_id"], load_state=load_state
    )

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(templated_sql)

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()


def check_mdm_log(**kwargs):
    # load_date = kwargs["params"]["load_date"]
    # print(load_date)
    days = kwargs["ti"].xcom_pull(key="max_date", task_ids="set_date")
    load_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

    load_date_type = datetime.strptime(load_date, "%Y-%m-%d")

    load_date_plus_1 = (load_date_type + timedelta(days=1)).strftime("%Y-%m-%d")
    print(load_date_plus_1)

    mdm_log_sql = open(sql + "check_raw.sql", "r").read()
    print(mdm_log_sql)
    templated_sql = Template(mdm_log_sql).render(load_date=load_date_plus_1)
    print(templated_sql)

    vertica_hook = VerticaHook(VERTICA_CONN)
    vertica_conn = vertica_hook.get_conn()
    vertica_cursor = vertica_conn.cursor()

    vertica_cursor.execute(templated_sql)
    ready_load_id = vertica_cursor.fetchall()[0]
    res = {"load_id": ready_load_id[0], "is_ready": ready_load_id[1], "load_date": load_date}

    vertica_conn.commit()
    vertica_cursor.close()
    vertica_conn.close()

    kwargs["ti"].xcom_push(key="load_parameters", value=json.dumps(res))


with DAG(
    dag_id="PROFILE_MDM_HIST",
    description="Ежедневная загрузка профиля клиента. Запуск расчета истории золотой записи.",
    tags=["PROFILE"],
    start_date=datetime(2024, 4, 26),
    schedule_interval="30 8 * * *",
    catchup=False,
    owner_links={"doc": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=727749873"},
    # params={"load_date": str(datetime.date.today())},
    default_args=default_args,
) as dag:
    set_date = PythonOperator(
        task_id="set_date",
        python_callable=set_date,
        dag=dag,
    )

    check_mdm_log = PythonOperator(
        task_id="check_mdm_log",
        provide_context=True,
        python_callable=check_mdm_log,
        email=["AiysulySH@halykbank.kz", "NikitaMi@halykbank.kz"],
        email_on_failure=True,
        email_on_retry=True,
        on_failure_callback=email_text,
        dag=dag,
    )

    hist_log_start = PythonOperator(
        task_id="hist_log_start",
        provide_context=True,
        python_callable=hist_log_start,
        dag=dag,
    )

    hist_start = PythonOperator(
        task_id="hist_start",
        provide_context=True,
        python_callable=hist_start,
        dag=dag,
    )

    hist_log_end = PythonOperator(
        task_id="hist_log_end",
        provide_context=True,
        python_callable=hist_log_end,
        dag=dag,
    )

set_date >> check_mdm_log >> hist_log_start >> hist_start >> hist_log_end
