import datetime
import json
import logging
from datetime import timedelta

from airflow import DAG
from airflow.providers.apache.kafka.operators.consume import ConsumeFromTopicOperator
from airflow.providers.oracle.hooks.oracle import OracleHook


logger = logging.getLogger(__name__)

default_args = {
    "owner": "AkejanA",
    "email": ["AkejanA@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": True,
}


columns = (
    "DEP_ID",
    "ID",
    "DOP",
    "DEA_CODE",
    "CR_EXP_PD_DAY",
    "CR_EXP_IN_DAY",
    "CR_EXP_IN",
    "CR_EXP_PD",
    "S$KAFKA_TIMESTAMP",
)


def deserialize_message_list(messages):
    data = []
    try:
        for m in messages:
            s = m.value().decode("utf-8").replace("М", "M")  # Replace cyrillic "М" with ascii "M"
            # Fix malformed JSON string by removing comma before the last closing bracket
            if s[-2] == ",":
                s = f"{s[:-2]}}}"
            data.append(json.loads(s))
    except Exception as e:
        logger.info(e)
        logger.info(m.value())
        raise e
    # data = list(json.loads(m.value().decode("utf-8").replace("М", "M")) for m in messages)

    message_timestamp = list(m.timestamp() for m in messages)

    data = [{k: v for k, v in d.items() if k in columns} for d in data]
    value_list = []

    for index, row in enumerate(data):
        row["KAFKA_TIMESTAMP"] = datetime.datetime.fromtimestamp(message_timestamp[index][1] / 1e3) + timedelta(
            hours=5
        )
        for key in row:
            if key == "DEP_ID":
                row[key] = str(row[key])
            elif key == "ID":
                row[key] = int(row[key])
            elif key == "DOP":
                if row[key] == "":
                    row[key] = ""
                else:
                    row[key] = datetime.datetime.strptime(
                        str(row[key][6:8] + "-" + row[key][3:5] + "-" + row[key][0:2]),
                        "%y-%m-%d",
                    )
            elif key == "DEA_CODE":
                row[key] = str(row[key])
            elif key == "CR_EXP_PD_DAY":
                if row[key] == "":
                    row[key] = ""
                else:
                    row[key] = datetime.datetime.strptime(
                        str(row[key][6:8] + "-" + row[key][3:5] + "-" + row[key][0:2]),
                        "%y-%m-%d",
                    )
            elif key == "CR_EXP_IN_DAY":
                if row[key] == "":
                    row[key] = ""
                else:
                    row[key] = datetime.datetime.strptime(
                        str(row[key][6:8] + "-" + row[key][3:5] + "-" + row[key][0:2]),
                        "%y-%m-%d",
                    )
            elif key == "CR_EXP_IN":
                row[key] = float(row[key])
            elif key == "CR_EXP_PD":
                row[key] = float(row[key])
        values = tuple(row.values())
        value_list.append(values)
    return value_list


def insert_rows_to_oracle_db(messages, oracle_hook) -> None:
    data_insert = list(deserialize_message_list(messages))
    oracle_hook.insert_rows("DSSB_DE.F$OCRM_CREDIT_OVERDUE", data_insert, columns, commit_every=10_000)
    oracle_conn = oracle_hook.get_conn()
    oracle_cur = oracle_conn.cursor()
    oracle_cur.execute("""
    SELECT case when ((extract(year from MAX(TRUNC(S$KAFKA_TIMESTAMP))) - extract(year from MIN(TRUNC(S$KAFKA_TIMESTAMP)))) * 12 + extract(month from MAX(TRUNC(S$KAFKA_TIMESTAMP))))  - extract(month from MIN(TRUNC(S$KAFKA_TIMESTAMP))) >= 6 then 1 
       else 0
       end flg
 from DSSB_DE.F$OCRM_CREDIT_OVERDUE
    """)
    flag = oracle_cur.fetchone()[0]
    if flag == 1:
        oracle_cur.execute('''SELECT MAX(TRUNC(S$KAFKA_TIMESTAMP,'mm')) FROM DSSB_DE.F$OCRM_CREDIT_OVERDUE''')
        MAX_DATE = oracle_cur.fetchone()[0].date()
        oracle_cur.execute(f'''DELETE FROM DSSB_DE.F$OCRM_CREDIT_OVERDUE WHERE S$KAFKA_TIMESTAMP < add_months(date'{MAX_DATE}',-5))''')
        oracle_conn.commit()
        oracle_cur.close()
        oracle_conn.close()
    else: 
        None

with DAG(
    dag_id="OCRM_CREDIT_OVERDUE_CONSUMER",
    default_args=default_args,
    start_date=datetime.datetime(2024, 10, 4, 10, 45),
    schedule=timedelta(minutes=30),
    catchup=False,
    tags=["consumer", "kafka"],
) as dag:
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE")

    first_task = ConsumeFromTopicOperator(
        task_id="ingest_from_kafka_and_write_to_db",
        kafka_config_id="kafka_oper_prod__ocrm_credit_overdue",
        topics=["OCRM_CREDIT_OVERDUE"],
        apply_function_batch=insert_rows_to_oracle_db,
        apply_function_kwargs={"oracle_hook": oracle_hook},
        poll_timeout=8.0,
        max_messages=10_000,
        max_batch_size=10_000,
        commit_cadence="end_of_batch",
    )

first_task
