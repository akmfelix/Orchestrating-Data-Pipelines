from datetime import datetime

import airflow
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator


default_args = {
    "owner": "NikitaMi",
    "email": ["NikitaMi@halykbank.kz", "AlibekDz@halykbank.kz"],
    "email_on_failure": True,
    "start_date": datetime(2024, 11, 2),  # поменять когда будет готовы перейти на триггер
}

with DAG(
    dag_id="EDW_LOADER_CMD_CCE_ALL",
    tags=["CMD_CCE", "EDW_LOADER", "DDS", "RISKDM"],
    default_args=default_args,
    schedule_interval="20 19 * * *",
    description="Trigger JSON, XML parser DAGs",
    catchup=False,
) as dag:
    start_task = BashOperator(
        task_id="start_task",
        bash_command="echo 'Start task RISK_CMD_CCE'",
    )
    trigger_JSON = TriggerDagRunOperator(
        task_id="trigger_JSON",
        trigger_dag_id="RISK_CMD_CCE_JSON",
        wait_for_completion=True,
    )
    trigger_XML = TriggerDagRunOperator(
        task_id="trigger_XML",
        trigger_dag_id="RISK_CMD_CCE_XML",
        wait_for_completion=True,
    )
    end_task = BashOperator(
        task_id="end_task",
        bash_command="echo 'End of task RISK_CMD_CCE'",
    )

start_task >> trigger_JSON >> trigger_XML >> end_task
