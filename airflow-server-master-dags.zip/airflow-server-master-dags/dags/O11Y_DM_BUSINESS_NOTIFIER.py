import os
import time
from datetime import datetime, timedelta

import pandas as pd
from airflow import DAG
from airflow.operators.email import EmailOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"

default_args = {"owner": "NikitaMi", "email_on_failure": True, "start_date": datetime(2023, 8, 2)}

SQL_QUERY_1_path = sql + "DAY.sql"
SQL_QUERY_1 = open(SQL_QUERY_1_path, "r").read()

time_str = time.strftime("%Y-%m-%d_%H")

output_path = os.path.join(os.path.expanduser(temp_dir), time_str + ".xlsx")


def remove_xls():
    os.remove(output_path)


def export_to_excel(sheet_name, sql_query, **kwargs):
    oracle_hook = OracleHook(oracle_conn_id="EDW_ETL_CDO")
    df = oracle_hook.get_pandas_df(sql_query)

    if os.path.exists(output_path):
        with pd.ExcelWriter(output_path, mode="a", engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            workbook = writer.book
            worksheet = writer.sheets[sheet_name]
            for column_cells in worksheet.columns:
                max_length = max(len(str(cell.value)) for cell in column_cells)
                column_letter = get_column_letter(column_cells[0].column)
                worksheet.column_dimensions[column_letter].width = max_length + 2

    else:
        df.to_excel(output_path, sheet_name=sheet_name, index=False)
        workbook = load_workbook(filename=output_path)
        worksheet = workbook[sheet_name]
        for column_cells in worksheet.columns:
            max_length = max(len(str(cell.value)) for cell in column_cells)
            column_letter = get_column_letter(column_cells[0].column)
            worksheet.column_dimensions[column_letter].width = max_length + 2

        workbook.save(output_path)


# According to currenct time function decides which task to execute
def choose_branch():
    now = datetime.utcnow()
    if now.hour == 6:
        return "Email_send1"
    elif now.hour == 3:
        return "Email_send2"


# DAG runs at 9am, 12pm
with DAG(
    tags=["DAILY", "EMAIL", "O11Y", "DM"],
    start_date=datetime(2023, 8, 2),
    catchup=False,
    dag_id="O11Y_DM_BUSINESS_NOTIFIER",
    description="Рассылка результата работы регламента DM слоя бизнесам",
    schedule_interval="0 9,12 * * *",
    default_args=default_args,
    owner_links={"NikitaMi": "https://confluence.halykbank.kz/pages/viewpage.action?pageId=522355042"},
) as dag:
    day_1 = PythonOperator(
        task_id="day_1",
        python_callable=export_to_excel,
        op_args=["Day", SQL_QUERY_1],
        provide_context=True,
        dag=dag,
    )

    branching = BranchPythonOperator(task_id="branching", python_callable=choose_branch)

    Email_send1 = EmailOperator(
        task_id="Email_send1",
        to=["NIKITAMI@HALYKBANK.KZ"],
        # cc=["NIKITAMI@HALYKBANK.KZ"],
        bcc=[
            "ALIYAIZ@HALYKBANK.KZ",
            "AlibekDz@halykbank.kz",
            "NYRLANTO@HALYKBANK.KZ",
            "AlinaMa@halykbank.kz",
            "BauyrzhanIs@halykbank.kz",
            "GALYMZHANK@halykbank.kz",
            "ZHANARKOK@halykbank.kz",
            "ALMASHB@halykbank.kz",
            "ZIYADAK@halykbank.kz",
            "AselTu@halykbank.kz",
            "DAURENZH@halykbank.kz",
            "DmitriiSp@halykbank.kz",
            "DaniyarAi3@halykbank.kz",
            "DamirKa@halykbank.kz",
            "AqmaralQi@halykbank.kz",
        ],
        subject="Ежедневный отчет готовности DM слоя",
        html_content="Добрый день, коллеги!<br><br>Во вложении информация о состоянии данных DM слоя.<br><br>С уважением,<br>Управление интеграции данных",
        files=[output_path],
        dag=dag,
    )

    Email_send2 = EmailOperator(
        task_id="Email_send2",
        to=["NIKITAMI@HALYKBANK.KZ"],
        # cc=["NIKITAMI@HALYKBANK.KZ"],
        bcc=[
            "ALIYAIZ@HALYKBANK.KZ",
            "AlibekDz@halykbank.kz",
            "DaniyarAi3@halykbank.kz",
            "DamirKa@halykbank.kz",
            "AqmaralQi@halykbank.kz",
        ],
        subject="Ежедневный отчет готовности DM слоя",
        html_content="Добрый день, коллеги!<br><br>Во вложении информация о состоянии данных DM слоя.<br><br>С уважением,<br>Управление интеграции данных",
        files=[output_path],
        dag=dag,
    )

    remove_xls = PythonOperator(task_id="remove_xls", python_callable=remove_xls, dag=dag, trigger_rule="all_done")

day_1 >> branching >> [Email_send1, Email_send2] >> remove_xls
