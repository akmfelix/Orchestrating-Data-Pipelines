import time
from datetime import datetime

import pandas as pd
from airflow import DAG
from airflow.operators.email import EmailOperator
from airflow.operators.python import BranchPythonOperator, PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook


home = "/opt/airflow/"
temp_dir = home + "temp/"
dags = home + "dags/"
sql = dags + "sql/"
apps = dags + "apps/"

default_args = {"owner": "AselNu", "email": ["AselNu3@halykbank.kz"]}

timestr = time.strftime("%Y-%m-%d")

fname = temp_dir + timestr + ".csv"
xls_fname = temp_dir + timestr + ".xlsx"

sql = """select * from dssb_se.rb2_tm_campaigns_once """

ORACLE_CONN_ID = "dssb_se"


def get_data_from_oracle():
    oracle_hook = OracleHook(oracle_conn_id=ORACLE_CONN_ID)
    pd.DataFrame(
        oracle_hook.get_records(sql=sql),
        columns=["P_SID", "IIN", "CAMPAIGNCODE", "SHORT_DESC", "UPLOAD_DATE", "PHONE", "P_SID_OCRM"],
    ).to_csv(fname, index=False)
    return fname


def validate_csv():
    df = pd.read_csv(fname, converters={"iin": str})
    if not df.empty:
        sheetname = timestr
        writer = pd.ExcelWriter(xls_fname, engine="xlsxwriter")
        df.to_excel(writer, sheet_name=sheetname, index=False)  # send df to writer
        worksheet = writer.sheets[sheetname]  # pull worksheet object
        for idx, col in enumerate(df):  # loop through all columns
            series = df[col]
            max_len = (
                max(
                    (
                        series.astype(str).map(len).max(),  # len of largest item
                        len(str(series.name)),  # len of column name/header
                    )
                )
                + 1
            )  # adding a little extra space
            worksheet.set_column(idx, idx, max_len)  # set column width
        # writer.save()
        writer.close()
        # df.to_excel(xls_fname, index=False)
        return "branch_ok"
    else:
        return "branch_not_ok"


with DAG(
    tags=["AselNu3@halykbank.kz", "daily", "email", "dssb_se", "oracle", "asselnuraliyeva", "rb"],
    dag_id="RB_REPORT_30M",
    description="Отчет кампании по клиентам, у которых одобренная сумма больше или равна запрошенной за последние полчаса.",
    start_date=datetime(2023, 4, 6),
    schedule_interval="*/30 * * * *",
    catchup=False,
    default_args=default_args,
) as dag:
    ora_extract = PythonOperator(task_id="ora_extract_task", python_callable=get_data_from_oracle)
    branch_task = BranchPythonOperator(
        task_id="validate_csv",
        python_callable=validate_csv,
        dag=dag,
    )
    branch_ok = EmailOperator(
        task_id="branch_ok",
        to=["AselNu3@halykbank.kz", "AdiletAl@halykbank.kz", "KuanysKu@halykbank.kz", "ZanfarBe@halykbank.kz"],
        # to=["SanzharsyltanBe@halykbank.kz"],
        subject="Отчет по 60 минут",
        html_content="Отчет кампании по клиентам, у которых одобренная сумма больше или равна запрошенной за последний час. \n С уважением, "
        "Нуралиева Асель",
        files=[xls_fname],
    )
    branch_not_ok = EmailOperator(
        task_id="branch_not_ok",
        to=["SanzharsyltanBe@halykbank.kz", "AselNu3@halykbank.kz"],
        subject="ERROR in DAG DEV_oracle_spss_assel_daily",
        html_content="Dataset is empty",
    )

ora_extract >> branch_task
branch_task >> branch_ok
branch_task >> branch_not_ok
