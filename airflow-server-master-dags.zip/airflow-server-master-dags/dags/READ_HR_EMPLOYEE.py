from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator, PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook


default_args = {
    "owner": "AiysulySH",
    "email": ["AiysulySH@halykbank.kz"],
    "email_on_failure": True,
    "start_date": datetime(2024, 6, 4),
    "retries": 0,
    "retry_delay": timedelta(minutes=10),
    # 'catchup': False
}


def add_partition(**kwargs):  # функция читает флаг IS_FIRED таблицы HR

    oracle_hook = OracleHook("EDW_ETL_CDO")
    oracle_conn = oracle_hook.get_conn()
    oracle_cursor = oracle_conn.cursor()

    max_date = oracle_cursor.execute(
        "SELECT DATE_CHANGE + 2 FROM dm.W4_CARD_ATTR_DM WHERE rownum = 1 ORDER BY DATE_CHANGE DESC"
    )
    print(max_date)
    oracle_cursor.execute("call dm.truncate_partition_P('W4_CARD_ATTR_DM', to_char(max_date, 'yyyymmdd'))")

    oracle_cursor.fetchall()

    # print(max_date)
    # global flag
    oracle_cursor.close()
    oracle_conn.close()

    # kwargs['ti'].xcom_push(key="flag_", value=flag_)


with DAG(
    dag_id="READ_HR_EMPLOYEE",
    tags=["ARMAGEDDON"],
    default_args=default_args,
    schedule_interval="@once",
    description="Добавление партиций в витрину W4_CARD_ATTR_DM",
    catchup=False,
) as dag:
    add_partition = PythonOperator(
        task_id="add_partition",
        python_callable=add_partition,
        dag=dag,
    )

add_partition
