import datetime as dt
import json
import logging
import typing
from dataclasses import dataclass

from airflow import DAG
from airflow.models.connection import Connection
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from airflow.providers.oracle.operators.oracle import OracleStoredProcedureOperator
from airflow.utils.dates import days_ago
from confluent_kafka import Consumer, KafkaException, Message, TopicPartition


logger = logging.getLogger(__name__)

default_args = {
    "owner": "AdiletAl",
    "depend_on_past": False,
    "start_date": days_ago(2),
    "retries": 1,
    "retry_delay": dt.timedelta(minutes=5),
}


@dataclass(frozen=True)
class ConsumedTopic:
    topic: str
    target_table: str
    target_columns: typing.Tuple[str, ...]
    transforms: typing.Callable[[dict], typing.Tuple]


# def fetch_data_from_kafka(topics: typing.List[str]):
#     kafka_config_id = "kafka_oper_test__payservicedata_consumer"
#     consumer_config = json.loads(
#         Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra
#     )
#     rows = list()
#     kafkaConsumer = KafkaConsumer(topics, consumer_config)
#     messages = kafkaConsumer.fetchPoll(timeout=1.0)
#     # logger.info("messages: ", messages)
#     for msg in messages:
#
#         if "HBHK_PGW_PAYSERVICESDATA" in topics:
#             if msg["bonus"]:
#                 msg["bonus"] = 1
#             else:
#                 msg["bonus"] = 0
#         rows.append(tuple(msg.values()))
#     logger.info(rows[:10])
#     return rows


# def load_to_data_base(table, columns, rows):
#     oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE")
#     oracle_hook.insert_rows(f"DSSB_DE.{table}", rows, target_fields=columns)
#     value = oracle_hook.get_first(
#         sql="select count(1) as cn from DSSB_DE.RY_HBHK_PGW_PAYSERVICESDATA"
#     )
#     return value


def truncate_target_tables(table_name: str) -> None: ...


def assignment_callback(consumer: Consumer, partitions: typing.List[TopicPartition]) -> None:
    logger.info(f"Consumer successfully assigned to topic(s): {[partitions[0].topic]}")

    partition_list = "; ".join(
        f"Partition #{partition.partition} @ offset {consumer.get_watermark_offsets(partition)[1]}"
        for partition in partitions
    )
    logger.info(f"Consumer successfully assigned to the following partitions(s): {partition_list}")


def deser_message(message: Message) -> dict:
    if message.error():
        raise message.error()
    else:
        return json.loads(message.value())


def transform_hbhk_pgw_payservicesdata_message(message: dict) -> typing.Tuple:
    if message.get("bonus") is not None:
        message["bonus"] = int(message["bonus"])  # Transform bool to an int value
    return tuple(message.values())


def bulk_insert(
    oracle_conn,
    data: typing.List[tuple],
    table_name: str,
    columns: typing.Tuple[str, ...],
) -> None:
    statement = "insert into {table_name} {columns} values ({values})".format(
        table_name=table_name,
        columns="({})".format(", ".join(columns)) if columns else "",
        values=", ".join(f":{i}" for i in range(1, len(columns) + 1)),
    )
    with oracle_conn.cursor() as cursor:
        cursor.prepare(statement)
        cursor.executemany(None, data)
        logger.info(f"Inserted {len(data)} records into {table_name}")
        oracle_conn.commit()


def consume_and_write(
    consumed_topic: ConsumedTopic,
    oracle_hook: OracleHook,
    consumer_config: dict,
    batch_size: int,
    poll_timeout: float = 3.0,
) -> None:
    consumer: Consumer = Consumer(consumer_config)
    consumer.subscribe([consumed_topic.topic], on_assign=assignment_callback)
    connection = oracle_hook.get_conn()

    try:
        while True:
            consumed_messages = consumer.consume(num_messages=batch_size, timeout=poll_timeout)
            if consumed_messages:
                data = list(consumed_topic.transforms(deser_message(m)) for m in consumed_messages if m is not None)
                logger.info(f"Consumed {len(data)} messages")
                bulk_insert(
                    connection,
                    data,
                    consumed_topic.target_table,
                    consumed_topic.target_columns,
                )
                consumer.commit()
            else:
                logger.info(f"There are no more messages left. Shutting down")
                break
    finally:
        consumer.close()
        connection.close()


with DAG(
    "RB_HBHK_PGW_PAYSERVICESDATA",
    default_args=default_args,
    description="Blackbox process, as of yet.",
    schedule_interval=dt.timedelta(days=1),
    tags=["consumer", "kafka"],
):
    schema = "DSSB_DE"

    consumed_topics = (
        ConsumedTopic(
            topic="HBHK_PGW_PAYSERVICESDATA",
            target_table=f"{schema}.RY_HBHK_PGW_PAYSERVICESDATA",
            target_columns=(
                "SERVICE_ID",
                "SERVICE_NAME",
                "SERVICE_DESCRIPTION",
                "SERVICE_STATE",
                "CREATION_DATE",
                "BIN",
                "BONUS",
                "PROVIDER_NAME",
                "PROVIDER_DESCRIPTION",
                "CATEGORY_ID",
                "CATEGORIES",
                "REGION_ID",
                "REGIONS",
            ),
            transforms=transform_hbhk_pgw_payservicesdata_message,
        ),
        ConsumedTopic(
            topic="HBHK_PGW_PAYSERVICESDATA_CAT",
            target_table=f"{schema}.RY_HBHK_PGW_PAYSERVICESDATA_CAT",
            target_columns=("ID", "NAME", "PARENT_ID"),
            transforms=lambda x: tuple(x.values()),
        ),
        ConsumedTopic(
            topic="HBHK_PGW_PAYSERVICESDATA_REG",
            target_table=f"{schema}.RY_HBHK_PGW_PAYSERVICESDATA_REG",
            target_columns=("ID", "NAME"),
            transforms=lambda x: tuple(x.values()),
        ),
    )

    kafka_config_id = "kafka_oper_test__payservicedata_consumer"
    consumer_config = json.loads(Connection.get_connection_from_secrets(conn_id=kafka_config_id).extra)
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_DE", thick_mode=True)

    kwargs = {
        "poll_timeout": 5.0,
        "batch_size": 25_000,
        "consumer_config": consumer_config,
        "oracle_hook": oracle_hook,
    }

    truncate_or_create_tables = OracleStoredProcedureOperator(
        task_id="create_temp_tables_for_services",
        oracle_conn_id="db_oracle_dssb__dssb_de",
        procedure="CREATE_TEMP_TABLES_FOR_SERVICES",
        parameters=[],
    )

    update_or_insert_data = OracleStoredProcedureOperator(
        task_id="update_or_insert_data_for_services",
        oracle_conn_id="DSSB_DE",
        procedure="UPDATE_OR_INSERT_HBHK_PGW_PAYSERVICESDATA",
        parameters=[],
    )

    for consumed_topic in consumed_topics:
        consume_and_read_task = PythonOperator(
            task_id=f"ingest_from_kafka_and_write_to_db_{str.lower(consumed_topic.topic)}",
            python_callable=consume_and_write,
            op_kwargs={**kwargs, **{"consumed_topic": consumed_topic}},
        )
        truncate_or_create_tables >> consume_and_read_task >> update_or_insert_data
