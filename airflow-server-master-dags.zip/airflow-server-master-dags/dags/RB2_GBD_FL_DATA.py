import datetime
import xml.etree.ElementTree as et
from datetime import timedelta

import oracledb
import pandas as pd
from airflow import DAG
from airflow.decorators import dag
from airflow.operators.python_operator import PythonOperator
from airflow.providers.oracle.hooks.oracle import OracleHook
from sqlalchemy import create_engine


def xmlImport(root, xmlPath, default=None):
    found_element = root.find(xmlPath)
    if found_element is not None and found_element.text is not None:
        return found_element.text
    return default


def clob_to_str(clob):
    if clob is not None:
        return "".join(clob.read())
    return ""


### Функция чтения XML и записи в лист
def parse_real_estate_305_data(xml):
    rn = et.fromstring(xml)
    rows = []
    for RegisteredRightsEvidencePerson in rn.findall(".//messageData"):
        StatementFeedPlace305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/StatementFeedPlace",
        )
        StatementNumber305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/StatementNumber",
        )
        StatementDate305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/StatementDate",
        )
        LastName305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/Declarant/LastName",
        )
        FirstName305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/Declarant/FirstName",
        )
        MiddleName305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/Declarant/MiddleName",
        )
        BornDt305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/Declarant/BornDt",
        )
        DeclarantIIN305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/DeclarantIIN",
        )
        DeclarantBirthDate305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/DeclarantBirthDate",
        )
        IdentityDocNumber305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/IdentityDoc/Number",
        )  # !
        IdentityDocIssueDate305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/IdentityDoc/IssueDate",
        )  # ! имя переменной
        EmptyLineForRights305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/EmptyLineForRights",
        )
        EmptyLineForBurdens305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/EmptyLineForBurdens",
        )
        EmptyLineForUPSes305 = xmlImport(
            RegisteredRightsEvidencePerson,
            ".//businessData/RegisteredRightsEvidencePerson/EmptyLineForUPSes",
        )
        for GbdrnObjectInfoItem in RegisteredRightsEvidencePerson.findall(".//GbdrnObjectInfoItem"):
            ObjectTypeId305 = xmlImport(GbdrnObjectInfoItem, "ObjectTypeId")
            KadastrNumber305 = xmlImport(GbdrnObjectInfoItem, "KadastrNumber")
            ObjectLocation305 = xmlImport(GbdrnObjectInfoItem, "ObjectLocation")
            ObjectEndUse305 = xmlImport(GbdrnObjectInfoItem, "ObjectEndUse")
            QuantityPart305 = xmlImport(GbdrnObjectInfoItem, "QuantityPart")
            Storeys305 = xmlImport(GbdrnObjectInfoItem, "Storeys")
            SquareTotal305 = xmlImport(GbdrnObjectInfoItem, "SquareTotal")
            BasicArea305 = xmlImport(GbdrnObjectInfoItem, "BasicArea")
            DwellingArea305 = xmlImport(GbdrnObjectInfoItem, "DwellingArea")
            Divisibility305 = xmlImport(GbdrnObjectInfoItem, "Divisibility")
            SpecialNotes305 = xmlImport(GbdrnObjectInfoItem, "SpecialNotes")
            ClaimsAndDealsDocList305 = xmlImport(GbdrnObjectInfoItem, ".//ClaimsAndDeals/DocList")
            for ImmovablesRight in GbdrnObjectInfoItem.findall(".//ImmovablesRight"):
                RightType305 = xmlImport(ImmovablesRight, "RightType")
                RightSubstance305 = xmlImport(ImmovablesRight, "RightSubstance")
                RightOwner305 = xmlImport(ImmovablesRight, "RightOwner")
                OwnershipType305 = xmlImport(ImmovablesRight, "OwnershipType")
                RightFoundationDocTip305 = xmlImport(ImmovablesRight, ".//RightFoundation/DocList/DocTip")
                RightFoundationDocNo305 = xmlImport(ImmovablesRight, ".//RightFoundation/DocList/DocNo")
                RightFoundationDocDt305 = xmlImport(ImmovablesRight, ".//RightFoundation/DocList/DocDt")
                RegistrationDate305 = xmlImport(ImmovablesRight, "RegistrationDate")
                rows.append(
                    {
                        "StatementFeedPlace305": StatementFeedPlace305,
                        "StatementNumber305": StatementNumber305,
                        "StatementDate305": StatementDate305,
                        "LastName305": LastName305,
                        "FirstName305": FirstName305,
                        "MiddleName305": MiddleName305,
                        "BornDt305": BornDt305,
                        "DeclarantIIN305": DeclarantIIN305,
                        "DeclarantBirthDate305": DeclarantBirthDate305,
                        "IdentityDocNumber305": IdentityDocNumber305,
                        "IdentityDocIssueDate305": IdentityDocIssueDate305,
                        "EmptyLineForRights305": EmptyLineForRights305,
                        "EmptyLineForBurdens305": EmptyLineForBurdens305,
                        "EmptyLineForUPSes305": EmptyLineForUPSes305,
                        "ObjectTypeId305": ObjectTypeId305,
                        "KadastrNumber305": KadastrNumber305,
                        "ObjectLocation305": ObjectLocation305,
                        "ObjectEndUse305": ObjectEndUse305,
                        "QuantityPart305": QuantityPart305,
                        "Storeys305": Storeys305,
                        "SquareTotal305": SquareTotal305,
                        "BasicArea305": BasicArea305,
                        "DwellingArea305": DwellingArea305,
                        "Divisibility305": Divisibility305,
                        "SpecialNotes305": SpecialNotes305,
                        "ClaimsAndDealsDocList305": ClaimsAndDealsDocList305,
                        "RightType305": RightType305,
                        "RightSubstance305": RightSubstance305,
                        "RightOwner305": RightOwner305,
                        "OwnershipType305": OwnershipType305,
                        "RightFoundationDocTip305": RightFoundationDocTip305,
                        "RightFoundationDocNo305": RightFoundationDocNo305,
                        "RightFoundationDocDt305": RightFoundationDocDt305,
                        "RegistrationDate305": RegistrationDate305,
                    }
                )
    df = pd.DataFrame(rows)
    return df


def parse_zags_data(xml):
    root_node = et.fromstring(xml)
    rows = []

    for familyReturn in root_node.findall(".//familyReturn"):
        messageId = xmlImport(familyReturn, ".//responseData/data/messageId")
        messageDate = xmlImport(familyReturn, ".//responseData/data/messageDate")
        requestId = xmlImport(familyReturn, ".//responseData/data/requestId")
        messageResultCode = xmlImport(familyReturn, ".//responseData/data/messageResult/code")
        for childData in familyReturn.findall(".//infoList"):
            actDate = xmlImport(childData, ".//birthInfos/actDate")
            actNumber = xmlImport(childData, ".//birthInfos/actNumber")
            childBirthDate = xmlImport(childData, ".//birthInfos/childBirthDate")
            childIIN = xmlImport(childData, ".//birthInfos/childIIN")
            marriageActDate = xmlImport(childData, ".//birthInfos/marriageActDate")
            motherBirthDate = xmlImport(childData, ".//birthInfos/motherBirthDate")
            motherIIN = xmlImport(childData, ".//birthInfos/motherIIN")
            motherName = xmlImport(childData, ".//birthInfos/motherName")
            motherPatronymic = xmlImport(childData, ".//birthInfos/motherPatronymic")
            motherSurName = xmlImport(childData, ".//birthInfos/motherSurName")
            fatherBirthDate = xmlImport(childData, ".//birthInfos/fatherBirthDate")
            fatherIIN = xmlImport(childData, ".//birthInfos/fatherIIN")
            fatherName = xmlImport(childData, ".//birthInfos/fatherName")
            fatherPatronymic = xmlImport(childData, ".//birthInfos/fatherPatronymic")
            fatherSurName = xmlImport(childData, ".//birthInfos/fatherSurName")
            zagsCode = xmlImport(childData, ".//birthInfos/zagsCode")
            zagsNameKZ = xmlImport(childData, ".//birthInfos/zagsNameKZ")
            zagsNameRU = xmlImport(childData, ".//birthInfos/zagsNameRU")

            rows.append(
                {
                    "messageId": messageId,
                    "messageDate": messageDate,
                    "requestId": requestId,
                    "messageResultCode": messageResultCode,
                    "actDate": actDate,
                    "actNumber": actNumber,
                    "childBirthDate": childBirthDate,
                    "childIIN": childIIN,
                    "marriageActDate": marriageActDate,
                    "motherBirthDate": motherBirthDate,
                    "motherIIN": motherIIN,
                    "motherName": motherName,
                    "motherPatronymic": motherPatronymic,
                    "motherSurName": motherSurName,
                    "fatherBirthDate": fatherBirthDate,
                    "fatherIIN": fatherIIN,
                    "fatherName": fatherName,
                    "fatherPatronymic": fatherPatronymic,
                    "fatherSurName": fatherSurName,
                    "zagsCode": zagsCode,
                    "zagsNameKZ": zagsNameKZ,
                    "zagsNameRU": zagsNameRU,
                }
            )

    df_parsed = pd.DataFrame(rows)
    return df_parsed


def parse_auto_data(xml):
    root_node = et.fromstring(xml)
    rows = []

    for item in root_node.findall(".//item"):
        idNumNikad = xmlImport(item, "idNumNikad")
        autoRegNum = xmlImport(item, "autoRegNum")
        autoRegNumOld = xmlImport(item, "autoRegNumOld")
        autoModel = xmlImport(item, "autoModel")
        autoYear = xmlImport(item, "autoYear")
        motorNum = xmlImport(item, "motorNum")
        chassisNum = xmlImport(item, "chassisNum")
        bodyNum = xmlImport(item, "bodyNum")
        autoColor = xmlImport(item, "autoColor")
        autoColorName = xmlImport(item, "autoColorName")
        srtsSerNum = xmlImport(item, "srtsSerNum")
        autoCategory = xmlImport(item, "autoCategory")
        motorPower1 = xmlImport(item, "motorPower1")
        motorPower2 = xmlImport(item, "motorPower2")
        motorVolume = xmlImport(item, "motorVolume")
        autoTonnageMax = xmlImport(item, "autoTonnageMax")
        autoWeight = xmlImport(item, "autoWeight")
        docPurchaseCode = xmlImport(item, "docPurchaseCode")
        docPurchaseNumDate = xmlImport(item, "docPurchaseNumDate")
        srtsSerNumOld = xmlImport(item, "srtsSerNumOld")
        srtsDate = xmlImport(item, "srtsDate")
        countPlacesBus = xmlImport(item, "countPlacesBus")

        lastName = xmlImport(item, "lastName")
        firstName = xmlImport(item, "firstName")
        middleName = xmlImport(item, "middleName")

        docSer = xmlImport(item, "docSer")
        docType = xmlImport(item, "docType")
        docDate = xmlImport(item, "docDate")
        docNum = xmlImport(item, "docNum")
        drivingDocSer = xmlImport(item, "drivingDocSer")
        drivingDocNum = xmlImport(item, "drivingDocNum")
        areaCode = xmlImport(item, "areaCode")
        districtCode = xmlImport(item, "districtCode")
        cityCode = xmlImport(item, "cityCode")
        streetName = xmlImport(item, "streetName")
        dom = xmlImport(item, "dom")
        apartment = xmlImport(item, "apartment")
        contactPrefix = xmlImport(item, "contactPrefix")
        autoRegNumCode = xmlImport(item, "autoRegNumCode")
        isPersonApplicant = xmlImport(item, "isPersonApplicant")
        autoType = xmlImport(item, "autoType")
        national = xmlImport(item, "national")
        gender = xmlImport(item, "gender")
        rnn = xmlImport(item, "rnn")
        #        iin = xmlImport(item, 'iin')
        osobOtmetki = xmlImport(item, "osobOtmetki")
        ownerKato = xmlImport(item, "ownerKato")
        birthDate = xmlImport(item, "birthDate")
        status = xmlImport(item, "status")
        statusDate = xmlImport(item, "statusDate")
        autoFirstRegDate = xmlImport(item, "autoFirstRegDate")

        rows.append(
            {
                "idNumNikad": idNumNikad,
                "autoRegNum": autoRegNum,
                "autoRegNumOld": autoRegNumOld,
                "autoModel": autoModel,
                "autoYear": autoYear,
                "motorNum": motorNum,
                "chassisNum": chassisNum,
                "bodyNum": bodyNum,
                "autoColor": autoColor,
                "autoColorName": autoColorName,
                "srtsSerNum": srtsSerNum,
                "autoCategory": autoCategory,
                "motorPower1": motorPower1,
                "motorPower2": motorPower2,
                "motorVolume": motorVolume,
                "autoTonnageMax": autoTonnageMax,
                "autoWeight": autoWeight,
                "docPurchaseCode": docPurchaseCode,
                "docPurchaseNumDate": docPurchaseNumDate,
                "srtsSerNumOld": srtsSerNumOld,
                "srtsDate": srtsDate,
                "countPlacesBus": countPlacesBus,
                "lastName": lastName,
                "firstName": firstName,
                "middleName": middleName,
                "docSer": docSer,
                "docType": docType,
                "docDate": docDate,
                "docNum": docNum,
                "drivingDocSer": drivingDocSer,
                "drivingDocNum": drivingDocNum,
                "areaCode": areaCode,
                "districtCode": districtCode,
                "cityCode": cityCode,
                "streetName": streetName,
                "dom": dom,
                "apartment": apartment,
                "contactPrefix": contactPrefix,
                "autoRegNumCode": autoRegNumCode,
                "isPersonApplicant": isPersonApplicant,
                "autoType": autoType,
                "national": national,
                "gender": gender,
                "rnn": rnn
                #            ,'iin': iin
                ,
                "osobOtmetki": osobOtmetki,
                "ownerKato": ownerKato,
                "birthDate": birthDate,
                "status": status,
                "statusDate": statusDate,
                "autoFirstRegDate": autoFirstRegDate,
            }
        )

    df = pd.DataFrame(rows)
    return df


def parse_real_estate_306_data(xml):
    root_node = et.fromstring(xml)
    rows = []
    for AvailabilityOfPropertyEvidencePerson in root_node.findall(".//businessData"):
        StatementFeedPlace306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/StatementFeedPlace"
        )
        StatementNumber306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/StatementNumber"
        )
        StatementDate306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/StatementDate"
        )
        LastName306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/Declarant/LastName"
        )
        FirstName306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/Declarant/FirstName"
        )
        MiddleName306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/Declarant/MiddleName"
        )
        BornDt306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/Declarant/BornDt"
        )
        DeclarantIIN306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/DeclarantIIN"
        )
        DeclarantBirthDate306 = xmlImport(
            AvailabilityOfPropertyEvidencePerson, ".//AvailabilityOfPropertyEvidencePerson/DeclarantBirthDate"
        )
        for Item in AvailabilityOfPropertyEvidencePerson.findall(".//ObjectShortInfos/Item"):
            ObjectTypeId306 = xmlImport(Item, "ObjectTypeId")
            KadastrNumber306 = xmlImport(Item, "KadastrNumber")
            ObjectLocation306 = xmlImport(Item, "ObjectLocation")
            ObjectEndUse306 = xmlImport(Item, "ObjectEndUse")
            Location_arCode306 = xmlImport(Item, ".//Location/arCode")
            Location_KATO306 = xmlImport(Item, ".//Location/KATO")
            Location_Area_CodeRN306 = xmlImport(Item, ".//Location/Area/CodeRN")
            Location_Area_CodeSHEP306 = xmlImport(Item, ".//Location/Area/CodeSHEP")
            Location_Area_CodeAR306 = xmlImport(Item, ".//Location/Area/CodeAR")
            Location_Area_KATO306 = xmlImport(Item, ".//Location/Area/KATO")
            Location_Area_NameRu306 = xmlImport(Item, ".//Location/Area/NameRu")
            Location_Area_NameKz306 = xmlImport(Item, ".//Location/Area/NameKz")
            Location_Area_TypeCodeAR306 = xmlImport(Item, ".//Location/Area/TypeCodeAR")
            Location_Area_TypeNameRu306 = xmlImport(Item, ".//Location/Area/TypeNameRu")
            Location_Area_TypeNameKz306 = xmlImport(Item, ".//Location/Area/TypeNameKz")
            Location_Area_TypeShortNameRu306 = xmlImport(Item, ".//Location/Area/TypeShortNameRu")
            Location_Area_TypeShortNameKz306 = xmlImport(Item, ".//Location/Area/TypeShortNameKz")
            Location_DistrictArea_CodeRN306 = xmlImport(Item, ".//Location/DistrictArea/CodeRN")
            Location_DistrictArea_CodeSHEP306 = xmlImport(Item, ".//Location/DistrictArea/CodeSHEP")
            Location_DistrictArea_CodeAR306 = xmlImport(Item, ".//Location/DistrictArea/CodeAR")
            Location_DistrictArea_KATO306 = xmlImport(Item, ".//Location/DistrictArea/KATO")
            Location_DistrictArea_NameRu306 = xmlImport(Item, ".//Location/DistrictArea/NameRu")
            Location_DistrictArea_NameKz306 = xmlImport(Item, ".//Location/DistrictArea/NameKz")
            Location_DistrictArea_TypeCodeAR306 = xmlImport(Item, ".//Location/DistrictArea/TypeCodeAR")
            Location_DistrictArea_TypeNameRu306 = xmlImport(Item, ".//Location/DistrictArea/TypeNameRu")
            Location_DistrictArea_TypeNameKz306 = xmlImport(Item, ".//Location/DistrictArea/TypeNameKz")
            Location_DistrictArea_TypeShortNameRu306 = xmlImport(Item, ".//Location/DistrictArea/TypeShortNameRu")
            Location_DistrictArea_TypeShortNameKz306 = xmlImport(Item, ".//Location/DistrictArea/TypeShortNameKz")
            Location_RuralDistrict306 = xmlImport(Item, ".//Location/RuralDistrict")
            Location_DistrictCity_CodeRN306 = xmlImport(Item, ".//Location/DistrictCity/CodeRN")
            Location_DistrictCity_CodeSHEP306 = xmlImport(Item, ".//Location/DistrictCity/CodeSHEP")
            Location_DistrictCity_CodeAR306 = xmlImport(Item, ".//Location/DistrictCity/CodeAR")
            Location_DistrictCity_KATO306 = xmlImport(Item, ".//Location/DistrictCity/KATO")
            Location_DistrictCity_NameRu306 = xmlImport(Item, ".//Location/DistrictCity/NameRu")
            Location_DistrictCity_NameKz306 = xmlImport(Item, ".//Location/DistrictCity/NameKz")
            Location_DistrictCity_TypeCodeAR306 = xmlImport(Item, ".//Location/DistrictCity/TypeCodeAR")
            Location_DistrictCity_TypeNameRu306 = xmlImport(Item, ".//Location/DistrictCity/TypeNameRu")
            Location_DistrictCity_TypeNameKz306 = xmlImport(Item, ".//Location/DistrictCity/TypeNameKz")
            Location_DistrictCity_TypeShortNameRu306 = xmlImport(Item, ".//Location/DistrictCity/TypeShortNameRu")
            Location_DistrictCity_TypeShortNameKz306 = xmlImport(Item, ".//Location/DistrictCity/TypeShortNameKz")
            Location_Toponym_CodeRN306 = xmlImport(Item, ".//Location/Toponym/CodeRN")
            Location_Toponym_CodeSHEP306 = xmlImport(Item, ".//Location/Toponym/CodeSHEP")
            Location_Toponym_CodeAR306 = xmlImport(Item, ".//Location/Toponym/CodeAR")
            Location_Toponym_NameRu306 = xmlImport(Item, ".//Location/Toponym/NameRu")
            Location_Toponym_NameKz306 = xmlImport(Item, ".//Location/Toponym/NameKz")
            Location_Toponym_TypeCodeAR306 = xmlImport(Item, ".//Location/Toponym/TypeCodeAR")
            Location_Toponym_TypeNameRu306 = xmlImport(Item, ".//Location/Toponym/TypeNameRu")
            Location_Toponym_TypeNameKz306 = xmlImport(Item, ".//Location/Toponym/TypeNameKz")
            Location_Toponym_TypeShortNameRu306 = xmlImport(Item, ".//Location/Toponym/TypeShortNameRu")
            Location_Toponym_TypeShortNameKz306 = xmlImport(Item, ".//Location/Toponym/TypeShortNameKz")
            Location_Building306 = xmlImport(Item, ".//Location/Building")
            Location_Flat306 = xmlImport(Item, ".//Location/Flat")
            rows.append(
                {
                    "StatementFeedPlace306": StatementFeedPlace306,
                    "StatementNumber306": StatementNumber306,
                    "StatementDate306": StatementDate306,
                    "LastName306": LastName306,
                    "FirstName306": FirstName306,
                    "MiddleName306": MiddleName306,
                    "BornDt306": BornDt306,
                    "DeclarantIIN306": DeclarantIIN306,
                    "DeclarantBirthDate306": DeclarantBirthDate306,
                    "ObjectTypeId306": ObjectTypeId306,
                    "KadastrNumber306": KadastrNumber306,
                    "ObjectLocation306": ObjectLocation306,
                    "ObjectEndUse306": ObjectEndUse306,
                    "Location_arCode306": Location_arCode306,
                    "Location_KATO306": Location_KATO306,
                    "Location_Area_CodeRN306": Location_Area_CodeRN306,
                    "Location_Area_CodeSHEP306": Location_Area_CodeSHEP306,
                    "Location_Area_CodeAR306": Location_Area_CodeAR306,
                    "Location_Area_KATO306": Location_Area_KATO306,
                    "Location_Area_NameRu306": Location_Area_NameRu306,
                    "Location_Area_NameKz306": Location_Area_NameKz306,
                    "Location_Area_TypeCodeAR306": Location_Area_TypeCodeAR306,
                    "Location_Area_TypeNameRu306": Location_Area_TypeNameRu306,
                    "Location_Area_TypeNameKz306": Location_Area_TypeNameKz306,
                    "Location_Area_TypeShortNameRu306": Location_Area_TypeShortNameRu306,
                    "Location_Area_TypeShortNameKz306": Location_Area_TypeShortNameKz306,
                    "Location_DistrictArea_CodeRN306": Location_DistrictArea_CodeRN306,
                    "Location_DistrictArea_CodeSHEP306": Location_DistrictArea_CodeSHEP306,
                    "Location_DistrictArea_CodeAR306": Location_DistrictArea_CodeAR306,
                    "Location_DistrictArea_KATO306": Location_DistrictArea_KATO306,
                    "Location_DistrictArea_NameRu306": Location_DistrictArea_NameRu306,
                    "Location_DistrictArea_NameKz306": Location_DistrictArea_NameKz306,
                    "Location_DistrictArea_TypeCodeAR306": Location_DistrictArea_TypeCodeAR306,
                    "Location_DistrictArea_TypeNameRu306": Location_DistrictArea_TypeNameRu306,
                    "Location_DistrictArea_TypeNameKz306": Location_DistrictArea_TypeNameKz306,
                    "Location_DistrictArea_TypeShortNameRu306": Location_DistrictArea_TypeShortNameRu306,
                    "Location_DistrictArea_TypeShortNameKz306": Location_DistrictArea_TypeShortNameKz306,
                    "Location_RuralDistrict306": Location_RuralDistrict306,
                    "Location_DistrictCity_CodeRN306": Location_DistrictCity_CodeRN306,
                    "Location_DistrictCity_CodeSHEP306": Location_DistrictCity_CodeSHEP306,
                    "Location_DistrictCity_CodeAR306": Location_DistrictCity_CodeAR306,
                    "Location_DistrictCity_KATO306": Location_DistrictCity_KATO306,
                    "Location_DistrictCity_NameRu306": Location_DistrictCity_NameRu306,
                    "Location_DistrictCity_NameKz306": Location_DistrictCity_NameKz306,
                    "Location_DistrictCity_TypeCodeAR306": Location_DistrictCity_TypeCodeAR306,
                    "Location_DistrictCity_TypeNameRu306": Location_DistrictCity_TypeNameRu306,
                    "Location_DistrictCity_TypeNameKz306": Location_DistrictCity_TypeNameKz306,
                    "Location_DistrictCity_TypeShortNameRu306": Location_DistrictCity_TypeShortNameRu306,
                    "Location_DistrictCity_TypeShortNameKz306": Location_DistrictCity_TypeShortNameKz306,
                    "Location_Toponym_CodeRN306": Location_Toponym_CodeRN306,
                    "Location_Toponym_CodeSHEP306": Location_Toponym_CodeSHEP306,
                    "Location_Toponym_CodeAR306": Location_Toponym_CodeAR306,
                    "Location_Toponym_NameRu306": Location_Toponym_NameRu306,
                    "Location_Toponym_NameKz306": Location_Toponym_NameKz306,
                    "Location_Toponym_TypeCodeAR306": Location_Toponym_TypeCodeAR306,
                    "Location_Toponym_TypeNameRu306": Location_Toponym_TypeNameRu306,
                    "Location_Toponym_TypeNameKz306": Location_Toponym_TypeNameKz306,
                    "Location_Toponym_TypeShortNameRu306": Location_Toponym_TypeShortNameRu306,
                    "Location_Toponym_TypeShortNameKz306": Location_Toponym_TypeShortNameKz306,
                    "Location_Building306": Location_Building306,
                    "Location_Flat306": Location_Flat306,
                }
            )

    df = pd.DataFrame(rows)
    return df


### Парсинг данных
def process_column(df, xml_column, parse_function, info_columns, none_case):
    parsed_dfs = []
    for index, row in df.iterrows():
        try:
            xml_data = row[xml_column]
            if xml_data and xml_data.strip():
                parsed_df = parse_function(xml_data)
                for col in info_columns:
                    ind = str.lower(col)
                    parsed_df[ind] = row[ind]
                parsed_dfs.append(parsed_df)
        except:
            print("ошибка при парсинге строки #", index, " для ", xml_column)
    if parsed_dfs:
        result_df = pd.concat(parsed_dfs, ignore_index=True)
    else:
        result_df = pd.DataFrame(columns=info_columns + none_case)
    return result_df


###### Конечные колонки
info_columns = ["ID", "IIN", "CREDIT_PRODUCT_TYPE", "MOBILE"]
children_none_case = [
    "messageId",
    "messageDate",
    "requestId",
    "messageResultCode",
    "actDate",
    "actNumber",
    "childBirthDate",
    "childIIN",
    "marriageActDate",
    "motherBirthDate",
    "motherIIN",
    "motherName",
    "motherPatronymic",
    "motherSurName",
    "fatherBirthDate",
    "fatherIIN",
    "fatherName",
    "fatherPatronymic",
    "fatherSurName",
    "zagsCode",
    "zagsNameKZ",
    "zagsNameRU",
]
auto_none_case = [
    "idNumNikad",
    "autoRegNum",
    "autoRegNumOld",
    "autoModel",
    "autoYear",
    "motorNum",
    "chassisNum",
    "bodyNum",
    "autoColor",
    "autoColorName",
    "srtsSerNum",
    "autoCategory",
    "motorPower1",
    "motorPower2",
    "motorVolume",
    "autoTonnageMax",
    "autoWeight",
    "docPurchaseCode",
    "docPurchaseNumDate",
    "srtsSerNumOld",
    "srtsDate",
    "countPlacesBus",
    "lastName",
    "firstName",
    "middleName",
    "docSer",
    "docType",
    "docDate",
    "docNum",
    "drivingDocSer",
    "drivingDocNum",
    "areaCode",
    "districtCode",
    "cityCode",
    "streetName",
    "dom",
    "apartment",
    "contactPrefix",
    "autoRegNumCode",
    "isPersonApplicant",
    "autoType",
    "national",
    "gender",
    "rnn",
    "osobOtmetki",
    "ownerKato",
    "birthDate",
    "status",
    "statusDate",
    "autoFirstRegDate",
]

real_estate_305_none_case = [
    "StatementFeedPlace305",
    "StatementNumber305",
    "StatementDate305",
    "LastName305",
    "FirstName305",
    "MiddleName305",
    "BornDt305",
    "DeclarantIIN305",
    "DeclarantBirthDate305",
    "IdentityDocNumber305",
    "IdentityDocIssueDate305",
    "EmptyLineForRights305",
    "EmptyLineForBurdens305",
    "EmptyLineForUPSes305",
    "ObjectTypeId305",
    "KadastrNumber305",
    "ObjectLocation305",
    "ObjectEndUse305",
    "QuantityPart305",
    "Storeys305",
    "SquareTotal305",
    "BasicArea305",
    "DwellingArea305",
    "Divisibility305",
    "SpecialNotes305",
    "ClaimsAndDealsDocList305",
    "RightType305",
    "RightSubstance305",
    "RightOwner305",
    "OwnershipType305",
    "RightFoundationDocTip305",
    "RightFoundationDocNo305",
    "RightFoundationDocDt305",
    "RegistrationDate305",
]

real_estate_306_none_case = [
    "StatementFeedPlace306",
    "StatementNumber306",
    "StatementDate306",
    "LastName306",
    "FirstName306",
    "MiddleName306",
    "BornDt306",
    "DeclarantIIN306",
    "DeclarantBirthDate306",
    "ObjectTypeId306",
    "KadastrNumber306",
    "ObjectLocation306",
    "ObjectEndUse306",
    "Location_arCode306",
    "Location_KATO306",
    "Location_Area_CodeRN306",
    "Location_Area_CodeSHEP306",
    "Location_Area_CodeAR306",
    "Location_Area_KATO306",
    "Location_Area_NameRu306",
    "Location_Area_NameKz306",
    "Location_Area_TypeCodeAR306",
    "Location_Area_TypeNameRu306",
    "Location_Area_TypeNameKz306",
    "Location_Area_TypeShortNameRu306",
    "Location_Area_TypeShortNameKz306",
    "Location_DistrictArea_CodeRN306",
    "Location_DistrictArea_CodeSHEP306",
    "Location_DistrictArea_CodeAR306",
    "Location_DistrictArea_KATO306",
    "Location_DistrictArea_NameRu306",
    "Location_DistrictArea_NameKz306",
    "Location_DistrictArea_TypeCodeAR306",
    "Location_DistrictArea_TypeNameRu306",
    "Location_DistrictArea_TypeNameKz306",
    "Location_DistrictArea_TypeShortNameRu306",
    "Location_DistrictArea_TypeShortNameKz306",
    "Location_RuralDistrict306",
    "Location_DistrictCity_CodeRN306",
    "Location_DistrictCity_CodeSHEP306",
    "Location_DistrictCity_CodeAR306",
    "Location_DistrictCity_KATO306",
    "Location_DistrictCity_NameRu306",
    "Location_DistrictCity_NameKz306",
    "Location_DistrictCity_TypeCodeAR306",
    "Location_DistrictCity_TypeNameRu306",
    "Location_DistrictCity_TypeNameKz306",
    "Location_DistrictCity_TypeShortNameRu306",
    "Location_DistrictCity_TypeShortNameKz306",
    "Location_Toponym_CodeRN306",
    "Location_Toponym_CodeSHEP306",
    "Location_Toponym_CodeAR306",
    "Location_Toponym_NameRu306",
    "Location_Toponym_NameKz306",
    "Location_Toponym_TypeCodeAR306",
    "Location_Toponym_TypeNameRu306",
    "Location_Toponym_TypeNameKz306",
    "Location_Toponym_TypeShortNameRu306",
    "Location_Toponym_TypeShortNameKz306",
    "Location_Building306",
    "Location_Flat306",
]


def process_zags(df):
    print("Начался парсинг загс")
    try:
        result_zags = process_column(df, "getfamilyinforesponse", parse_zags_data, info_columns, children_none_case)
        result_zags = result_zags[
            [
                "id",
                "iin",
                "credit_product_type",
                "mobile",
                "messageId",
                "messageDate",
                "requestId",
                "messageResultCode",
                "actDate",
                "actNumber",
                "childBirthDate",
                "childIIN",
                "marriageActDate",
                "motherBirthDate",
                "motherIIN",
                "motherName",
                "motherPatronymic",
                "motherSurName",
                "fatherBirthDate",
                "fatherIIN",
                "fatherName",
                "fatherPatronymic",
                "fatherSurName",
                "zagsCode",
                "zagsNameKZ",
                "zagsNameRU",
            ]
        ]

        return result_zags
    except Exception as e:
        print("Данных в таблице больше нет")


def process_auto(df):
    print("Начался парсинг авто")
    result_auto = process_column(df, "getautoresponse", parse_auto_data, info_columns, auto_none_case)
    result_auto = result_auto[
        [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "idNumNikad",
            "autoRegNum",
            "autoRegNumOld",
            "autoModel",
            "autoYear",
            "motorNum",
            "chassisNum",
            "bodyNum",
            "autoColor",
            "autoColorName",
            "srtsSerNum",
            "autoCategory",
            "motorPower1",
            "motorPower2",
            "motorVolume",
            "autoTonnageMax",
            "autoWeight",
            "docPurchaseCode",
            "docPurchaseNumDate",
            "srtsSerNumOld",
            "srtsDate",
            "countPlacesBus",
            "lastName",
            "firstName",
            "middleName",
            "docSer",
            "docType",
            "docDate",
            "docNum",
            "drivingDocSer",
            "drivingDocNum",
            "areaCode",
            "districtCode",
            "cityCode",
            "streetName",
            "dom",
            "apartment",
            "contactPrefix",
            "autoRegNumCode",
            "isPersonApplicant",
            "autoType",
            "national",
            "gender",
            "rnn",
            "osobOtmetki",
            "ownerKato",
            "birthDate",
            "status",
            "statusDate",
            "autoFirstRegDate",
        ]
    ]
    return result_auto


def process_305(df):
    print("Начался парсинг 305")
    result_305 = process_column(
        df,
        "gbdrnreport305",
        parse_real_estate_305_data,
        info_columns,
        real_estate_305_none_case,
    )
    result_305 = result_305[
        [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "StatementFeedPlace305",
            "StatementNumber305",
            "StatementDate305",
            "LastName305",
            "FirstName305",
            "MiddleName305",
            "BornDt305",
            "DeclarantIIN305",
            "DeclarantBirthDate305",
            "IdentityDocNumber305",
            "IdentityDocIssueDate305",
            "EmptyLineForRights305",
            "EmptyLineForBurdens305",
            "EmptyLineForUPSes305",
            "ObjectTypeId305",
            "KadastrNumber305",
            "ObjectLocation305",
            "ObjectEndUse305",
            "QuantityPart305",
            "Storeys305",
            "SquareTotal305",
            "BasicArea305",
            "DwellingArea305",
            "Divisibility305",
            "SpecialNotes305",
            "ClaimsAndDealsDocList305",
            "RightType305",
            "RightSubstance305",
            "RightOwner305",
            "OwnershipType305",
            "RightFoundationDocTip305",
            "RightFoundationDocNo305",
            "RightFoundationDocDt305",
            "RegistrationDate305",
        ]
    ]
    return result_305


def process_306(df):
    print("Начался парсинг 306")
    result_306 = process_column(
        df, "gbdrnreport306", parse_real_estate_306_data, info_columns, real_estate_306_none_case
    )
    result_306 = result_306[
        [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "StatementFeedPlace306",
            "StatementNumber306",
            "StatementDate306",
            "LastName306",
            "FirstName306",
            "MiddleName306",
            "BornDt306",
            "DeclarantIIN306",
            "DeclarantBirthDate306",
            "ObjectTypeId306",
            "KadastrNumber306",
            "ObjectLocation306",
            "ObjectEndUse306",
            "Location_arCode306",
            "Location_KATO306",
            "Location_Area_CodeRN306",
            "Location_Area_CodeSHEP306",
            "Location_Area_CodeAR306",
            "Location_Area_KATO306",
            "Location_Area_NameRu306",
            "Location_Area_NameKz306",
            "Location_Area_TypeCodeAR306",
            "Location_Area_TypeNameRu306",
            "Location_Area_TypeNameKz306",
            "Location_Area_TypeShortNameRu306",
            "Location_Area_TypeShortNameKz306",
            "Location_DistrictArea_CodeRN306",
            "Location_DistrictArea_CodeSHEP306",
            "Location_DistrictArea_CodeAR306",
            "Location_DistrictArea_KATO306",
            "Location_DistrictArea_NameRu306",
            "Location_DistrictArea_NameKz306",
            "Location_DistrictArea_TypeCodeAR306",
            "Location_DistrictArea_TypeNameRu306",
            "Location_DistrictArea_TypeNameKz306",
            "Location_DistrictArea_TypeShortNameRu306",
            "Location_DistrictArea_TypeShortNameKz306",
            "Location_RuralDistrict306",
            "Location_DistrictCity_CodeRN306",
            "Location_DistrictCity_CodeSHEP306",
            "Location_DistrictCity_CodeAR306",
            "Location_DistrictCity_KATO306",
            "Location_DistrictCity_NameRu306",
            "Location_DistrictCity_NameKz306",
            "Location_DistrictCity_TypeCodeAR306",
            "Location_DistrictCity_TypeNameRu306",
            "Location_DistrictCity_TypeNameKz306",
            "Location_DistrictCity_TypeShortNameRu306",
            "Location_DistrictCity_TypeShortNameKz306",
            "Location_Toponym_CodeRN306",
            "Location_Toponym_CodeSHEP306",
            "Location_Toponym_CodeAR306",
            "Location_Toponym_NameRu306",
            "Location_Toponym_NameKz306",
            "Location_Toponym_TypeCodeAR306",
            "Location_Toponym_TypeNameRu306",
            "Location_Toponym_TypeNameKz306",
            "Location_Toponym_TypeShortNameRu306",
            "Location_Toponym_TypeShortNameKz306",
            "Location_Building306",
            "Location_Flat306",
        ]
    ]
    return result_306


#### Загрузка в базу
def upload_to_sql(sql_query, result_df, cursor, conn):
    result_df = result_df.values.tolist()
    # result_df
    # start_pos = 0
    # batch_size = 100000
    # while start_pos < len(result_df):
    # data = result_df[start_pos : start_pos + batch_size]
    # start_pos = start_pos + batch_size
    cursor.executemany(sql_query, result_df)
    conn.commit()


def final_gbdrnreport306_load(oracle_hook):
    dssb_conn = oracle_hook.get_conn()
    dssb_cursor = dssb_conn.cursor()
    gbdrn306_table = "DSSB_OCDS.d$gdb_real_estate_306"
    sql_upload_306 = f"""insert into {gbdrn306_table} (id,iin,credit_product_type,mobile,statementfeedplace306,statementnumber306,statementdate306,lastname306,firstname306,    middlename306,borndt306,declarantiin306,declarantbirthdate306,objecttypeid306,kadastrnumber306,objectlocation306,objectenduse306,location_arcode306,location_kato306,location_area_codern306,location_area_codeshep306,location_area_codear306,location_area_kato306,
location_area_nameru306,location_area_namekz306,location_area_typecodear306,location_area_typenameru306,location_area_typenamekz306,
location_area_typeshortnameru306,location_area_typeshortnamekz306,location_districtarea_codern306,location_districtarea_codeshep306,
location_districtarea_codear306,location_districtarea_kato306,location_districtarea_nameru306,location_districtarea_namekz306,
location_districtarea_typecodear306,location_districtarea_typenameru306,location_districtarea_typenamekz306,
location_districtarea_typeshortnameru306,location_districtarea_typeshortnamekz306,location_ruraldistrict306,
location_districtcity_codern306,location_districtcity_codeshep306,location_districtcity_codear306,location_districtcity_kato306,
location_districtcity_nameru306,location_districtcity_namekz306,location_districtcity_typecodear306,location_districtcity_typenameru306,
location_districtcity_typenamekz306,location_districtcity_typeshortnameru306,location_districtcity_typeshortnamekz306,location_toponym_codern306,
location_toponym_codeshep306,location_toponym_codear306,location_toponym_nameru306,location_toponym_namekz306,location_toponym_typecodear306,
location_toponym_typenameru306,location_toponym_typenamekz306,location_toponym_typeshortnameru306,location_toponym_typeshortnamekz306,location_building306,location_flat306)
 values (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19,:20,:21,:22,:23,:24,:25,:26,:27,:28,
:29,:30,:31,:32,:33,:34,:35,:36,:37,:38,:39,:40,:41,:42,:43,:44,:45,:46,:47,:48,:49,:50,:51,:52,:53,:54,
 :55,:56,:57,:58,:59,:60,:61,:62,:63,:64,:65)
"""
    dssb_cursor.execute(
        """
                        select count(*)
                    from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1
                              and t.act_date < trunc(sysdate) 
                              and length(GBDRNREPORT306) > 0
                            """
    )

    count = dssb_cursor.fetchone()[0]
    start = "Start GBDRNREPORT306: " + str(datetime.datetime.now())
    print(start)
    start_row_pos = 0
    b_size = 200000
    while start_row_pos < count:
        sql_query_download = f"""select       
                                   id,
                                   iin,
                                   CREDIT_PRODUCT_TYPE,
                                   MOBILE,
                                   GBDRNREPORT305,
                                   GBDRNREPORT306,
                                   GETFAMILYINFORESPONSE,
                                   GETAUTORESPONSE
                             from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1 
                              and t.act_date < trunc(sysdate) 
                              and length(GBDRNREPORT306) > 0
                            order by rownum
                            offset {start_row_pos} rows
                            fetch next  {b_size} rows only
                        """

        sql_query_columns = [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "gbdrnreport305",
            "gbdrnreport306",
            "getfamilyinforesponse",
            "getautoresponse",
        ]
        dssb_cursor.execute(sql_query_download)
        fetch = dssb_cursor.fetchall()
        df = pd.DataFrame(fetch, columns=sql_query_columns)
        for column in ["gbdrnreport305", "gbdrnreport306", "getfamilyinforesponse", "getautoresponse"]:
            df[column] = df[column].apply(clob_to_str)
        result_306 = process_306(df)
        upload_to_sql(sql_upload_306, result_306, dssb_cursor, dssb_conn)
        start_row_pos = start_row_pos + b_size
        print("Загрузилось:", start_row_pos, "строк")
    dssb_cursor.execute(
        f"""
           delete from DSSB_OCDS.d$gdb_real_estate_306 
            where rowid not in
         (select min (rowid) 
          from DSSB_OCDS.d$gdb_real_estate_306 t 
         group by id,iin,credit_product_type,mobile,statementfeedplace306,statementnumber306,statementdate306,lastname306,firstname306,
         middlename306,borndt306,declarantiin306,declarantbirthdate306,objecttypeid306,kadastrnumber306,objectlocation306,objectenduse306,
         location_arcode306,location_kato306,location_area_codern306,location_area_codeshep306,location_area_codear306,location_area_kato306,
         location_area_nameru306,location_area_namekz306,location_area_typecodear306,location_area_typenameru306,location_area_typenamekz306,
         location_area_typeshortnameru306,location_area_typeshortnamekz306,location_districtarea_codern306,location_districtarea_codeshep306,
         location_districtarea_codear306,location_districtarea_kato306,location_districtarea_nameru306,location_districtarea_namekz306,
         location_districtarea_typecodear306,location_districtarea_typenameru306,location_districtarea_typenamekz306,
         location_districtarea_typeshortnameru306,location_districtarea_typeshortnamekz306,location_ruraldistrict306,
         location_districtcity_codern306,location_districtcity_codeshep306,location_districtcity_codear306,location_districtcity_kato306,
         location_districtcity_nameru306,location_districtcity_namekz306,location_districtcity_typecodear306,location_districtcity_typenameru306,
         location_districtcity_typenamekz306,location_districtcity_typeshortnameru306,location_districtcity_typeshortnamekz306,location_toponym_codern306,
         location_toponym_codeshep306,location_toponym_codear306,location_toponym_nameru306,location_toponym_namekz306,location_toponym_typecodear306,
         location_toponym_typenameru306,location_toponym_typenamekz306,location_toponym_typeshortnameru306,location_toponym_typeshortnamekz306,
         location_building306,location_flat306)
    """
    )
    dssb_conn.commit()
    dssb_cursor.close()
    dssb_conn.close()
    print(start)
    print("End GBDRNREPORT305: ", datetime.datetime.now())


def final_gbdrnreport305_load(oracle_hook):
    dssb_conn = oracle_hook.get_conn()
    dssb_cursor = dssb_conn.cursor()
    gbdrn305_table = "DSSB_OCDS.d$gdb_real_estate_305"
    sql_upload_305 = f"""insert into {gbdrn305_table} (id, iin, credit_product_type, mobile, statementfeedplace305, statementnumber305, 
                                                   statementdate305, lastname305, firstname305, middlename305, borndt305, declarantiin305, 
                                                   declarantbirthdate305, identitydocnumber305, identitydocissuedate305, emptylineforrights305, 
                                                   emptylineforburdens305, emptylineforupses305, objecttypeid305, kadastrnumber305, objectlocation305, 
                                                   objectenduse305, quantitypart305, storeys305, squaretotal305, basicarea305, dwellingarea305, divisibility305, 
                                                   specialnotes305, claimsanddealsdoclist305, righttype305, rightsubstance305, rightowner305, ownershiptype305, 
                                                   rightfoundationdoctip305, rightfoundationdocno305, rightfoundationdocdt305, registrationdate305)       
                                           values (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19,:20,:21,:22,:23,:24,:25,:26,:27,:28,:29,:30,:31,:32,:33,:34,:35,:36,:37,:38)
"""

    dssb_cursor.execute(
        """select count(*)
                             from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1 
                              and t.act_date < trunc(sysdate)
                              and length(GBDRNREPORT305) > 0
                            order by rownum
                            """
    )
    count = dssb_cursor.fetchone()[0]
    start = "Start GBDRNREPORT305: " + str(datetime.datetime.now())
    print(start)
    start_row_pos = 0
    b_size = 200000
    while start_row_pos < count:
        sql_query_download = f"""select       
                                   id,
                                   iin,
                                   CREDIT_PRODUCT_TYPE,
                                   MOBILE,
                                   GBDRNREPORT305,
                                   GBDRNREPORT306,
                                   GETFAMILYINFORESPONSE,
                                   GETAUTORESPONSE
                             from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1
                              and t.act_date < trunc(sysdate) 
                              and length(GBDRNREPORT305) > 0
                            order by rownum
                            offset {start_row_pos} rows
                            fetch next {b_size} rows only
                        """
        sql_query_columns = [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "gbdrnreport305",
            "gbdrnreport306",
            "getfamilyinforesponse",
            "getautoresponse",
        ]
        dssb_cursor.execute(sql_query_download)
        fetch = dssb_cursor.fetchall()
        df = pd.DataFrame(fetch, columns=sql_query_columns)
        for column in ["gbdrnreport305", "gbdrnreport306", "getfamilyinforesponse", "getautoresponse"]:
            df[column] = df[column].apply(clob_to_str)
        result_305 = process_305(df)
        upload_to_sql(sql_upload_305, result_305, dssb_cursor, dssb_conn)
        start_row_pos = start_row_pos + b_size
        print("Загрузилось:", start_row_pos, "строк")

    dssb_cursor.execute(
        f"""
    delete from {gbdrn305_table}
    where rowid not in
    (select min (rowid) 
    from DSSB_OCDS.d$gdb_real_estate_305 t 
    group by ID, STATEMENTNUMBER305, IIN, CREDIT_PRODUCT_TYPE, MOBILE, STATEMENTFEEDPLACE305, 
             STATEMENTDATE305, LASTNAME305, FIRSTNAME305, MIDDLENAME305, BORNDT305, 
             DECLARANTIIN305, DECLARANTBIRTHDATE305, IDENTITYDOCNUMBER305, IDENTITYDOCISSUEDATE305, 
             EMPTYLINEFORRIGHTS305, EMPTYLINEFORBURDENS305, EMPTYLINEFORUPSES305, OBJECTTYPEID305,
             KADASTRNUMBER305, OBJECTLOCATION305, OBJECTENDUSE305, QUANTITYPART305, STOREYS305, 
             SQUARETOTAL305, BASICAREA305, DWELLINGAREA305, DIVISIBILITY305, SPECIALNOTES305, 
             CLAIMSANDDEALSDOCLIST305, RIGHTTYPE305, RIGHTSUBSTANCE305, RIGHTOWNER305, OWNERSHIPTYPE305, 
             RIGHTFOUNDATIONDOCTIP305, RIGHTFOUNDATIONDOCNO305, RIGHTFOUNDATIONDOCDT305, REGISTRATIONDATE305)
    """
    )
    dssb_conn.commit()
    dssb_cursor.close()
    dssb_conn.close()
    print(start)
    print("End GBDRNREPORT305: ", datetime.datetime.now())


def final_auto_load(oracle_hook):
    dssb_conn = oracle_hook.get_conn()
    dssb_cursor = dssb_conn.cursor()
    auto_table = "DSSB_OCDS.d$gdb_auto"
    sql_upload_auto = f"""insert into {auto_table} (id, iin, credit_product_type, mobile, idnumnikad, autoregnum, autoregnumold, 
                          automodel, autoyear, motornum, chassisnum, bodynum, autocolor, autocolorname, 
                          srtssernum, autocategory, motorpower1, motorpower2, motorvolume, autotonnagemax, 
                          autoweight, docpurchasecode, docpurchasenumdate, srtssernumold, srtsdate, 
                          countplacesbus, lastname, firstname, middlename, docser, doctype, docdate, 
                          docnum, drivingdocser, drivingdocnum, areacode, districtcode, citycode, streetname, 
                          dom, apartment, contactprefix, autoregnumcode, ispersonapplicant, autotype, national, 
                          gender, rnn, osobotmetki, ownerkato, birthdate, status, statusdate, autofirstregdate)
                  values (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19,:20,:21,:22,:23,:24,:25,:26,:27,:28,:29,:30,:31,:32,:33,:34,:35,:36,:37,:38,:39,:40,:41,:42,:43,:44,:45,:46,:47,:48,:49,:50,:51,:52,:53,:54)
    """
    dssb_cursor.execute(
        """
                        select count(*)
                    from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1
                              and t.act_date < trunc(sysdate) 
                              and length(GETAUTORESPONSE) > 0
                            """
    )
    count = dssb_cursor.fetchone()[0]
    start = "Start Auto: " + str(datetime.datetime.now())
    print(start)
    start_row_pos = 0
    b_size = 200000
    while start_row_pos < count:
        sql_query_download = f"""  select       
                                   id,
                                   iin,
                                   CREDIT_PRODUCT_TYPE,
                                   MOBILE,
                                   GBDRNREPORT305,
                                   GBDRNREPORT306,
                                   GETFAMILYINFORESPONSE,
                                   GETAUTORESPONSE
                             from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1
                              and t.act_date < trunc(sysdate)
                              and length(GETAUTORESPONSE) > 0
                            order by rownum
                           offset {start_row_pos} rows
                            fetch next  {b_size} rows only
                        """
        sql_query_columns = [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "gbdrnreport305",
            "gbdrnreport306",
            "getfamilyinforesponse",
            "getautoresponse",
        ]
        dssb_cursor.execute(sql_query_download)
        fetch = dssb_cursor.fetchall()
        print("Select query end")
        df = pd.DataFrame(fetch, columns=sql_query_columns)
        for column in ["gbdrnreport305", "gbdrnreport306", "getfamilyinforesponse", "getautoresponse"]:
            df[column] = df[column].apply(clob_to_str)
        result_auto = process_auto(df)
        print("SQL INSERT")
        upload_to_sql(sql_upload_auto, result_auto, dssb_cursor, dssb_conn)
        start_row_pos = start_row_pos + b_size
        print("Загрузилось:", start_row_pos, "строк")
    dssb_cursor.execute(
        f""" 
delete from dssb_ocds.d$gdb_auto z
where rowid in (
select row_id 
from (
select rowid as row_id,
       row_number() over (partition by iin, 
       mobile, idnumnikad, autoregnum, autoregnumold, automodel, 
       autoyear, motornum, chassisnum, bodynum, autocolor, autocolorname, 
       srtssernum, autocategory, motorpower1, motorpower2, motorvolume, 
       autotonnagemax, autoweight, docpurchasecode, docpurchasenumdate, 
       srtssernumold, srtsdate, countplacesbus, lastname, firstname, middlename, 
       docser, doctype, docdate, docnum, drivingdocser, drivingdocnum, areacode, 
       districtcode, citycode, streetname, dom, apartment, contactprefix, autoregnumcode, 
       ispersonapplicant, autotype, national, gender, rnn, osobotmetki, ownerkato, 
       birthdate, status, statusdate, autofirstregdate order by s$change_date desc)  as rn
from dssb_ocds.d$gdb_auto z
)
where rn > 1 
)
    """
    )
    dssb_conn.commit()
    dssb_cursor.close()
    dssb_conn.close()
    print(start)
    print("End: ", datetime.datetime.now())


def final_zags_load(oracle_hook):
    dssb_conn = oracle_hook.get_conn()
    dssb_cursor = dssb_conn.cursor()
    children_table = "DSSB_OCDS.d$gdb_zags"
    sql_upload_zags = f"""
insert into {children_table} (id, iin, credit_product_type, mobile, messageid, messagedate, requestid, messageresultcode, actdate, 
                              actnumber, childbirthdate, childiin, marriageactdate, motherbirthdate, motheriin, mothername, motherpatronymic, 
                              mothersurname, fatherbirthdate, fatheriin, fathername, fatherpatronymic, fathersurname, zagscode, zagsnamekz, zagsnameru) 
                      values (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19,:20,:21,:22,:23,:24,:25,:26)
"""
    dssb_cursor.execute(
        """
                        select count(*)
                    from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1
                              and t.act_date < trunc(sysdate) 
                              and length(GETFAMILYINFORESPONSE) > 0
                            """
    )
    count = dssb_cursor.fetchone()[0]
    start = "Start: " + str(datetime.datetime.now())
    print(start)
    start_row_pos = 0
    b_size = 200000
    while start_row_pos < count:
        sql_query_download = f"""select       
                                   id,
                                   iin,
                                   CREDIT_PRODUCT_TYPE,
                                   MOBILE,
                                   GBDRNREPORT305,
                                   GBDRNREPORT306,
                                   GETFAMILYINFORESPONSE,
                                   GETAUTORESPONSE
                             from dssb_dev.agg_auto_child_estate_info t
                            where 1=1
                              and t.act_date >= trunc(sysdate) -1
                              and t.act_date < trunc(sysdate) 
                              and length(GETFAMILYINFORESPONSE) > 0
                            order by rownum
                           offset {start_row_pos} rows
                            fetch next  {b_size} rows only
                        """
        sql_query_columns = [
            "id",
            "iin",
            "credit_product_type",
            "mobile",
            "gbdrnreport305",
            "gbdrnreport306",
            "getfamilyinforesponse",
            "getautoresponse",
        ]
        dssb_cursor.execute(sql_query_download)
        fetch = dssb_cursor.fetchall()
        print("Select query end")
        df = pd.DataFrame(fetch, columns=sql_query_columns)
        for column in ["gbdrnreport305", "gbdrnreport306", "getfamilyinforesponse", "getautoresponse"]:
            df[column] = df[column].apply(clob_to_str)
        result_zags = process_zags(df)
        upload_to_sql(sql_upload_zags, result_zags, dssb_cursor, dssb_conn)
        start_row_pos = start_row_pos + b_size
        print("Загрузилось:", start_row_pos, "строк")

    dssb_cursor.execute(
        f"""
                    delete from {children_table} 
                    where s$change_date >= trunc(sysdate) and s$change_date < trunc(sysdate) +1 and (actdate is null or actdate = '0001-01-01') 
                    and actnumber is null and (childbirthdate is null or childbirthdate = '0001-01-01') 
                    and childiin is null and (marriageactdate is null or marriageactdate = '0001-01-01') and (motherbirthdate is null or motherbirthdate = '0001-01-01') 
                    and motheriin is null and mothername is null and motherpatronymic is null and mothersurname is null 
                    and (fatherbirthdate is null or fatherbirthdate = '0001-01-01') and fatheriin is null and fathername is null and fatherpatronymic is null 
                    and fathersurname is null and zagscode is null and zagsnamekz is null and zagsnameru is null
                         """
    )
    dssb_conn.commit()
    dssb_cursor.execute(
        f"""
        DELETE FROM DSSB_OCDS.D$GDB_ZAGS z
WHERE ROWID IN (
SELECT row_id
FROM(
select ROWID as row_id,
       ROW_NUMBER() OVER (PARTITION BY IIN,
       MOBILE,
       ACTDATE, 
       ACTNUMBER,
       CHILDBIRTHDATE,  
       CHILDIIN,  
       MARRIAGEACTDATE, 
       MOTHERBIRTHDATE,
       MOTHERIIN, 
       MOTHERNAME,  
       MOTHERPATRONYMIC,  
       MOTHERSURNAME, 
       FATHERBIRTHDATE, 
       FATHERIIN, 
       FATHERNAME,  
       FATHERPATRONYMIC,  
       FATHERSURNAME, 
       ZAGSCODE ORDER BY S$CHANGE_DATE DESC) AS RN
from DSSB_OCDS.D$GDB_ZAGS z
)
WHERE RN > 1
  AND ROWNUM < 1000000
)
""")
    dssb_conn.commit()
    dssb_cursor.close()
    dssb_conn.close()


default_args = {
    "owner": "AkejanA",
    "email": ["AkejanA@halykbank.kz"],
    "depend_on_past": False,
    "email_on_failure": False,
}

with DAG(
    dag_id="RB2_GBD_FL_DATA",
    start_date=datetime.datetime(2024, 10, 23),
    schedule="0 8 * * *",  # "@once",
    default_args=default_args,
    catchup=False,
) as dag:
    oracle_hook = OracleHook(oracle_conn_id="db_oracle_dssb__dssb_de", schema="DSSB_OCDS")
    kwargs = {"oracle_hook": oracle_hook}

    gbdrnreport305 = PythonOperator(
        task_id="final_gbdrnreport305_load",
        # provide_context=True,
        python_callable=final_gbdrnreport305_load,
        op_kwargs=kwargs,
        dag=dag,
    )

    gbdrnreport306 = PythonOperator(
        task_id="final_gbdrnreport306_load",
        # provide_context=True,
        python_callable=final_gbdrnreport306_load,
        op_kwargs=kwargs,
        dag=dag,
    )

    gbdrnreport_auto = PythonOperator(
        task_id="final_gbdrnreport_auto_load",
        # provide_context=True,
        python_callable=final_auto_load,
        op_kwargs=kwargs,
        dag=dag,
    )

    gbdrnreport_zags = PythonOperator(
        task_id="final_gbdrnreport_zags_load",
        # provide_context=True,
        python_callable=final_zags_load,
        op_kwargs=kwargs,
        dag=dag,
    )
    
    #[gbdrnreport306, gbdrnreport305, gbdrnreport_auto, gbdrnreport_zags]
    gbdrnreport_zags
